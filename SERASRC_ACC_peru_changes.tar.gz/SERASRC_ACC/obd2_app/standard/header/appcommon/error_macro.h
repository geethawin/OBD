/*!< INclude File Header */
#ifndef __OBD2FW_ERR_H_
#define __OBD2FW_ERR_H_

/*!< Add Doxygen comment for macro, variables and function */
#define OBD2_SUCCESS         (0)
#define OBD2_FAILURE	     (-1)	
#define E_OBD_APP_MOD_SHIFT     (16)
#define E_OBD_APP_MOD_MASK     ((1 << E_OBD_APP_MOD_SHIFT) -1)

#define E_OBD_APP_ERR_BASE     (0xE0000000)
#define E_BB_MODULE_BASE    (E_OBD_APP_ERR_BASE | (1 & E_OBD_APP_MOD_MASK) << E_OBD_APP_MOD_SHIFT) /* VAlues??????*/ 
#define E_BB_FILE_OPEN      (E_BB_MODULE_BASE + 1) /* VAlues??????*/
#define E_BB_FILE_SZ        (E_BB_MODULE_BASE + 2) /* VAlues??????*/
#define E_BB_ARG_INVALID    (E_BB_MODULE_BASE + 3) /* VAlues??????*/
#define E_BB_NO_DATA        (E_BB_MODULE_BASE + 4) /* VAlues??????*/
#define E_CFG_FILE_OPEN     (E_BB_MODULE_BASE + 5)

/*
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 5)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 6)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 7)
*/

#endif /* __OBD2FW_ERR_H_ */

