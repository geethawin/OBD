#ifndef __APP__
#define __APP__

#define BLACKBOX
#define GYRO_ENABLE 1
#define ACC_ENABLE  1
#define __USB__
#include "common.h"
#include  <stdio.h>
#include  <stdlib.h>
#include <netinet/in.h>
#include <signal.h>
#include <semaphore.h>
#include <mqueue.h>
#include<string.h>
#include <errno.h>
#include <unistd.h>
#include "error_macro.h"
#include "debug.h"
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <termios.h>

#define USB_2		"/dev/ttyUSB2"
#ifdef BLACKBOX 

#include "blackbox.h"
        
#endif


#define _ANALYTICS_

#define APP_WAKE  0
#define APP_SLEEP 1

/*MACRO for Data Id*/

#define KEY_ON			0x1
#define KEY_OFF 		0x2
#define SAMPLING 		0x3
#define BCALL			0x4
#define ECALL			0x5
#define BLCK_OFF		0x6
#define BLCK_ON			0x7
#define DULCK			0x8
#define DLCK			0x9
#define EXCHNG_SIM		0xA
#define TMOUT_MSG		0xB
#define IMM_POS			0xC
#define CALL_CON_ERR		0xD
#define CAN_SIGN		0xE
#define CRASH_BCALL		0xF
#define DGT_INP			0x10
#define THEFT			0x11
#define THEFT_OFF		0x12
#define THEFT_ON		0x13
#define BB_EN			0x14
#define BB_FN			0x15
#define BB_LWN			0x16
#define MB_CN			0x17
#define MB_LWN			0x18
#define MB_RN			0x19
#define GAN			0x1A
#define PANIC_OFF		0x1B
#define PANIC_ON		0x1C
#define ROUTE_VIO		0x1D
#define RPM_OVER		0x1E
#define	OVERSPEED		0x1F
#define OVERTEMP		0x20
#define PNC_BTN			0x21
#define UNAUTHORIZED_MOVEMENT	0x22
#define CRASH			0x23
#define HARSH			0x24
#define	HARSH_ACC		0x25
#define HARSH_BRK		0x26
#define LEFT_TURN		0x27
#define RIGHT_TURN		0x28
#define JA_DT			0x29
#define JOURNEY_OFF		0x2A
#define JOURNEY_ON		0x2B
#define NETW_ERR		0x2C
#define NO_CARRIER		0x2D
#define PM_OFF			0x2E
#define PM_ON			0x2F
#define REALTM_POS		0x30
#define RELAY_WARN		0x31
#define TAN			0x32
#define V_KEY_OFF		0x33
#define V_KEY_ON		0x34
#define RESET			0x35
#define THIRD_BUTTON		0x36
#define THIRD_BUTTON_REL	0x37
#define DRIVER_REC		0x38
#define SM_ON			0x39
#define PWR_LW			0x3A
#define PWR_OFF			0x3B
#define IDLE_ON			0x3C
#define IDLE_OFF		0x3D
#define GAN_ENTRY		0x3E
#define GAN_EXIT		0x3F
#define LOAD			0x40
#define UNLOAD			0x41
#define GOODS_DLV		0x42
#define G_ENTRY			0x43
#define	G_EXIT			0x44
#define DREAR_OPEN		0x45
#define DREAR_CLOSE		0x46
#define DLEFT_OPEN		0x47
#define DLEFT_CLOSE		0x48
#define DRIGHT_OPEN		0x49
#define DRIGHT_CLOSE		0x4A
#define UNAUTHORIZED_DOOROPEN	0x4B

#define MAX_BUF_SZ		512
/*RMC*/

#define TIME_STAMP          1
#define RMA_FIX_STATUS      2
#define RMA_CUR_LATITUDE    3
#define RMA_HEMISPHERE      4
#define RMA_CUR_LONGITUDE   5
#define RMA_GREENWICH       6
#define RMA_KNOT_SPEED      7
#define RMA_DIRECTION       8

/*VTG*/
#define DIRECTION     	1 
#define KMPH_SPEED      7

/*GSV*/
#define NO_OF_SAT       3

/*GGA*/
#define TIME_STAMP      1
#define CUR_LATITUDE    2
#define HEMISPHERE      3
#define CUR_LONGITUDE   4
#define GREENWICH       5
#define FIX_STATUS      7
#define ALTITUDE	9
#define GEOID		11

/*GSA*/
#define PDOP		15
#define HDOP		16
#define VDOP		17
#define MAX_SIZE 	2048
struct obd_data
{
	int msg_type;
	//char prop[64];
	char data[MAX_SIZE];
};

#ifdef _XLS__EN_
_xls xls_objs;
#endif
extern int ttl;
car_parameters carparams;

typedef struct _appClient{
	int appSleep;
#ifdef BLACKBOX 
	blackbox_t bb;
#endif
}_appClient;

_appClient appClient;

typedef struct config{
        char deviceid[64];
	void * server_cfg;
//        char host[128];
//        int port;
}config;

typedef struct Client{
       	void * deviceClient;
        config cfg;
	mqd_t obd_queue_id;
	mqd_t fw_to_usb_id;
	sem_t obd_cloud_sem;
	sem_t obd_q_sem;
	sem_t gps_sem;
	sem_t rns_sem;
	int interrupt;
	int ttl;
}Client;

Client dmClient;

typedef struct _car_data{
	double veh_speed;
	double rpm;
	double engine_load;
	int distance_dtc_clear;
	double air_temp;
	double Eng_cool_temp;
	double Run_time_since_engine_start;
	double fuel_level;
	double Engine_oil_temp;
	double maf_rate;
	double ctrl_module_vol;
	double fuel_rate;
	double pedal_position;
	char engine_run_time[15];
	double i_battery_volt;
	float i_battery_cur;	
}_car_data;

_car_data car_data;



struct gps_rmc_t
{
        unsigned int hour;
        unsigned int minutes;
        unsigned int seconds;
        double latitude;
        double longitude;
        double speed;
        double direction;
        char nmea[200];
        int gps_valid; 
	int gps_init_fix; 
};

struct gps_gga_t
{
        char nmea[200];
	unsigned int hour;
        unsigned int minutes;
        unsigned int seconds;
        double latitude;
        double longitude;
	double altitude;
	double geoid;
	int gps_valid;	
	int gps_init_fix; 
};

struct gps_vtg_t
{
        char nmea[200];
	double speed;
        double direction;
};

struct gps_gsv_t
{
        char nmea[200];
	int no_f_sat;
};


struct gps_gsa_t
{
        char nmea[200];
        double pdop;
        double hdop;
        double vdop;

};

struct gps_pkt
{
        struct gps_gsv_t gps_gsv;
        struct gps_rmc_t gps_rmc;
        struct gps_gga_t gps_gga;
        struct gps_gsa_t gps_gsa;
        struct gps_vtg_t gps_vtg;
};

typedef struct _telemetry{
char pi[10];
char std[10];
char v[30];
char u[30];
char time[30];
}_telemetry;

typedef struct _payload{
	char EventCode[30];
	char timestamp[30];
	double Latitude;
	double Longitude;
	double altitude;
	double direction;
	int gpsSatNum;
	double Speed;
	char sensor[30];
	double gps_pdop;
	double gps_hdop;
	double Partial_Odometer;
	double Full_Odometer;
	int DTC_number;
	char GSM_level[4];
	float ExtPowerVoltage;
	char Cell_ID[30];
	char LAC[30];
	char PTO[5];
	double TotalFuel;
	double FuelLevel;
	char EngineTotHours[15];
	char ServiceDist[15];
	char PTO_eng[15];
	char GeofenceZone[10];
	char EcoDrivingValue[10];
	//char Accelerometer[64];
	_telemetry telemetry[8];
}_payload;

typedef struct _c_header{
char IoTHub_app_transactionId[128];
char IoTHub_app_deviceId[128];
char IoTHub_app_deviceType[64];
char IoTHub_app_serviceName[64];
char IoTHub_app_timestamp[64];
char Authorization[256];
}_c_header; 

typedef struct _a_header{
char Accept[30];
char Content_Type[64];
char iothub_to[128];
char Authorization[256];
char Connection[64];
char User_Agent[128];
char iothub_app_temperatureAlert[64];
char Host[64];
char Content_Length[30];
}_a_header;

typedef struct _packet{
_a_header a_header;
_c_header c_header;
_payload payload;
}_packet;

_packet packet_global;
sem_t gps_sem;
unsigned long long msts;
extern int dtc_num[256];
int dtc_number;
void sample_evt_thread (void);
car_parameters g_carparams;
extern int d_count;
struct gps_rmc_t g_gps_rmc;
accelerometer_api_priv g_adata;
extern int tot_odometer;


int ParseRMC(struct gps_rmc_t *, size_t );
int ParseGSV(struct gps_gsv_t *, size_t );
int ParseGGA(struct gps_gga_t *, size_t );
int ParseGSA(struct gps_gsa_t *, size_t );
int ParseVTG(struct gps_vtg_t *, size_t );

int get_config(Client *);
int thread_init(void);
int indicate_device_exit(void);
int get_host_by_name(Client *,char * );
int get_config(Client *);
void set_ttl(void);
void reconnect_thread(void);
int convert_raw_data(car_parameters *);
int publishEventWrapper(char *);
int get_gps_data_wrapper(struct gps_pkt *);
int publishEvent(char*);
int check_telemetry(char *);
int read_req_data(struct gps_pkt *,accelerometer_api_priv *,char * );
int send_data_to_server(struct gps_pkt *,car_parameters *,char *,char *);
int final_payload_frame(char *, struct obd_data *, char *);
int get_tot_odometer();
void get_time_zone(char *);
int validate_time_fence(struct tm *);
int send_notification(const char *);
//int get_xml_content(char *filename, char *parent_node,char *name, char *value);
#endif
