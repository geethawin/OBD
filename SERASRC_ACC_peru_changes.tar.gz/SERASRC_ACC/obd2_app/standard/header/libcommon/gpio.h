#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define INPUT 1
#define OUTPUT 0

int gpio_export(int gpio);
int get_gpio(int gpio, int * value);
int set_gpio_direction(int gpio, int direction);
int set_gpio_value(int gpio, int value);
