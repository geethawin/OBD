#ifndef __ACCELEROMETER_H__
#define __ACCELEROMETER_H__

typedef struct _accelerometer_api_priv
{
    int fd;
    double x,y,z,acc;
} accelerometer_api_priv;

/* global declaration */
int acc_init();
int acc_deinit();
int get_accelerometer(accelerometer_api_priv *adata);
#endif /* #define __ACCELEROMETER_H__ */
