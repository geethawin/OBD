#ifndef __INIT_CALLBACKS__
#define __INIT_CALLBACKS__

void main_ign_on (char *);
void main_pnc_btn (char *);
void main_ign_off (char *);
void main_dis_stat (char *);
void main_bat_drain (char *);
void main_crash_det (char *);
void sys_sleep (void);
void sys_wake_dis (void);
void sys_wake (void);
void sigHandler(int signo);

#endif
