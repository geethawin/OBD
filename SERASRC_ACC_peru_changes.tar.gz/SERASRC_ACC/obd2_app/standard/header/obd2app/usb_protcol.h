#ifndef __USB_PROTOCOL_H
#define __USB_PROTOCOL_H

/*! extern cplus TODO */
#include <usb_protcol_typedefs.h>
#include <stdint.h>

//WINDOW CONSTANTS
/*!< SCREENS IDs*/

//#define CONNECTION_MODULEBASE 				(0x0100)
//#define STATUS_MODULEBASE 				(0x0200)
//#define CONNECTION_WINDOW_1   				(CONNECTION_MODULEBASE + 1)  
#define CONNECTION_WINDW   				(0x0101) 	//1st window 
#define MAIN_WINDOW_ID 					(0x0005) 	//
//STATUS  CONSTANTS
#define STATUS_CPU_WINDOW_ID				(0x0006)
#define STATUS_IO_WINDOW_ID   				(0x0007) 
#define STATUS_GSM_GPRS_WINDOW_ID   			(0x0008) 
#define STATUS_SOFTWARE__WINDOW_ID  			(0x0009)
//SIM CONFIGURATION
#define SIM_CONFIG_WINDOW_ID				(0x000A)
//CLOUD CONFIGURATION
#define CLOUD_CONFIG_WINDOW_ID 				(0x000F)
#define CLOUD_AZURE_CONFIG_WINDOW_ID			(0x0010)
#define CLOUD_AWS_CONFIG_WINDOW_ID			(0x0011)
#define CLOUD_IBM_CONFIG_WINDOW_ID			(0x0012)
#define CLOUD_ORACLE_CONFIG_WINDOW_ID			(0x0013)
#define CLOUD_TCPIP_CONFIG_WINDOW_ID			(0x0014)
//SETTINGS
#define SETTINGS_WINDOW_ID 		    		(0x0020) 
#define SETTINGS_GENERAL_WINDOW_ID 			(0x0021) 
#define SETTINGS_THRSHOLD_WINDOW_ID 			(0x0022) 
#define SETTINGS_IO_WINDOW_ID	  			(0x0023) 
//FIRMWARE
#define FIRMWARE_WINDOW_ID  				(0x0030) 
//BLACKBOX
#define BLACK_BOX_WINDOW_ID  				(0x0040)
//IMMOBILIZER
#define IMMOBILIZER_WINDOW_ID  				(0x0050)
//USRID_PWD
#define USRID_PWD_WINDOW_ID  				(0x0060)


//CMD ID:
/*!< Command ID to get request for Device Information*/
#define GET_DEV_INFO_REQ   				(0x0001)
#define CONNECTION_REQ   				(0x0002)
#define DEV_STATUS_REQ   				(0x0003)
//STATUS
#define CPU_INFO_REQ 					(0x00CA) 
#define IO_INFO_REQ    					(0x00DA) 
#define GSM_GPRS_INFO_REQ   				(0x00EA) 
#define SOFTWARE_REQ   					(0x00FA) 
//SIM CONFIGUARTION
#define GET_SIM_CONFIG_REQ   				(0x025A)
#define SET_SIM_CONFIG_REQ   				(0x025B)
//CLOUD CONFIGUARTION
#define CLOUD_AZURE_REQ   				(0x02B0) 
#define GET_CLOUD_AZURE_CONFIG_REQ   			(0x02B1)
#define SET_CLOUD_AZURE_CONFIG_REQ   			(0x02B2)
//SETTINGS
#define GET_GEN_SET_REQ   				(0x0422)
#define SET_GEN_SET_REQ   				(0x0423)
#define GET_THRSLD_SET_REQ   				(0x04EA)
#define SET_THRSLD_SET_REQ   				(0x04EB)
#define GET_IO_SET_REQ   				(0x05B2)
#define SET_IO_SET_REQ   				(0x05B3)
//FIRMWARE
#define FIRM_TYPE_INFO_REQ   				(0x07A0)
#define FIRM_DATA_REQ   				(0x07A1)
//BLACKBOX
#define DATA_XFER_REQ   				(0x07B0)

//*!<Command ID to send response for Device Information*/ 
#define GET_DEV_INFO_RSP   				(0x8001) 
#define CONNECTION_RSP 					(0x8002) 
#define DEV_STATUS_RSP 					(0x8003) 
//STATUS
#define CPU_INFO_RSP        				(0x80CA) 
#define IO_INFO_RSP    					(0x80DA) 
#define GSM_GPRS_INFO_RSP   				(0x80EA) 
#define SOFTWARE_RSP   					(0x80FA) 
//SIM CONFIGUARTION
#define GET_SIM_CONFIG_RSP   				(0x825A) 
#define SET_SIM_CONFIG_RSP   				(0x825B)
//CLOUD CONFIGUARTION
#define CLOUD_AZURE_RSP  				(0x82B0) 
#define GET_CLOUD_AZURE_CONFIG_RSP   			(0x82B1)
#define SET_CLOUD_AZURE_CONFIG_RSP   			(0x82B2)
//SETTINGS
#define GET_GEN_SET_RSP   				(0x8422)
#define SET_GEN_SET_RSP   				(0x8423)
#define GET_THRSLD_SET_RSP   				(0x84EA)
#define SET_THRSLD_SET_RSP   				(0x84EB)
#define GET_IO_SET_RSP   				(0x85B2)
#define SET_IO_SET_RSP   				(0x85B3)
//FIRMWARE
#define FIRM_TYPE_INFO_RSP   				(0x87A0)
#define FIRM_DATA_RSP   				(0x87A1)
//BLACKBOX
#define DATA_TRNSFR_RSP   				(0x87B0)



//Data Size defines
/*!<MAX DATA SIZE DEVICE INFO     	 */
#define MAX_DEVICE_NAME_STR_SZ  			32
#define MAX_IMEI_STR_SZ 				15
#define	MAX_EXT_POWER_STR_SZ				 8
#define MAX_INT_POWER_STR_SZ 				 8

/*!<MAX DATA SIZE STATUS CPU     	 */
#define MAX_PROCESSOR_NAME_STR_SZ  			32
#define MAX_CLK_SPEED_STR_SZ 				 8
#define MAX_DDR3_STR_SZ					 8
#define MAX_NAND_STR_SZ 				 8
/*!<MAX DATA SIZE STATUS  IO 		*/
#define MAX_IGNITION_STATUS_STR_SZ 	   		 6
/*!<MAX DATA SIZE STATUS GSM_GPRS      	*/
#define MAX_SIM_STATUS_STR_SZ				 8
#define MAX_NETWORK_STATUS_STR_SZ 			12
/*!<MAX DATA SIZE STATUS SOFTWARE   	*/
#define MAX_LINUX_VERSION_STR_SZ			12


/*!<MAX DATA SIZE SIM CONFIGURATION   	*/
#define MAX_ACCEPOINT_STR_SZ		32				
#define MAX_SIM_USERNAME_STR_SZ 	32
#define MAX_SIM_PASSWORD_STR_SZ		32
#define MAX_APN_NAME_STR_SZ 		32
/*!<MAX DATA SIZE CLOUD AZURE CONFIGURATION   */
#define MAX_PORT_STR_SZ 				2
#define MAX_HOST_STR_SZ    				32
#define MAX_DEVICE_ID_STR_SZ				32
#define MAX_DEVICE_TYPE_STR_SZ				32
#define MAX_IOT_HUB_NAME_STR_SZ     			32
#define MAX_SAS_TOKEN_STR_SZ				128
/*!<MAX DATA SIZE STATUS SOFTWARE   			*/


//Sim Configuration --> network_mode
#define TWOG 1 
#define THREEG 2  
//General Settings --> mode
#define LAB_MODE 1
#define CAR_MODE 2 
//IO Settings dout1,dout1 --> 
#define BUZZER 1
#define RELAY  2

#define MAX_AIN1_STATUS_STR_SZ 32

typedef struct  __attribute__((__packed__)) usb_board
{
	uint16_t scr_id;
	uint16_t cmd_id;
	uint8_t type;
	uint16_t size;
	uint16_t crc;
	char *payload;
} usb_board;


typedef struct  __attribute__((__packed__)) usb_pkt
{
	USHORT scr_id;
	USHORT cmd_id;
	UCHAR type;
	USHORT size;
	USHORT crc;
	//char payload[USB_DATA_4095_BYTES];
	char *payload;
} usb_pkt_t;

//*!<Structure to recieve response for CPU Information*/
typedef struct  __attribute__((__packed__)) st_dev_info
{
	UCHAR device_name[MAX_DEVICE_NAME_STR_SZ];
	UCHAR imei_number[MAX_IMEI_STR_SZ];
	UCHAR ext_power[MAX_EXT_POWER_STR_SZ];
	UCHAR int_battery[MAX_INT_POWER_STR_SZ];
} st_dev_info_t;
#if 1
//*!<Structure to send request for CPU Information*/
typedef struct  __attribute__((__packed__)) st_cpu_info
{
	UCHAR proc_name[MAX_PROCESSOR_NAME_STR_SZ];
	UCHAR clk_speed[MAX_CLK_SPEED_STR_SZ];
	UCHAR ddr3[MAX_DDR3_STR_SZ];
	UCHAR nand[MAX_NAND_STR_SZ];
} st_cpu_info_req_t;
#endif

//*!<Structure to recieve response for IO Information*/
typedef struct  __attribute__((__packed__)) st_io_info
{
	UCHAR ignition_status[MAX_IGNITION_STATUS_STR_SZ];
	//whether to use double or uchar
	UCHAR AIN1[MAX_AIN1_STATUS_STR_SZ];

} st_io_info_rsp_t;
#if 0
//*!<Structure to send request for IO Information*/
typedef struct  __attribute__((__packed__)) st_io_info
{
	UCHAR ignition_status[MAX_IGNITION_STATUS_STR_SZ];
	//whether to use double or uchar
	UCHAR ain1[MAX_AIN1_STATUS_STR_SZ];

} st_io_info_req_t;
#endif


//*!<Structure to recieve response for GSM_GPRS Information*/
typedef struct  __attribute__((__packed__)) st_gsm_gprs_info
{
	UCHAR sim_status[MAX_SIM_STATUS_STR_SZ];
	UCHAR network_status[MAX_NETWORK_STATUS_STR_SZ];

} st_gsm_gprs_info_rsp_t;

#if 0
//*!<Structure to send request for GSM_GPRS Information*/
typedef struct  __attribute__((__packed__)) st_gsm_gprs_info
{
	UCHAR sim_status[MAX_SIM_STATUS_STR_SZ];
	UCHAR network_status[MAX_NETWORK_STATUS_STR_SZ];

} st_gsm_gprs_info_req_t;
#endif


//*!<Structure to recieve response for SOFTWARE Information*/
typedef struct  __attribute__((__packed__)) st_software_info
{
	UCHAR linux_version[MAX_LINUX_VERSION_STR_SZ];


} st_software_info_rsp_t;
#if 0
//*!<Structure to send request for SOFTWARE Information*/
typedef struct  __attribute__((__packed__)) st_software_info
{
	UCHAR linux_version[MAX_LINUX_VERSION_STR_SZ];


} st_software_info_req_t;
#endif


//*!<Structure to recieve response for SIM Configuration*/
typedef struct  __attribute__((__packed__)) sim_config
{
	UCHAR apn_name[MAX_APN_NAME_STR_SZ];
	UCHAR access_point[MAX_ACCEPOINT_STR_SZ];
	UCHAR sim_username[MAX_SIM_USERNAME_STR_SZ];  
	UCHAR sim_password[MAX_SIM_PASSWORD_STR_SZ]; 
	//network_mode=2G 1 ,3G=2 
	UCHAR  network_mode;
	//flight_mode=ON 1,OFF=2
	UCHAR  flight_mode;


} sim_config_rsp_t;
#if 0
//*!<Structure to send request for SIM Configuration*/
typedef struct  __attribute__((__packed__)) sim_config
{
	UCHAR apn_name[MAX_APN_NAME_STR_SZ];
	UCHAR access_point[MAX_ACCEPOINT_STR_SZ];
	UCHAR sim_username[MAX_SIM_USERNAME_STR_SZ];
	UCHAR sim_password[MAX_SIM_PASSWORD_STR_SZ];
	//network_mode=2G 1 ,3G=2  
	UCHAR  network_mode;
	//flight_mode=ON 1,OFF=2
	UCHAR  flight_mode;

} sim_config_req_t;
#endif


//*!<Structure to recieve response for CLOUD AZURE Configuration*/
typedef struct  __attribute__((__packed__)) cloud_azure_config
{
	UCHAR host[MAX_HOST_STR_SZ];
	UCHAR port[MAX_PORT_STR_SZ];
	UCHAR device_id[MAX_DEVICE_ID_STR_SZ];
	UCHAR device_type[MAX_DEVICE_TYPE_STR_SZ];
	UCHAR iot_hub_name[MAX_IOT_HUB_NAME_STR_SZ]; //MAX_IOT_HUB_NAME_STR_SZ MAX_SAS_TOKEN_STR_SZ MAX_MODE_STR_SZ MAX_SAMPLING_FREQUENCY_STR_SZ
	UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ];	

} cloud_azure_config_rsp_t;
#if 0
//*!<Structure to send request for CLOUD AZURE  Configuration*/
typedef struct  __attribute__((__packed__))  cloud_azure_config
{
	UCHAR host[MAX_HOST_STR_SZ];
	//
	UCHAR port[MAX_PORT_STR_SZ]
		UCHAR device_id[MAX_DEVICE_ID_STR_SZ];
	UCHAR device_type[MAX_DEVICE_TYPE_STR_SZ];
	UCHAR iot_hub_name[MAX_IOT_HUB_NAME_STR_SZ]; 
	UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ];	

} cloud_azure_config_req_t;
#endif


/*!<Structure to recieve response for Settings General*/
typedef struct  __attribute__((__packed__)) settings_general
{
	//mode=LAB_MODE=1,CAR_MODE=2
	UCHAR mode;
	UCHAR sampling_frequency;
	UCHAR can_sign;

} settings_general_rsp_t;
#if 0
//*!<Structure to send request for  Settings General*/
typedef struct  __attribute__((__packed__)) settings_general
{

	//mode=LAB_MODE=1,CAR_MODE=2 
	UCHAR mode;
	UCHAR sampling_frequency;
	UCHAR can_sign;

} settings_general_req_t;
#endif



/*!<Structure to recieve response for Settings Threshold*/
typedef struct  __attribute__((__packed__)) settings_threshold
{

	UCHAR harsh_brake_source;
	UCHAR harsh_acceleration_source;
	UCHAR crash_source;
	UCHAR harsh_source;
	UCHAR overspeed_source;
	UCHAR odometer_soruce;

	UCHAR  harsh_brake_threshold;
	UCHAR harsh_acceleration_threshold;
	UCHAR crash_threshold;
	UCHAR harsh_threshold;
	UCHAR overspeed_threshold;
	UCHAR odometer_base;

	UCHAR overspeed_duration;


} settings_threshold_rsp_t;
#if 0
//*!<Structure to send request for Settings Threshold*/
typedef struct  __attribute__((__packed__)) settings_threshold
{

	UCHAR  harsh_brake_source;
	UCHAR harsh_acceleration_source;
	UCHAR crash_source;
	UCHAR harsh_source;
	UCHAR overspeed_source;
	UCHAR odometer_soruce;

	UCHAR  harsh_brake_threshold;
	UCHAR harsh_acceleration_threshold;
	UCHAR crash_threshold;
	UCHAR harsh_threshold;
	UCHAR overspeed_threshold;
	UCHAR odometer_base;

	UCHAR overspeed_duration;

} settings_threshold_req_t;
#endif

/*!<Structure to recieve response for  Settings IO*/
typedef struct  __attribute__((__packed__)) settings_io
{
	//dout=BUZZER=1,RELAY=2
	UCHAR dout1;
	UCHAR dout2; 
}settings_io_rsp_t;


#if 0
//*!<Structure to send request for  Settings IO*/

typedef struct  __attribute__((__packed__)) settings_io
{
	//dout=BUZZER=1,RELAY=2
	UCHAR dout1;
	UCHAR dout2; 
}settings_io_req_t;
#endif




/*Yet to put detailed description

  --> Confirm on the structures
  --> Firmware Data Size,Type,Remaining byte,actual data etc

 */
/*!<Structure to recieve response for firmware*/
typedef struct  __attribute__((__packed__)) firmware
{
	UCHAR firmware_type;
	UCHAR file_sytem_type; 
}firmware_rsp_t;


#if 0
//*!<Structure to send request for  Settings firmware*/

typedef struct  __attribute__((__packed__)) firmware
{
	UCHAR firmware_type;
	UCHAR file_sytem_type; 
}firmware_req_t
#endif


//*!<Structure to recieve response for firmware*/
typedef struct  __attribute__((__packed__)) firmware_type
{
	UCHAR firmware_type;
	UCHAR file_sytem_type; 
}firmware_type_rsp_t;


#if 0
//*!<Structure to send request for  Settings firmware*/

typedef struct  __attribute__((__packed__)) firmware_type
{
	uchar white_list[10][10]; 
}firmware_type_req_t;
#endif




#endif /*!< #ifndef __USB_PROTOCOL_H */
