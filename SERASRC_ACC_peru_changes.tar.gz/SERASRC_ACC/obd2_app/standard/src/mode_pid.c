#include "application.h"
#include "standard.h"

int convert_cardata_strtodouble(char * buf,double * ptr)
{

	char str[64] = {0};
	int len = strlen(buf);
	int in = 0;
	int index = 0;

	while(len > 0)
	{
		memset(str,0,sizeof(str));
		str[0] = buf[in];
		str[1] = buf[in+1];
		str[2] = '\0';
		//printf("str is %s \n",str);
		ptr[index] = (int)strtol(str, NULL, 16);
		//printf("copied in double is %f \n",ptr[index]);
		index++;
		in = in+3;
		len = len - 3;
	}

	/* no of bytes */
	return index;

}

int convert_raw_data(car_parameters *carparams)
{

	int no_of_pids = 0;
	no_of_pids = carparams->no_of_pids;
	int in = 0;
	double values[64];
	int ret;

	ret = raw_can_enable();
	if (no_of_pids <= 0)
			return -1;

	while(no_of_pids > 0)
	{
		memset(values,0,sizeof(values));	
		convert_cardata_strtodouble(carparams->modepid[in].raw_data,&values[0]);
		switch(carparams->modepid[in].mode){
			case 0x1:
				if((strcmp(carparams->modepid[in].pid,"0C")==0) || \
				   (strcmp(carparams->modepid[in].pid,"0c")==0) || \
				   (strcmp(carparams->modepid[in].pid,"C")==0)){
					if(ret != 1) {	
						carparams->modepid[in].data = ((256 * values[0]) +  values[1])/4;
						car_data.rpm = 0;
					}
					car_data.rpm = carparams->modepid[in].data;
					printf("CD - Vehicle RPM is %f \n",car_data.rpm);
				}
				else if((strcmp(carparams->modepid[in].pid,"0D")==0) || \
					(strcmp(carparams->modepid[in].pid,"0d")==0) || \
					(strcmp(carparams->modepid[in].pid,"D")==0)){
					if(ret != 1) {
						carparams->modepid[in].data = values[0];
						car_data.veh_speed = 0;
					}
					car_data.veh_speed = carparams->modepid[in].data;
					if ((ret == 1) && (car_data.veh_speed == 0) && (car_data.rpm == 0)){
						IOBD_DEBUG_LEVEL3 ("*Propritary* standard_cli.g_gps.gps_rmc.speed:%f",\
									standard_cli.g_gps.gps_rmc.speed);
						car_data.veh_speed = standard_cli.g_gps.gps_rmc.speed; 
					}
					printf("CD - Vehicle speed is %f \n",car_data.veh_speed);
				}
				else if((strcmp(carparams->modepid[in].pid,"04")==0) || \
					(strcmp(carparams->modepid[in].pid,"4")==0)){
					carparams->modepid[in].data = (values[0] * 100)/255;
					car_data.engine_load = 0;
					car_data.engine_load = carparams->modepid[in].data;
					printf("CD - Engine Load is %f \n",car_data.engine_load);
				}
				else if((strcmp(carparams->modepid[in].pid,"31")==0)){
					carparams->modepid[in].data = (256*values[0]) + values[1];//increase by 1(every time car ign off starts from 0);
					car_data.distance_dtc_clear = 0;
					car_data.distance_dtc_clear = (int)carparams->modepid[in].data;
					printf("CD - Distance DTC clear %d \n",car_data.distance_dtc_clear);

				}
				else if((strcmp(carparams->modepid[in].pid,"05")==0) || \
					(strcmp(carparams->modepid[in].pid,"5")==0)){
					carparams->modepid[in].data = values[0] -40;
					car_data.Eng_cool_temp = carparams->modepid[in].data;
					printf("CD - engine coolant temperature %f \n",car_data.Eng_cool_temp);
					//printf("Engine coolant temperature %f \n",carparams->modepid[in].data);
				}
				else if((strcmp(carparams->modepid[in].pid,"46")==0)){
					if(values[0] == 0.00)
					{
						carparams->modepid[in].data = values[0];
					}
					else
						carparams->modepid[in].data = values[0]-40;

					car_data.air_temp = 0;
					car_data.air_temp = carparams->modepid[in].data;
					printf("CD - air temperature %f \n",car_data.air_temp);

					//printf("Air temperature %f\n",air_temp);
				}
				else if((strcmp(carparams->modepid[in].pid,"2F")==0) || (strcmp(carparams->modepid[in].pid,"2f")==0)){
					carparams->modepid[in].data = (values[0] * 100)/255;
					car_data.fuel_level = carparams->modepid[in].data;
					printf("CD - Fuel Tank level input %f \n",car_data.fuel_level);
					//	printf("Fuel level %f \n",carparams->modepid[in].data);
				}
				else if((strcmp(carparams->modepid[in].pid,"5A")==0) || (strcmp(carparams->modepid[in].pid,"5a")==0)){
					carparams->modepid[in].data = (values[0] * 100)/255;
					car_data.pedal_position = carparams->modepid[in].data;
					printf("CD - Accelerator pedal position %f \n",car_data.pedal_position);
				}
				else if((strcmp(carparams->modepid[in].pid,"10")==0)){
					carparams->modepid[in].data =((256 * values[0]) + values[1])/100;
					car_data.maf_rate = carparams->modepid[in].data;
					printf("CD - MAF Rate %f \n",carparams->modepid[in].data);
				}
			#if 0
				else if((strcmp(carparams->modepid[in].pid,"1F")==0) || (strcmp(carparams->modepid[in].pid,"1f")==0)){
					carparams->modepid[in].data = (256 * values[1]) + values[0];
					car_data.Run_time_since_engine_start = carparams->modepid[in].data;
					//printf("CD - run time since engine start %f \n",carparams->modepid[in].data);
					//	printf("Run time engine start %f \n",carparams->modepid[in].data);
				}

				else if((strcmp(carparams->modepid[in].pid,"5C")==0) || (strcmp(carparams->modepid[in].pid,"5c")==0)){
					carparams->modepid[in].data = values[0]-40;
					car_data.Engine_oil_temp = carparams->modepid[in].data;
					//					printf("CD - Engine oil temperature %f \n",carparams->modepid[in].data);
					//	printf("Oil temperature %f \n",carparams->modepid[in].data);
				}
				else if((strcmp(carparams->modepid[in].pid,"42")==0)){
					carparams->modepid[in].data = ((256 * values[1]) + values[0])/1000;
					car_data.ctrl_module_vol = carparams->modepid[in].data;
					//					printf("CD - control module volume %f \n",carparams->modepid[in].data);
					//	printf("Control module voltage %f \n",carparams->modepid[in].data);
				}
				else if((strcmp(carparams->modepid[in].pid,"5E")==0) || (strcmp(carparams->modepid[in].pid,"5e")==0)){
					carparams->modepid[in].data = ((256 * values[1]) + values[0])/20;
					car_data.fuel_rate = carparams->modepid[in].data;
					//					printf("CD - fuel rate %f \n",carparams->modepid[in].data);
					//	printf("Fuel mode %f \n",carparams->modepid[in].data);
				}
			#endif
				else if((strcmp(carparams->modepid[in].pid,"7F")==0) || (strcmp(carparams->modepid[in].pid,"7f")==0)){
					//car_data.engine_run_time = 0;
					int ERT[20];
					char vals[5]={0};
					int i = 0;
					int index = 0;
					//                        printf("length %d \n",strlen(carparams->modepid[in].raw_data));

					/* ERT will be 13 characters, in ASCII 26 */
					if(strlen(carparams->modepid[in].raw_data)>26){
						for(i = 0;i<13;i++)
						{
							vals[0] = carparams->modepid[in].raw_data[index++];
							vals[1] = carparams->modepid[in].raw_data[index++];
							vals[2]='\0';
							//                      printf("vals[0] %d \n",vals[0]);
							//                      printf("vals[1] %d \n",vals[1]);
							//                      ERT[i]=atoi(vals);
							ERT[i]= (int)strtol(vals, NULL, 16);

							//printf("ERT[i] %c \n",ERT[i]);
							index++;
						}
#if 0                   
						for(i=0;i<17;i++)
							printf("ERT[%d]:%d",i,ERT[i]);
#endif
						sprintf(car_data.engine_run_time,",%c%c%c%c%c%c%c%c%c%c%c%c%c",ERT[0],ERT[1],ERT[2],ERT[3],ERT[4],ERT[5],ERT[6],ERT[7],ERT[8],ERT[9],ERT[10],ERT[11],ERT[12],ERT[13]);
						printf("ERT present %s\n",car_data.engine_run_time);
					}
				}

				else{
					printf("Invalid PID in mode 1 \n");
				}	
				break;


			case 0x9:
				/* ToDo */
				break;
			default:
				printf(" %d Mode not supported  \n",carparams->modepid[in].mode);
		}
		no_of_pids--;
		in++;
	}


	return 0;
}
