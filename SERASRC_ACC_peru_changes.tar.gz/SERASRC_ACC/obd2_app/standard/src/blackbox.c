#include "application.h"
#include "standard.h"

int blackbox_thread(void)
{
        FILE *fd_offset;
        char buf[MAX_BUF_SZ];
        long int sz = 0;
        long offset = 0;
        long int size=0;
        char filename[100];
        //int num_records;
	char time [30];
	int ret = 0,bb_error;

        appClient.bb.bb_fops.wr_pos = 0;
        appClient.bb.bb_fops.rd_pos = 0;
        appClient.bb.bb_fops.wrap_bit_fg = 0;
        appClient.bb.bb_fops.nrecords = 0;
        appClient.bb.bb_fops.bytes_written = 0;
        /*!< Read and update the above variables from XML */
/*!<start>*/
/*!<end>*/
	sprintf(filename,"%s%s",BLACKBOX_DIR,BLACKBOX_FILENAME);
#if 0
        num_records = BB_MAX_FILE_SZ/appClient.bb.bb_fops.record_sz;
	IOBD_DEBUG_LEVEL2 ("num_records = %d",num_records);
        appClient.bb.bb_fops.total_avail_bytes = num_records * appClient.bb.bb_fops.record_sz;
#endif
        appClient.bb.bb_fops.total_avail_bytes = BB_MAX_FILE_SZ;

        /*!< open the file if not exist */
        if(access(filename, F_OK)){
                appClient.bb.bb_file = fopen(filename, "w");
		IOBD_DEBUG_LEVEL1 ("Blackbox file created initially : %p",appClient.bb.bb_file);
        }
        else{
                /*Open the file in read and write mode*/
                appClient.bb.bb_file = fopen(filename, "r+");
                if (ret = CHK_NULL ((int *)appClient.bb.bb_file, stderr, "Error in blackbox_thread: fopen") != OBD2_APP_SUCCESS)
			bb_error = OBD2_APP_FAILURE;
		else{
                /*check file size if > 0 copy the last file position & move the file pointer to that location to continue writing from where it left*/
			bb_error = OBD2_APP_SUCCESS;
			ret = check_file_size(filename, &sz);
			CHK_ERR (ret, stderr, "Error in blackbox_thread: check_file_size");
			IOBD_DEBUG_LEVEL1 ("File size is: %d Bytes\r\n", sz);

			/*!< read/write from App data structure */
			if(access("/file_offset.txt", F_OK) == 0){
				fd_offset = fopen("/file_offset.txt","r");
				fread(&appClient.bb.bb_fops,sizeof(appClient.bb.bb_fops),1,fd_offset);
				IOBD_DEBUG_LEVEL2 ("file_offset\nwrite_pos %ld read_pos %ld appClient.bb.bb_fops.wrap_bit_fg %ld",appClient.bb.bb_fops.wr_pos, appClient.bb.bb_fops.rd_pos, appClient.bb.bb_fops.wrap_bit_fg);
				fseek(appClient.bb.bb_file, appClient.bb.bb_fops.wr_pos, SEEK_SET);
				fclose(fd_offset);
			}
		}
		
        }

	while(1)
	{
		IOBD_DEBUG ("File write ptr offset is: %ld \r\n",appClient.bb.bb_fops.wr_pos);
		IOBD_DEBUG ("File read ptr offset is: %ld \r\n",appClient.bb.bb_fops.rd_pos);
		if(appClient.appSleep == APP_SLEEP){
			/*!< for testing */
			ret = bb_read_single_record (appClient.bb.bb_file, buf, sizeof(buf));
			printf("bb_read_single_record : ret is %d\n Buffer is %s\n",ret,buf);
			/*!< read/write from App data structure and XML cfg file */
			fd_offset = fopen("/file_offset.txt","w");
			if (fd_offset == NULL)
				perror ("file_offset:fopen");
			fwrite(&appClient.bb.bb_fops,sizeof(appClient.bb.bb_fops),1,fd_offset);
			fclose(fd_offset);
			fclose(appClient.bb.bb_file);
			break;
		}
		frame_payload_bb(&standard_cli.g_gps, &standard_cli.g_carparams, time);
		if (bb_error != OBD2_APP_FAILURE){

			sprintf(buf, "$%s,%.6lf,%.6lf,%.6lf,%.6lf,%hd,%.6lf,%.6lf,%d,"
					"%.6lf,%.6lf,%.6lf,%.6lf,%s,%.6f,%s,%s,%.6lf,%.6lf,%s,"
					"%.6lf,%.6lf\n",appClient.bb.bb_rec.ts, appClient.bb.bb_rec.lat,
					appClient.bb.bb_rec.lon, appClient.bb.bb_rec.alt, appClient.bb.bb_rec.dir,
					appClient.bb.bb_rec.no_of_sat, appClient.bb.bb_rec.rpm, appClient.bb.bb_rec.veh_speed,
					appClient.bb.bb_rec.dtc_num, appClient.bb.bb_rec.gps_speed, appClient.bb.bb_rec.gps_pdop,
					appClient.bb.bb_rec.gps_hdop,appClient.bb.bb_rec.odometer, appClient.bb.bb_rec.gsm_level,
					appClient.bb.bb_rec.ext_volt, appClient.bb.bb_rec.cell_id, appClient.bb.bb_rec.lac, 
					appClient.bb.bb_rec.total_fuel, appClient.bb.bb_rec.fuel_level, appClient.bb.bb_rec.eng_tot_hrs,
					appClient.bb.bb_rec.eng_cool_temp, appClient.bb.bb_rec.eng_load);

			IOBD_DEBUG_LEVEL2 (buf);
			ret = bb_write_single_record (appClient.bb.bb_file, buf, strlen (buf));
			CHK_ERR (ret, stderr, "Error in blackbox_thread: bb_write_single_record");
			CHK_EOF (ret, stderr, "Error in BB: bb_write_single_record \r\n");
			sleep(1);// for every 1 sec data should be written to the file.
		}
	}
}

int bb_write_single_record (FILE *fp_bb, char *p_rec, size_t rec_sz)
{
        char *tmp_buf = NULL;
        long int f_wr_off;
        int ret;

		/*!< Lock the Resource */
		sem_wait(&appClient.bb.rw_lock);
        /*!< Check input argument validation */
        /*if (fp_bb == NULL || p_rec == NULL ||
             rec_sz > appClient.bb.bb_fops.record_sz)*/
        if (fp_bb == NULL || p_rec == NULL)
                return E_BB_ARG_INVALID;

	/*!< Get file offset */
        f_wr_off = ftell(fp_bb);
IOBD_DEBUG_LEVEL2 ("f_wr_off %ld\t appClient.bb.bb_fops.total_avail_bytes %ld\t rec_sz %ld", f_wr_off, appClient.bb.bb_fops.total_avail_bytes, rec_sz);	
	/*!< Check all available bytes are used */
        if (f_wr_off == appClient.bb.bb_fops.total_avail_bytes){
                rewind(fp_bb);
                ret = fputs(p_rec, fp_bb);
		IOBD_DEBUG_LEVEL2 ("1. ret is %d",ret);
                CHK_EOF (ret, stderr, "Error in BB: bb_write_single_record: fputs BEGIN\r\n");
        }
	/*!< check bytes need to write is more than total available bytes */
        else if ((f_wr_off + rec_sz) > appClient.bb.bb_fops.total_avail_bytes){
	/*!< Get the extra bytes which exceeds the file size */
                long diff = (f_wr_off + rec_sz) - appClient.bb.bb_fops.total_avail_bytes;
//		IOBD_DEBUG_LEVEL3 ("diff is %ld", diff);
                tmp_buf = strndup (p_rec, rec_sz - diff);
//		IOBD_DEBUG_LEVEL3 ("tmp_buf is %s", tmp_buf);
	/*!< write bytes till space available */
                ret = fputs(tmp_buf, fp_bb);
		if (ret == EOF)
			IOBD_DEBUG_LEVEL2 ("ret is %d fputs failed",ret);
                if (tmp_buf != NULL) {
                        free(tmp_buf);// free the memory. Note : check Man page strdup for more info
                }
                CHK_EOF (ret, stderr, "Error in BB: bb_write_single_record: fputs INTER_1\r\n");

	/*!< after move the pointer to beginning position as it reached EOF */
                rewind(fp_bb);
		IOBD_DEBUG_LEVEL2 ("rec_sz - diff is %ld",rec_sz - diff);
	/*!< Write the remaining bytes */
                ret = fputs(&p_rec[(rec_sz - diff)], fp_bb);
		IOBD_DEBUG_LEVEL2 ("3. ret is %d",ret);
                CHK_EOF (ret, stderr, "Error in BB: bb_write_single_record: fputs INTER_2\r\n");
        }
        else {
		ret = fputs(p_rec, fp_bb);
		IOBD_DEBUG_LEVEL2 ("4. ret is %d",ret);
                CHK_EOF (ret, stderr, "Error in BB: bb_write_single_record: fputs MIDDLE\r\n");
        }

        appClient.bb.bb_fops.wr_pos = ftell(fp_bb);
		IOBD_DEBUG_LEVEL2 ("appClient.bb.bb_fops.wr_pos is %ld", appClient.bb.bb_fops.wr_pos);
                                                                                            
	if ((appClient.bb.bb_fops.wrap_bit_fg == 0) && (appClient.bb.bb_fops.bytes_written + rec_sz > appClient.bb.bb_fops.total_avail_bytes))
                appClient.bb.bb_fops.wrap_bit_fg = 1;

        if (appClient.bb.bb_fops.bytes_written < appClient.bb.bb_fops.total_avail_bytes)
                appClient.bb.bb_fops.bytes_written += rec_sz;

	/*Release*/
	sem_post(&appClient.bb.rw_lock);
	IOBD_DEBUG_LEVEL2 ("appClient.bb.bb_fops.bytes_written is %ld", appClient.bb.bb_fops.bytes_written);
#if 0
        if ((appClient.bb.bb_fops.wrap_bit_fg == 0) && (appClient.bb.bb_fops.bytes_written == appClient.bb.bb_fops.total_avail_bytes))
                appClient.bb.bb_fops.wrap_bit_fg = 1;
#endif
        return OBD2_APP_SUCCESS;
}

int bb_get_record_sz (blackbox_t *p_bb)
{
        return (p_bb == NULL)? E_BB_ARG_INVALID: p_bb->bb_fops.record_sz;
}

int bb_read_single_record (FILE *fp_bb, char *p_rec, int rec_sz)
{
        char *tmp_buf;
        long int f_wr_off;
        int ret;
	char *st;
        /*!< Wait till release and lock*/
        sem_wait(&appClient.bb.rw_lock);
        /*!< Check input argument validation */
        //if (fp_bb == NULL || p_rec == NULL || (rec_sz > appClient.bb.bb_fops.record_sz))
        if (fp_bb == NULL || p_rec == NULL)
                return E_BB_ARG_INVALID;

	/*!< Blackbox data read completely return immediately */
	if (appClient.bb.bb_fops.bytes_written == 0){
		IOBD_DEBUG_LEVEL2 ("No bytes available to read");
		return E_BB_NO_DATA;
	}

        if ((appClient.bb.bb_fops.rd_pos < appClient.bb.bb_fops.wr_pos) && (appClient.bb.bb_fops.wrap_bit_fg == 1)){
                appClient.bb.bb_fops.rd_pos = appClient.bb.bb_fops.wr_pos;
                appClient.bb.bb_fops.wrap_bit_fg = 0;
        }
#if 0   
        if ((appClient.bb.bb_fops.bytes_written == appClient.bb.bb_fops.total_avail_bytes) && (appClient.bb.bb_fops.wrap_bit_fg == 1)){
                appClient.bb.bb_fops.rd_pos = appClient.bb.bb_fops.wr_pos;
                appClient.bb.bb_fops.wrap_bit_fg = 0;
        }
#endif
	/*!< Positioning the read pointer */
        fseek(fp_bb, appClient.bb.bb_fops.rd_pos, SEEK_SET);
	/*!< Reading the record */
        fgets (p_rec, rec_sz, fp_bb);
	
	IOBD_DEBUG_LEVEL2 ("blackbox_read : buf %s",p_rec);
	rec_sz = strlen (p_rec);
	/*!< Checking whether it a proper record */
	st = strstr (p_rec, "$");
	/*!< If not a proper record read the next record */
	if (st == NULL){
		fgets (p_rec, rec_sz, fp_bb);
		IOBD_DEBUG_LEVEL2 ("blackbox_read : buf %s",p_rec);
		rec_sz += strlen (p_rec);	
	}

        //appClient.bb.bb_fops.rd_pos += appClient.bb.bb_fops.record_sz;
	/*!< Updating the next Read position to the read_pointer */
        appClient.bb.bb_fops.rd_pos = ftell (fp_bb);
	IOBD_DEBUG_LEVEL2 ("blackbox_read : appClient.bb.bb_fops.rd_pos is %ld",appClient.bb.bb_fops.rd_pos);
	/*!< Subtracting the bytes read from bytes written */
        appClient.bb.bb_fops.bytes_written -= rec_sz;
	IOBD_DEBUG_LEVEL2 ("blackbox_read : appClient.bb.bb_fops.bytes_written %lu",appClient.bb.bb_fops.bytes_written);
        if (appClient.bb.bb_fops.rd_pos == appClient.bb.bb_fops.total_avail_bytes)
                appClient.bb.bb_fops.rd_pos = 0;

	        fseek(fp_bb, appClient.bb.bb_fops.wr_pos, SEEK_SET);

	/*!< Release the r/w lock */
        sem_post(&appClient.bb.rw_lock);

        return OBD2_APP_SUCCESS;
}

/*!< function header */
int check_file_size (const char *file_name, long int *sz)
{
    struct stat st; /*declare stat variable*/
    int ret;

    /*!< Check input arguments */
    if ((file_name == NULL) || (sz == NULL))
        return E_BB_ARG_INVALID;

    /*get the size using stat()*/
    if(stat(file_name,&st)==0){
        *sz = st.st_size;
        ret = OBD2_APP_SUCCESS;
    }
    else {
        ret = E_BB_FILE_SZ;
    }

    return ret;
}
	
