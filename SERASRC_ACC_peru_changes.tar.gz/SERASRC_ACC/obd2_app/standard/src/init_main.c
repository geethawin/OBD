#include "application.h"
#include "init_callbacks.h"
#include "stdlib.h"
#include "standard.h"

int main()
{
	int rc = -1;
	short ret = 0;
	struct obd_data obddata;
	int len;
	char command[256];
	char ts[64] = {0};
	int index = 0;
	struct gps_pkt g_gps;
	car_parameters car_para;
	accelerometer_api_priv acc;

	IGN_PTRS Ign;
	SLEEP_WAKE sw;

	Ign.ign_ON    = main_ign_on;
	Ign.ign_OFF   = main_ign_off;
	Ign.dis_stat  = main_dis_stat;
	Ign.bat_drain = main_bat_drain;
	Ign.pnc_btn   = main_pnc_btn;	
	Ign.crash_det = main_crash_det;
	sw.slp 	      = sys_sleep;
	sw.wake	      = sys_wake;
	sw.slp_dis    = sys_wake_dis;

	//catch interrupt signal
	signal(SIGINT, sigHandler);
	signal(SIGTERM, sigHandler);

#if 1
	if (init_mq_usb() == -1)
	{
		IOBD_DEBUG_LEVEL1 ("Cloud Message Queue Create Failed\r\n");
	}
#endif
	if (init_mq() == -1)
	{
		IOBD_DEBUG_LEVEL1 ("Cloud Message Queue Create Failed\r\n");
	}
	/* Init Semaphore*/
	if (sem_init(&dmClient.gps_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL1("GPS_Sem Create Failed\r\n");
	}
	/* Init Semaphore*/
	if (sem_init(&dmClient.rns_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL1("Read_n_Send_Sem Create Failed\r\n");
	}


	/* Init Semaphore*/
	if (sem_init(&dmClient.obd_q_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL1("OBD_Q_Sem Create Failed\r\n");
	}

	/* Init Semaphore*/
	if (sem_init(&dmClient.obd_cloud_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL1("OBD_cloud_Sem Create Failed\r\n");
	}
#ifdef BLACKBOX
	/*Semaphore for blackbox read/write*/	
	if (sem_init(&appClient.bb.rw_lock, 1, 1) == -1)
	{
		IOBD_DEBUG_LEVEL1("BB_R_W_lock_Sem Create Failed\r\n");
	}
#endif

#ifdef _XLS__EN_
	rc = init(&Ign,&sw,&standard_cli.xls_objs);
#else
	rc = init(&Ign,&sw,&standard_cli.xml_objs);
#endif
	if (rc == -1)
		IOBD_DEBUG_LEVEL1("init failed\n");
	rc = update_io_function ();
	if (rc < 0)
        	IOBD_DEBUG_LEVEL1 ("update_io_function failed %d",rc);

	rc = hw_init();
	if(rc < 0)
	{
		IOBD_DEBUG_LEVEL1("hw_init failed \n");
		rc = -1;
		goto exit;
	}

	rc = analytics_init();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("analytics init failed %d",rc);

	rc = client_init(&dmClient);
	if (rc != 0)
		IOBD_DEBUG_LEVEL1("client_init failed\n");

	rc = start_pm_client();
	if (rc == -1)
		IOBD_DEBUG_LEVEL1("start_pm_client failed\n");
	
//	rc = send_notification ("start");

	rc = usb_app_init ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL2 ("usb_app_init failed\n");
	standard_cli.mode = check_mode();
#if ACC_ENABLE
	IOBD_DEBUG_LEVEL2 ("Accelerometer Enabled");	
	rc = acc_init();
	if (rc != 0)
		IOBD_DEBUG_LEVEL1("acc_init failed\n");
	//sensor_approximation(1);
#endif
#if GYRO_ENABLE	
	IOBD_DEBUG_LEVEL2 ("Gyroscope Enabled");	
	rc = gyro_init();
	if (rc != 0)
		IOBD_DEBUG_LEVEL1("gyro_init failed\n");
#endif

	if (standard_cli.mode == 1){
		rc = check_protocol();
		if (rc == 1)
			IOBD_DEBUG_LEVEL2 ("Protocol is propretary CAN\n");

		/* disconnection thread */
		rc = init_ign_dis_handler();
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("init_ign_dis_handler failed\n");


		/* get client configuration */
		rc = get_config(&dmClient);
		if (rc != 0)
			IOBD_DEBUG_LEVEL1("get_config failed\n");

		/* initialising cloud */
		rc = cloud_init(&dmClient);
		if (rc != 0)
			IOBD_DEBUG_LEVEL1("cloud_init failed\n");

		/* Indicate to library about client initialisation */
		server_connection_complete();

		standard_cli.led_switch = 0;
		dmClient.interrupt = 0;
		get_time(ts);

		rc = get_car_data(&standard_cli.g_carparams);
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("get_car_status failed\n");

		rc = convert_raw_data(&standard_cli.g_carparams);
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("convert_raw_data failed\n");

		rc = get_gps_data_wrapper(&standard_cli.g_gps);

		IOBD_DEBUG_LEVEL1("CD - Distance DTC clear %d \n",car_data.distance_dtc_clear);

		rc = total_odometer(car_data.distance_dtc_clear);// peru : to update odometer value in RESET and KEY_ON payload
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("total_odometer failed\n");
		memset(&g_gps,'\0',sizeof(struct gps_pkt));
#if 0
		/*Framing header once*/	
		rc = frame_actual_header(&packet_global,((config_azure *)(dmClient.cfg.server_cfg))->url);
		if(rc<0)
			printf("frame custom header failed \n");

		rc = frame_custom_header(&packet_global);
		if(rc<0)
			printf("frame custom header failed \n");
#endif
		rc = final_payload_frame (ts, &obddata, "RESET");
		if(rc<0)
			IOBD_DEBUG_LEVEL1("final_payload_frame failed \n");

		rc = publishEvent (obddata.data);

		if(rc<0)
			IOBD_DEBUG_LEVEL1("send data to server failed \n");

		rc = thread_init();
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("thread_init failed \n");


#ifdef _ANALYTICS_
		enable_analytics();	
#endif
	}
	//indicate_device_exit(standard_cli.t_handle[6]);
	indicate_device_exit();
	IOBD_DEBUG_LEVEL1("system sleeping...!!!\n");

exit:
	IOBD_DEBUG_LEVEL1("Application exiting with rc %d \n",rc);
	return 0;
}


