#include "application.h"
//#include "cloud.h"
#include "standard.h"
//#include <stdio.h>
//#include <stdlib.h>
#include <pthread.h>
//#include <string.h>
//#include <unistd.h>
//#include "usb_app.h"
pthread_t t_handle[5];

int client_init(Client * dmclient)
{
	dmclient->cfg.server_cfg = (void *)&cfg_azure;
	printf("server_cfg %p \n",(config_azure *)(dmClient.cfg.server_cfg));
	memset(&iotfclient,0,sizeof(iotfclient));
	dmclient->deviceClient = (Iotfclient *)&iotfclient;

	if (sem_init(&standard_cli.send_sem, 0, 1) == -1)
		printf("Sem init failed \n");

	return 0;
}

int get_config(Client * client)
{
	FILE* prop;
	char filename[20]="/device.cfg";
	char hostname[50]={0};
	char endpoint[50]={0};
	int rc = 0;
	char value[2];
	set_default_config();
#if 0
	prop = fopen(filename, "r");
	if (prop == NULL){
		printf("Config file not found at %s\n",filename);
		return -1;
	}
	char line[256];
	int linenum = 0;
#endif
	strncpy(((config_azure *)(dmClient.cfg.server_cfg))->time_zone,"UTC",3);
	char zone[128]={0};
	strcpy(zone,"ln -sf /usr/share/zoneinfo/");
	strcat(zone,((config_azure *)(dmClient.cfg.server_cfg))->time_zone);
	strcat(zone, " /etc/localtime");

	system(zone);
	rc = get_cloud_config ();
#if 0
	while (fgets(line, 256, prop) != NULL) {
		char* prop;
		char* value;

		linenum++;
		if (line[0] == '#')
			continue;

		prop = strtok(line, "=");
		trim(prop);

		value = strtok(NULL, "\n");
		trim(value);

		IOBD_DEBUG("prop %s values %s \n",prop,value);
		if (strcmp(prop, "host") == 0)
			strncpy(hostname,value,50);
		if (strcmp(prop, "port") == 0)
			((config_azure *)(dmClient.cfg.server_cfg))->port = atoi(value);
		if (strcmp(prop, "deviceId") == 0)
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId,value,60);
		if (strcmp(prop, "deviceType") == 0)
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType,value,60);
		if (strcmp(prop, "IoTHubName") == 0)
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName,value,60);
		if (strcmp(prop, "sasToken") == 0)
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->sas,value,256);
		if (strcmp(prop, "transactionId") == 0)
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->transactionId,value,256);
		if (strcmp(prop, "total_fuel") == 0)
			((config_azure *)(dmClient.cfg.server_cfg))->fuel_used = atoi(value);
		if (strcmp(prop, "backup_battery_expire") == 0){

			int year = 0, month = 0, day = 0;
			strncpy(((config_azure *)(dmClient.cfg.server_cfg))->backup_battery_expire,value,60);

			if (sscanf(((config_azure *)(dmClient.cfg.server_cfg))->backup_battery_expire, "%4d-%2d-%2d", &year, &month, &day) == 3){

				struct tm breakdown = {0};
				breakdown.tm_year = year - 1900; /* years since 1900 */
				breakdown.tm_mon = month - 1;
				breakdown.tm_mday = day;
				breakdown.tm_hour = 0;
				breakdown.tm_min = 0;

				if ((standard_cli.i_btry_expire = mktime(&breakdown)) == (time_t)-1) {
					fprintf(stderr, "Could not convert time input to time_t\n");
					// return EXIT_FAILURE;
				}
				printf("Battery expiration date is %s \n",ctime(&standard_cli.i_btry_expire));

			}
			else{
				printf("The input was not a valid time format\n");
			}		
		}
		if (strcmp(prop, "work_time_start") == 0){

			set_start_work_time(value);

		}

		if (strcmp(prop, "work_time_end") == 0){

			set_end_work_time(value);

		}

	}
#endif
	get_imei_modem(((config_azure *)(dmClient.cfg.server_cfg))->deviceid);
	strcpy (hostname,((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	bzero (((config_azure *)(dmClient.cfg.server_cfg))->hostname,sizeof(((config_azure *)(dmClient.cfg.server_cfg))->hostname));
	if((strlen(((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName))>0){
		strcpy(endpoint,((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
		strcat(endpoint,".");
		strcat(endpoint,hostname);
	}

	else
		strcpy(endpoint,hostname);

	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->hostname,endpoint);

	char fullpath[256]={0};

	strcpy(fullpath,"https://");
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->hostname);

	strcat(fullpath,"/devices/");
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	strcat(fullpath,"/messages/events");

	printf("fullpath %s \n",fullpath);

	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->url,fullpath);

	printf("url %s \n",((config_azure *)(dmClient.cfg.server_cfg))->url);

	printf("id %s\n",((config_azure *)(dmClient.cfg.server_cfg))->deviceid);
	printf("hostname %s \n",((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	printf("port %d \n",((config_azure *)(dmClient.cfg.server_cfg))->port);
	printf("http_deviceId %s \n",((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	printf("http_deviceType %s \n",((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	printf("transactionId %s \n",((config_azure *)(dmClient.cfg.server_cfg))->transactionId);

	//fclose(prop);
	rc  = get_xml_content (SRC_XML_FILE, "general", "can_sign", value);
	standard_cli.usb_app.freq.f_can_sign = atoi (value);
	rc  = get_xml_content (SRC_XML_FILE, "general", "sampling_frequency", value);
	standard_cli.usb_app.freq.f_sampling = atoi (value);
//	evt_limits ();

	printf("out get_config()\n");
	return 0;
}

int get_cloud_config ()
{
	char port [10];
	printf("get_cloud_config +");
	bzero (port,sizeof(port));
	/* Get parameters from XML file. */
	printf ("host\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "host", ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	printf ("port\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "port", port);
	printf ("deviceid\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "device_id", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	printf ("device_type\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "device_type", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	printf ("iot_hub_name\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "iot_hub_name", ((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
	printf ("sas_token\n");
	get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "sas_token", ((config_azure *)(dmClient.cfg.server_cfg))->sas);

	printf ("port_atoi\n");
	((config_azure *)(dmClient.cfg.server_cfg))->port = atoi(port);

	IOBD_DEBUG_LEVEL3 ("Hostname = %s", ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	IOBD_DEBUG_LEVEL3 ("Port = %d", ((config_azure *)(dmClient.cfg.server_cfg))->port);
	IOBD_DEBUG_LEVEL3 ("Http_device_id = %s", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	IOBD_DEBUG_LEVEL3 ("Http_deviceType = %s", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	IOBD_DEBUG_LEVEL3 ("IoTHubNam = %s", ((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
	IOBD_DEBUG_LEVEL3 ("sas = %s", ((config_azure *)(dmClient.cfg.server_cfg))->sas);
	printf("get_cloud_config -");

	return OBD2_APP_SUCCESS;
}
void set_default_config()
{
#if 0	
	char ST[] = "10:00:00";
	printf("Setting Default start work time to 10.00 AM\n");
	set_start_work_time(ST);


	char ET[] = "18:00:00";
	printf("Setting Default end work time to 18.00 HRS\n");
	set_end_work_time(ET);
#endif
	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->transactionId,"a2dc7095-fbb5-47ad-96a5-9ca3e8a97720");

	((config_azure *)(dmClient.cfg.server_cfg))->port = 443;

}
void set_start_work_time(char * time)
{

	char *p=NULL;

	strncpy(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start,time,strlen(time));

	p = (char *)strptime(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start,"%H:%M",&standard_cli.work_start_time);
	if(p==NULL)
	{
		printf("Invalid format. Setting Default to 10.00 AM\n");
		const char T[] = "10:00:00";
		memset(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start,0,sizeof(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start));

		strncpy(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start,T,strlen(T));
		p = (char *)strptime(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_start,"%H:%M",&standard_cli.work_start_time);
		mktime(&standard_cli.work_start_time);		
	}
	else
	{
		mktime(&standard_cli.work_start_time);
	}
	printf("H %d M %d \n",standard_cli.work_start_time.tm_hour,standard_cli.work_start_time.tm_min);
}

void set_end_work_time(char * time)
{

	char *p=NULL;

	strncpy(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end,time,strlen(time));

	p = (char *)strptime(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end,"%H:%M",&standard_cli.work_end_time);
	if(p==NULL)
	{
		printf("Invalid format. Setting Default to 10.00 AM\n");
		const char T[] = "10:00:00";
		memset(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end,0,sizeof(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end));

		strncpy(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end,T,strlen(T));
		p = (char *)strptime(((config_azure *)(dmClient.cfg.server_cfg))->cfg_work_time_end,"%H:%M",&standard_cli.work_end_time);
		mktime(&standard_cli.work_end_time);
	}
	else
	{
		mktime(&standard_cli.work_end_time);
	}
	printf("H %d M %d \n",standard_cli.work_end_time.tm_hour,standard_cli.work_end_time.tm_min);
}



size_t
RecvResponseCallback ( char *ptr, size_t size, size_t nmemb, char *data ) {
	// handle received data
	printf("callback data %s \n",data);
	return size * nmemb;
}


char gData[512];
static size_t HandleResponse(
		void *Ptr,
		size_t Size,
		size_t NoElements,
		void* Data )
{
	int gDataLen = 0;
	memcpy( &( gData[0] ), Ptr, (Size * NoElements) );
	gDataLen += (Size * NoElements);
	gData[ gDataLen ] = '\0';
	return (Size * NoElements);
}

int cloud_init (Client * client)
{
	((Iotfclient *)(dmClient.deviceClient))->o_init_state = 1;
	int rc = 0;
	char url[128]={0};
	
	printf("cloud_init + \n");
	curl_global_init(CURL_GLOBAL_ALL);
	((Iotfclient *)(dmClient.deviceClient))->curl = curl_easy_init();
	curl_easy_setopt( ((Iotfclient *)(dmClient.deviceClient))->curl,CURLOPT_CAINFO,"/etc/ssl/certs/ca-bundle.crt");
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_VERBOSE, 1);
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_HEADERFUNCTION,HandleResponse );
	strcpy(url,((config_azure *)(dmClient.cfg.server_cfg))->url);
	strcat(url,"?api-version=2016-02-03");
	printf("cloud_init url %s \n",url);
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_URL,url);
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_WRITEFUNCTION, RecvResponseCallback );

	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_CONNECTTIMEOUT, 5L);
	curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_TIMEOUT, 6L);

	printf("cloud_init - \n");
	return 0;       

}

int cloud_deinit()
{
	int rc = 0;
	printf(" client_deinit %d +\n",(((Iotfclient *)(dmClient.deviceClient))->o_init_state));

	if((((Iotfclient *)(dmClient.deviceClient))->o_init_state) != 0)
	{
		printf("system ignition off in sys_sleep() cloud_deinit \n");

		((Iotfclient *)(dmClient.deviceClient))->o_init_state = 0;

	}

	return rc;
}


int retry_connection(Iotfclient *client)
{
	/* ToDo */
	int rc = 0;
#if 0
	rc = aws_iot_mqtt_attempt_reconnect((AWS_IoT_Client *)client);

	printf("aws_iot_mqtt_attempt_reconnect %d \n",rc);

	if(rc!=SUCCESS && rc!= NETWORK_RECONNECTED){
		rc = -1;
		printf("connection retry failed \n");
		goto exit;
	}
	else{
		rc=0;
		printf("Network reconnected \n");
	}
#endif
exit:
	return rc;
}

#if 0
void iot_subscribe_callback_handler(AWS_IoT_Client *pClient, char *topicName, uint16_t topicNameLen,
		IoT_Publish_Message_Params *params, void *pData) {
	IOT_UNUSED(pData);
	IOT_UNUSED(pClient);
	IOT_INFO("Subscribe callback");
	IOT_INFO("%.*s\t%.*s", topicNameLen, topicName, (int) params->payloadLen, params->payload);
}

void disconnectCallbackHandler(AWS_IoT_Client *pClient, void *data)
{
	IOT_WARN("MQTT Disconnect");
	IoT_Error_t rc = FAILURE;
	if(NULL == pClient) {
		return;
	}

	IOT_UNUSED(data);

	if(aws_iot_is_autoreconnect_enabled(pClient)) {
		IOT_INFO("Auto Reconnect is enabled, Reconnecting attempt will start now");
	} else {
		IOT_WARN("Auto Reconnect not enabled. Starting manual reconnect...");
		pthread_t dis_tid;
		//rc = aws_iot_mqtt_attempt_reconnect(pClient);
		if (pthread_create(&(dis_tid), NULL, (void*) reconnect_thread, NULL) != 0) {
			printf(" pthread_create for reconnect_thread status failed. Closing APP \r\n");
			return;
		}
		if(NETWORK_RECONNECTED == rc) {
			IOT_WARN("Manual Reconnect Successful");
		} else {
			IOT_WARN("Manual Reconnect Failed - %d", rc);
		}
	}
}
#endif
//void try_reconnect
void reconnect_cloud(void)
{
	printf(" reconnect thread\r\n");

#if 0
	int rc = 0;
	do{
		IOT_WARN("try Manual Reconnect - %d \n");

		rc = aws_iot_mqtt_attempt_reconnect(&dmClient.deviceClient);

		IOT_WARN("try Manual Reconnect rc is %d \n",rc);

		if(NETWORK_RECONNECTED == rc) {
			IOT_WARN("Manual Reconnect Successful");
			disconnected = 0;
		} else {
			IOT_WARN("Manual Reconnect Failed - %d", rc);
		}
		sleep(1);
		rc = retry_connection((Iotfclient *)dmClient.deviceClient);
		if(rc!=0)
			sleep(1);

	}while(rc!=0);
	printf(" reconnect thread rc %d\r\n",rc);

#endif
}

int get_host_by_name(Client * client,char * hostname)
{
	int rc = 0;
	int i = 0;
	struct hostent *he;
	struct in_addr **addr_list;
	//    char *hostname1 = "google.com";

	printf(" get_host_by_name ++ \n");

	printf(" get_host_by_name hostname %s \n",hostname);

#if 1
	if ((he = gethostbyname(hostname)) == NULL) 
	{  // get the host info
		sleep(2);
		printf("Error gethost by name");
		strcpy(((config_azure *)(dmClient.cfg.server_cfg))->hostname,hostname);
		rc = -1;
		goto exit;
	}
#endif
	//rc = gethostbyname_wrapper(he,hostname1);
	sleep(2);
	printf(" gethostbyname returned with rc %d  \n",rc);

	// print information about this host:
	//printf("Host name is: %s\n", he->h_name);
	printf("IP address: ");
	addr_list = (struct in_addr **)he->h_addr_list;
	for(i = 0; addr_list[i] != NULL; i++) {
		strcpy(((config_azure *)(dmClient.cfg.server_cfg))->hostname, (const char *)inet_ntoa(*addr_list[i]));
		printf("%s",((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	}
	printf("\n");
exit:
	return rc;
}
void get_time_zone(char * zone)
{
	printf("timezone %s \n",((config_azure *)(dmClient.cfg.server_cfg))->time_zone);
	strcpy(zone,((config_azure *)(dmClient.cfg.server_cfg))->time_zone);
}


