#include "application.h"
#include "standard.h"
#include "standard_pkt_process.h"
#include <netdb.h>

int close_current_session()
{

	int rc = 0;
	/* To avoid sending packets after k_off */
	deinit_mq();

	/* SDK takes some time to send the data to cloud, so sleep for 1 second */
	sleep(1);

#if 0	
	rc = cloud_deinit();	
	if(rc < 0)
		printf(" cloud_deinit failed with rc %d \n",rc);
#endif
	return rc;

}


int process_data_packets(){

	int len = 0;
	struct obd_data obddata;
	int rc = 0,link = 0;
	static uint8_t key_off_sent = 0;
	struct hostent *hostinfo;
        char *hostname = "google.com";

	while (!dmClient.interrupt)
	{

		len = mq_receive(dmClient.obd_queue_id,(char *) &obddata, sizeof(struct obd_data),NULL);

retry:
		if(appClient.appSleep == APP_SLEEP && key_off_sent == 1)
			break;
	
		printf(" Receive len = %d, errno =%d\r\n",len,errno);

		if (access("/dev/ttyUSB4",F_OK))		
			break;
		printf("msg_type = %d\r\n", obddata.msg_type);
		printf("Receive Data = %s\r\n", obddata.data);

		switch(obddata.msg_type)
		{	
			case CAN_SIGN:
				rc = publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" CAN_SIGN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case SAMPLING:
				rc = publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" SAMPLING publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				printf("SAMPLING Event Sent\n");
				break;

			case KEY_ON:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" KEY_ON publishEvent Failed rc= %d\r\n",rc);
#if 0
					link = check_connection();
					if (link){
						hostinfo = gethostbyname (hostname);
				                if (hostinfo == NULL){
                        				IOBD_DEBUG_LEVEL2 ("no internet connection");
							system ("killall pppd");
							perror ("killall");
						}
						else
                        				IOBD_DEBUG_LEVEL2 ("internet connection is there");
					}
#endif
					sleep(1);
					goto retry;
				}
				key_off_sent = 0;
				break;

			case KEY_OFF:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" KEY_OFF publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				key_off_sent = 1;
				/*Indicate to library about ignition_off*/
				indicate_ignition_off_completed();
				break;

			case EXCHNG_SIM:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf("EXCHNG_SIM publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case PNC_BTN:
                                rc= publishEventWrapper(obddata.data);
                                printf("after PNC_BTN rc: %d\r\n", rc);
                                if (rc != OBD2_APP_SUCCESS) {
                                        printf(" PNC_BTN publishEvent Failed rc= %d\r\n",rc);
                                        sleep(1);
                                        goto retry;
                                }
                                break;

			case MB_RN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf("MB_RN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case BB_EN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf("BB_EN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
			
			case BLCK_OFF:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" BLCK_OFF publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
			case BB_FN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" BB_FN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
				/*keshav st*/
			case BB_LWN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					printf(" BB_LWN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
				/*keshav end*/
			default :
				printf(" Wrong message_type\r\n");
		}
		if (key_off_sent == 1){
			key_off_sent = 0;
			break;
		}
	}
		printf("process_data_packets exits\n");
}
