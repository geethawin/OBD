#include "application.h"
#include "common.h"
#include "accelerometer.h"
#include "gyroscope.h"
#include "stdio.h"

int frame_disconnect_pkt_in_json( char * buffer,char * ts,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ttl\":%d}",ts,dmClient.cfg.deviceid,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s}",ts,dmClient.cfg.deviceid);
	}

	return 0;
}


int frame_k_on_pkt_in_json( char * buffer,char * ts,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ttl\":%d}",ts,dmClient.cfg.deviceid,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s}",ts,dmClient.cfg.deviceid);
	}

	return 0;
}

int frame_k_off_pkt_in_json( char * buffer,char * ts,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ttl\":%d}",ts,dmClient.cfg.deviceid,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s}",ts,dmClient.cfg.deviceid);
	}

	return 0;
}

int frame_bat_drain_pkt_in_json( char * buffer,char * ts,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ttl\":%d}",ts,dmClient.cfg.deviceid,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s}",ts,dmClient.cfg.deviceid);
	}

	return 0;
}

int frame_gps_pkt_in_json(char * buffer,struct gps_rmc_t * gps_rmc,char * ts,int ttl)
{
	if(ttl){
		if (gps_rmc->gps_valid == 1){
			sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"v\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,gps_rmc->gps_valid,ttl);
		}
		else{
			if(gps_rmc->gps_init_fix == 0){
				sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"v\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->gps_valid,ttl);
			}
			else{
				sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"v\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,0,ttl);			
			}
		}
	}
	else{
		if (gps_rmc->gps_valid == 1){
			sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"v\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,gps_rmc->gps_valid);
		}
		else{
			if(gps_rmc->gps_init_fix == 0){
				sprintf(buffer,"{\"ts\":%s,\"imei\":%s,\"v\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->gps_valid);
			}
			else{
				sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"v\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,0);			
			}
		}		
	}
	return 0;
}

int frame_car_status_pkt_in_json( char * buffer,char * ts,_car_data * c_data,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ambienttemp\":%f,\"engine_load\":%f,\"distance_dtc_clear\":%f,\"rpm\":%f,\"Speed\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,c_data->air_temp,c_data->engine_load,c_data->distance_dtc_clear,c_data->rpm,c_data->veh_speed,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ambienttemp\":%f,\"engine_load\":%f,\"distance_dtc_clear\":%f,\"rpm\":%f,\"Speed\":%f}",ts,dmClient.cfg.deviceid,c_data->air_temp,c_data->engine_load,c_data->distance_dtc_clear,c_data->rpm,c_data->veh_speed);
	}

	return 0;
}

int frame_dtc_pkt_in_json(char * buffer,char * ts,char * dtc_values,int ttl)
{
	printf("frame dtc 1 \n");
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"ttl\":%d",ts,dmClient.cfg.deviceid,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s",ts,dmClient.cfg.deviceid,ttl);
	}
	printf("frame dtc 2 \n");
	strcat(buffer,",\"dtc_code\" : \"");
	strcat(buffer, dtc_values);
	strcat(buffer, "\"}");
	printf("frame dtc 3 \n");
	return 0;
}

int frame_acc_pkt_in_json(char * buffer,char * ts,accelerometer_api_priv * adata,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"x-axis\":%d,\"y-axis\":%d,\"z-axis\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,adata->x,adata->y,adata->z,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"x-axis\":%d,\"y-axis\":%d,\"z-axis\":%d}",ts,dmClient.cfg.deviceid,adata->x,adata->y,adata->z);
	}

	return 0;
}

int frame_gyro_pkt_in_json(char * buffer,char * ts,gyroscope_api_priv * gdata,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"x-axis\":%f,\"y-axis\":%f,\"z-axis\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gdata->x,gdata->y,gdata->z,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"x-axis\":%d,\"y-axis\":%d,\"z-axis\":%d}",ts,dmClient.cfg.deviceid,gdata->x,gdata->y,gdata->z);
	}
	return 0;
}

int frame_p_odo_pkt_json(char * buffer,char * ts,int dist,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"p_odo\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,dist,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"p_odo\":%d}",ts,dmClient.cfg.deviceid,dist);
	}

	return 0;
}

int frame_t_avg_spd_pkt_json(char * buffer,char * ts,int dist,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"avg_spd\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,dist,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"avg_spd\":%d}",ts,dmClient.cfg.deviceid,dist);
	}

	return 0;
}

int frame_fuel_consumption_pkt_in_json(char * buffer,char * ts,float fuel,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"fuel\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,fuel,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"fuel\":%f}",ts,dmClient.cfg.deviceid,fuel);
	}

	return 0;
}

