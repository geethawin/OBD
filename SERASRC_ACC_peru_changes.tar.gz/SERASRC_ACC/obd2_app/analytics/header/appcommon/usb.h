#ifndef __USB_STD_QUEUE__
#define __USB_STD_QUEUE__
#include <mqueue.h>
#include <sys/resource.h>

#define Q_MAX_MESSAGES 	65535
#define MAX_MSG_SIZE	256

#define SRC_XML_FILE          	"/sample.xml"
#define PARENT_NODE_CLOUD 	"cloud_azure"
#define PARENT_NODE_FREQ       	"general"
#define PARENT_NODE_SIM       	"sim_config"
#define SAMPLE_FREQ		"sampling_frequency"	
#define CAN_SIGN_FREQ		"can_sign"	
#define PARENT_NODE_BRK		"harsh_brake"
#define PARENT_NODE_ACC		"harsh_acceleration"
#define PARENT_NODE_CRASH	"crash"
#define PARENT_NODE_HARSH	"harsh"
#define PARENT_NODE_OSPD	"overspeed"
#define PARENT_NODE_OTEMP       "over_temp"
#define PARENT_NODE_RPM		"rpm"
#define PARENT_NODE_IDL		"idle_time"
#define PARENT_NODE_ODO		"odometer"
#define PARENT_NODE_FAT		"fatige_detection"
#define PARENT_NODE_DOUT1	"dout1"
#define PARENT_NODE_DOUT2	"dout2"
#define PARENT_NODE_DIN1	"din1"
#define PARENT_NODE_DIN2	"din2"
#define FIELD_NAME_SRC		"source"		
#define FIELD_NAME_THRESH	"threshold"
#define FIELD_NAME_BASE		"base_value"
#define FIELD_NAME_DUR		"duration"
#define FIELD_NAME_APN          "apn_name"
#define FIELD_NAME_ACCESS_PT    "access_point"
#define FIELD_NAME_PASS_REQ     "password_required"
#define FIELD_NAME_USER_NAME    "sim_username"
#define FIELD_NAME_PASSWORD     "sim_password"
#define FIELD_NAME_SIM_MODE     "mode"
#define FIELD_NAME_FLIGHT       "flight_mode"

/*USB APPLICATION NOTIFICATION*/
#define SIM_CONFIG_REQ    (0x025B)
#define CLOUD_CONFIG_REQ  (0x02B2)
#define GEN_SETTING_REQ   (0x02C1)
#define THRESHOLD_SET_REQ (0x02C3)
#define IO_CONFIG_REQ     (0x02C5)
#define FIRMWARE_UPGRADE  (0x07A0)
#define BLACK_BOX	  (0x07B1)
#define AUTOMODE          (1)
#define MODE_TYPE_2G	  (2)
#define MODE_TYPE_3G      (3)
	
#define SRC_ACCELEROMETER 1
#define SRC_VEHICLE_SPEED 2 
#define SRC_GYROSCOPE	  2
#define SRC_GPS	  	  1


typedef struct mesg_buffer {
	unsigned short type; /*!< notification*/
} mesg_buffer_t;

typedef struct __FREQ__
{
	short f_sampling;
	short f_can_sign;

}FREQ;

typedef struct __SOURCE__
{
	uint8_t h_brk;
	uint8_t h_acc;
	uint8_t crash;
	uint8_t harsh;
	uint8_t o_spd;
}SOURCE;

typedef struct __LIMIT__
{
	double h_brk;
	double h_acc;
	double crash;
	double harsh;
	double rpm;
	int o_spd;
	int idle;
	int tot_odo;
	int fat;
	double o_temp;
}LIMIT;

typedef struct __SIM_CONF__
{
	char apn[64];
	char access_pt[64];
	int is_password_req;
	char user_name[64];
	char pass_word[64];
	int mode;
	int is_flight_mode_set;
}SIM_CONF;

typedef struct __IO__
{
	short dout1[2];
	short dout2[2];
	short din1;
	short din2;
	short ain1;
}IO;

typedef struct __USB__APP__ {
	mqd_t usb_q_id;
	pthread_t usb_thread_id;
	mesg_buffer_t usb_msg_buf;
	FREQ freq;
	SOURCE src;
	LIMIT limit;
	IO io;
	SIM_CONF sim_conf;
}USB_APP;
 
USB_APP usb_app;

mqd_t usb_mq_init();
void usb_mq_deinit(mqd_t);
int send_usb_msg_q (mqd_t, struct mesg_buffer);
int recv_usb_msg_q (mqd_t, struct mesg_buffer *, size_t);
void usb_notification_thread (void);
#endif
