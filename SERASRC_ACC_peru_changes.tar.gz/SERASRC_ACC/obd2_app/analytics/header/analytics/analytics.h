#ifndef __ANALYTICS__
#define __ANALYTICS__

#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <pthread.h>

#define __BUZZER__
#define BUZZER_ON   1
#define BUZZER_OFF  0
#define BUZZER      0

typedef enum QoS {
        QOS0 = 0,
        QOS1 = 1
} QoS;

pthread_t a_handle[4];

typedef struct o_rpm_data{
	double rpm_threshold;
	int mode_idle;
	int mode_ride;	
}o_rpm_data;

typedef struct o_spd_data{
	int o_spd_threshold;
	struct timeval sot,eot;
	int duration;
	int trigger;
	int is_o_spd;
}o_spd_data;

typedef struct ftg_data{
	int ftg_threshold;
	struct timeval sot,eot;
	int duration;
	int drive_start;
}ftg_data;

typedef struct idle_data{
	int idle_threshold;
	struct timeval sot,eot;
	int duration;
	int idle_start;
	int car_idle_on;
}idle_data;

typedef struct h_acc_brk_data{
	double acc_threshold;
	double brk_threshold;
	double prev_speed;
	double cur_speed;
	double acc;	
}h_acc_brk_data;

typedef struct crash_data{
	double crash_threshold;
	double prev_speed;
	double cur_speed;
	double acc;	
}crash_data;

typedef struct h_crn_data{
	double dps_threshold;
}h_crn_data;

typedef struct t_odo_data{
        double tot_odometer;
}t_odo_data;

typedef struct o_temp_data{
	double o_temp_threshold;
	int notify;
}o_temp_data;

typedef struct digitial_input_data{
	int saved_state;
}digitial_input_data;

typedef struct panic_btn_data{
	int saved_state;
}panic_btn_data;

typedef struct time_fence_data{
	int notify;
}time_fence_data;


typedef struct _analytics{
	h_acc_brk_data h_acc_brk;
	crash_data crash;
	o_spd_data o_spd;
	ftg_data ftg;
	idle_data idle;
	o_rpm_data o_rpm;
	h_crn_data h_crn;
	t_odo_data t_odo;
	o_temp_data o_temp;
	digitial_input_data d_input;
	panic_btn_data p_btn;
	time_fence_data t_fence;
	accelerometer_api_priv g_adata;
}_analytics;

_analytics i_analytics;

int analytics_thread_init();
void a_pkt_process_thread(void);
void analytics_thread_l1 (void);
void analytics_thread_l2 (void);
void analytics_thread_l3 (void);
int car_data_analytics(double,double,int);
int harsh_cornering (double *);
int harsh_cornering_acc (double *);
int over_temp_detection(double);
int check_digital_input();
int check_panic_btn();
int check_time_fence();
int get_p_btn_state(int *);
int get_d_input_state();
int analytics_init();
int sensor_approximation(int );
#endif
