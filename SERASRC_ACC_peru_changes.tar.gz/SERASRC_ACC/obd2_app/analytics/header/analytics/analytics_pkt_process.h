#ifndef __A_PKT_PROCESS__
#define __A_PKT_PROCESS__


#define SUCCESS 0

void process_analytics_data_packets();

#endif
