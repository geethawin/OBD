#ifndef __EVENT__
#define __EVENT__

#include <mqueue.h>
#include <semaphore.h>

#ifdef _XLS__EN_
typedef struct event_limits
{
char events[30];
int limit;
char units[20];
int no_of_evt;
}E_LIMIT;
extern E_LIMIT *elimit;
#endif
extern int fat_flag;

struct timeval sof;


typedef struct analytics{
	sem_t car_data_sem;
	sem_t analytics_q_sem;
	mqd_t analytics_queue_id;
}analytics;

analytics data_analytics;
void get_limit(void);
int over_speed_detection(double);
int rpm_detection (double,double);
int harsh_acc_braking (double);
int fatigue_detection (void);
int excess_idling (double,double);
int total_odometer (int);
int crash_detection (double);
int avg_trip_speed();
void critical_data_analytics();
int send_data_to_cloud(char *,int);
int evt_limits (void);
int update_io_function ();
int drive_gpio_state ();
int update_time_limit ();
#endif
