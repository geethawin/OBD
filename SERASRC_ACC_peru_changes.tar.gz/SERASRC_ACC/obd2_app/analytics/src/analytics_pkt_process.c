#include "application.h"
#include "analytics_pkt_process.h"
#include "analytics.h"
#include "analytics_events.h"


void process_analytics_data_packets(){

	int len = 0;
	struct obd_data obddata;
	int rc = 0;
	while (!dmClient.interrupt)
	{
		len = mq_receive(data_analytics.analytics_queue_id,(char *) &obddata, sizeof(struct obd_data),NULL);

		printf(" Receive len = %d, errno =%d\r\n",len,errno);
		printf("msg_type = %d\r\n", obddata.msg_type);
		printf("Receive Data = %s\r\n", obddata.data);

retry:
		if(appClient.appSleep == APP_SLEEP){
			break;
		}

		switch(obddata.msg_type)
		{
			case RPM_OVER:
				rc= publishEventWrapper(obddata.data);
				printf("after OVERRPM rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" OVERRPM publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case OVERSPEED:
				rc= publishEventWrapper(obddata.data);
				printf("after OVERSPEED rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" OVERSPEED publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 

			case OVERTEMP:
				rc= publishEventWrapper(obddata.data);
				printf("after OVERTEMP rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" OVERTEMP publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 
#if 0
			case PNC_BTN:
				rc= publishEventWrapper(obddata.data);
				printf("after PNC_BTN rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" PNC_BTN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 
#endif
			case CRASH:
				rc= publishEventWrapper(obddata.data);
				printf("after crash rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" crash publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case HARSH:
				rc= publishEventWrapper(obddata.data);
				printf("after crash rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" h_crn publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case HARSH_ACC:
				rc= publishEventWrapper(obddata.data);
				printf("after h_acc rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" h_acc publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case HARSH_BRK:
				rc= publishEventWrapper(obddata.data);
				printf("after h_brk rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" h_brk publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case JA_DT:
				rc= publishEventWrapper(obddata.data);
				printf("after ftg rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf("ftg publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case TAN:
				rc= publishEventWrapper(obddata.data);
				printf("after TAN rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf("TAN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case IDLE_ON:
				rc= publishEventWrapper(obddata.data);
				printf("after idl_on rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" idl_on publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;
			case IDLE_OFF:
				rc= publishEventWrapper(obddata.data);
				printf("after idl_off rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					printf(" idl_off publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			default :
				printf(" Wrong message_type\r\n");
		}
	}
			printf("process_analytics_data_packets exits\n");
}

