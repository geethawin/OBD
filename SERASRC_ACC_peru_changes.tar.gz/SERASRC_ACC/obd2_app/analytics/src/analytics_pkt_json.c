#include "application.h"
#include "analytics_pkt_json.h"
#include <stdio.h>

int frame_h_crn_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}


int frame_o_spd_pkt_json(char * buffer,char * ts,int vehicle_speed,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"spd\":%d,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,vehicle_speed,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"spd\":%d,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,vehicle_speed,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_h_acc_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_h_brk_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_crash_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_o_rpm_pkt_json(char * buffer,char * ts,int rpm,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"rpm\":%d,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,rpm,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"rpm\":%d,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,rpm,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_ftg_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_idle_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude);
	}

	return 0;
}

int frame_t_odo_pkt_json(char * buffer,char * ts,int tot_odometer,struct gps_rmc_t * gps_rmc,int ttl)
{
	if(ttl){
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"odo\":%d,\"ttl\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,tot_odometer,ttl);
	}
	else{
		sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"lt\":%f,\"ln\":%f,\"odo\":%d}",ts,dmClient.cfg.deviceid,gps_rmc->latitude,gps_rmc->longitude,tot_odometer);
	}
	return 0;
}


