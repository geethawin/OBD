#include "application.h"
#include "gyroscope.h"
#include "analytics.h"
#include "analytics_queue.h"
#include "analytics_events.h"
#include "analytics_pkt_process.h"
#include "analytics_pkt_json.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "xls.h"
#include <time.h>
#include "gpio.h"
#include "usb.h"
#ifdef _XLS__EN_
E_LIMIT *elimit = NULL;
#endif
int tot_odometer;
int fat_flag = 0;

int analytics_init()
{
	int rc = 0;
        rc = evt_limits ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("evt_limits failed %d",rc);
//	rc = update_io_function ();
//	if (rc < 0)
//		IOBD_DEBUG_LEVEL1 ("update_io_function failed %d",rc);
	rc = update_time_limit ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("update_time_limit failed %d",rc);
        /*set event limits as macro*/
        get_limit();

        /* Init Semaphore*/
        if (sem_init(&data_analytics.analytics_q_sem, 0, 1) == -1)
        {
                printf("Sem Create Failed\r\n");
                rc = -2;
        }

        if (init_an_mq() == -1)
        {
                printf("Message Queue Create Failed\r\n");
                rc = -3;
        }

	return rc;

}

int enable_analytics()
{
	int rc = 0;
#if 0
	evt_limits ();
	/*set event limits as macro*/
	get_limit();

	/* Init Semaphore*/
	if (sem_init(&data_analytics.analytics_q_sem, 0, 1) == -1)
	{
		printf("Sem Create Failed\r\n");
		rc = -1;
	}

	if (init_an_mq() == -1)
	{
		printf("Message Queue Create Failed\r\n");
		rc = -1;
	}
#endif
	if(analytics_thread_init()<0)
	{
		printf("init_analytics_thread failure \n");
		rc = -1;
	}
	else
	{
		printf("init_analytics_thread success \n");
	}

	return rc;
}

int analytics_thread_init()
{

	i_analytics.t_fence.notify = 0;

	if(pthread_create(&(a_handle[0]), NULL, (void*) a_pkt_process_thread, NULL) != 0){
		printf(" pthread_create for a_pkt_process_thread failed. Analytics data will not be available! \r\n");
		return -1;
	}
	else{
		printf("a_pkt_process_thread is created\n");
	}

	if(pthread_create(&(a_handle[1]), NULL, (void*) analytics_thread_l1, NULL) != 0){
		printf(" pthread_create for analytics_thread_l1 failed. Analytics data will not be available! \r\n");
		return -1;
	}
	else{
		printf("car_analytics_thread is created\n");
	}

	if(pthread_create(&(a_handle[2]), NULL, (void*) analytics_thread_l2, NULL) != 0){
		printf(" pthread_create for analytics_thread_l2 failed. Analytics data will not be available! \r\n");
		return -1;
	}
	else{
		printf("analytics_thread_l2 is created\n");
	}
#if 0
	/*commented for demo*/
	if(pthread_create(&(a_handle[3]), NULL, (void*) analytics_thread_l3, NULL) != 0){
		printf(" pthread_create for analytics_thread_l3 failed. Analytics data will not be available! \r\n");
		return -1;
	}
	else{
		printf("analytics_thread_l3 is created\n");
	}
#endif
	return 0;
}

int sensor_approximation(int op)
{
	
	double val=0.0;
	int i;
	printf("sensor approximation................\n");
	if (op == 1){
		for (i = 0;i < 5;i++){
			get_accelerometer (&i_analytics.g_adata);	
			val += i_analytics.g_adata.x;
		}
		i_analytics.h_acc_brk.acc_threshold += val/5;
		printf("sensor approx : acc_threshold %lf\n",i_analytics.h_acc_brk.acc_threshold);
	}
	else if (op == 2){
	//	get_gyroscope (&gyro);
	}
return 0;

}

void a_pkt_process_thread(void)
{
	process_analytics_data_packets();
}

void analytics_thread_l1 (void)
{
	int rc = 0;

	car_parameters carparams;

	i_analytics.h_acc_brk.prev_speed = -1;
	i_analytics.crash.prev_speed = -1;

	while(!dmClient.interrupt){
		printf("car_analytics_thread while + \n");
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
		get_car_data(&carparams);
		convert_raw_data(&carparams);
		printf("car_data.veh_speed  %lf car_data.rpm  %lf  car_data.distance_dtc_clear  %d\n",car_data.veh_speed,car_data.rpm,car_data.distance_dtc_clear);
		get_accelerometer (&i_analytics.g_adata);
		rc = car_data_analytics(car_data.veh_speed,car_data.rpm,car_data.distance_dtc_clear);

		if(rc < 0){
			printf("Analytics failed! \n");
		}
		printf("car_analytics_thread while - \n");
	}
	printf("analytics_thread_l1 exit \n");

}

void analytics_thread_l2 (void)
{

	char payload[128]={0};
	char ts[64]={0};
	struct obd_data obd_qdata;

#if GYRO_ENABLE
	double G;
#endif
	int ret = 0;
	int rc =0;
	int data_read = 0;

	
	while(!dmClient.interrupt){
		printf("analytics_thread_l2 while + \n");
		if(appClient.appSleep == APP_SLEEP){
			i_analytics.idle.car_idle_on = 0;
			i_analytics.idle.idle_start = 0;
			break;
		}
		data_read = 0;
#if GYRO_ENABLE
		if (usb_app.src.harsh == SRC_ACCELEROMETER)
			rc = harsh_cornering_acc (&G);
		else if (usb_app.src.harsh == SRC_GYROSCOPE)
			rc = harsh_cornering(&G);

		if (rc == 1){
			memset(payload,0,sizeof(payload));

			printf("**********************************HARSH CORNERING %f********************************\n",G);
			get_time(ts);

			if(data_read == 0){
				data_read = 1;
			}

			rc = final_payload_frame (ts, &obd_qdata, "HARSH");
			obd_qdata.msg_type = HARSH;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf(" HARSH send to server failed!\n");
			}

		}
#endif
		memset(payload,0,sizeof(payload));
		if(fatigue_detection ()== 1){
			get_time(ts);
			printf("********************************FATIGUE DETECTED************************************\n");

			if(data_read == 0){
				data_read = 1;
			}
			rc = final_payload_frame (ts, &obd_qdata, "JA_DT");
			obd_qdata.msg_type = JA_DT;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf(" JA_DT send to server failed!\n");
			}
		}

		memset(payload,0,sizeof(payload));
		ret = excess_idling(car_data.rpm,car_data.veh_speed);
		if(ret == 1){
			get_time(ts);
			printf("*************************************CAR IDLE ON************************************\n");

			if(data_read == 0){
				data_read = 1;
			}

			rc = final_payload_frame (ts, &obd_qdata, "IDLE_ON");
			obd_qdata.msg_type = IDLE_ON;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf(" IDLE_ON send to server failed!\n");
			}
		}
		if(ret == -1){
			get_time(ts);
			printf("*************************************CAR IDLE OFF***********************************\n");
			if(data_read == 0){
				data_read = 1;
			}

			rc = final_payload_frame (ts, &obd_qdata, "IDLE_OFF");
			obd_qdata.msg_type = IDLE_OFF;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf(" IDLE_OFF send to server failed!\n");
			}
		}

		memset(payload,0,sizeof(payload));
		if(total_odometer(car_data.distance_dtc_clear) == 1)
		{
			printf("*************************************TOTAL ODOMETER %d\n********************************",tot_odometer);
		}

		rc = over_speed_detection(car_data.veh_speed);
		if (rc == BUZZER_ON){
			get_time(ts);

			printf("************************** OVER SPEED ALERT-- %f*****************************\n",car_data.veh_speed);
			if(data_read == 0){
				data_read = 1;
			}

			rc = final_payload_frame (ts, &obd_qdata, "OVERSPEED");
			obd_qdata.msg_type = OVERSPEED;
			rc = send_msg_an_q(&obd_qdata);
#ifdef __BUZZER__
			/*Switch ON the Buzzer*/
			printf("in overspeed usb_app.io.dout1[0] %d usb_app.io.dout2[0] %d\n",usb_app.io.dout1[0], usb_app.io.dout2[0]);
			if (usb_app.io.dout1[0] == 2){
				set_gpio_value (36, BUZZER_ON);
			}
			else if (usb_app.io.dout2[0] == 2)
				set_gpio_value (38, BUZZER_ON);
#endif
			if(rc < 0)
			{
				printf("OVER SPEED ALERT data send to queue failed!\n");
			}
		}
		else if(rc == BUZZER_OFF) {
#ifdef __BUZZER__
			/*Switch OFF Buzzer*/
			if (usb_app.io.dout1[0] == 2){
			set_gpio_value (36, BUZZER_OFF);
			}
			else if (usb_app.io.dout2[0] == 2)
				set_gpio_value (38, BUZZER_OFF);
#endif
		}	

		if(over_temp_detection(car_data.Eng_cool_temp) == 1){
			get_time(ts);

			printf("************************** OVER TEMP ALERT-- %f*****************************\n",car_data.air_temp);

			if(data_read == 0){
				data_read = 1;
			}

			rc = final_payload_frame (ts, &obd_qdata, "OVERTEMP");
			obd_qdata.msg_type = OVERTEMP;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf("OVER TEMP ALERT data send to server failed!\n");
			}
		}

		memset(payload,0,sizeof(payload));


		usleep(200000);
		printf("analytics_thread_l2 while - \n");
	}
	printf("analytics_thread_l2 exit \n");
}


void analytics_thread_l3 (void)
{
	int rc = 0;

	while(!dmClient.interrupt){
		printf("analytics_thread_l3 while + \n");
		if(appClient.appSleep == APP_SLEEP){
			sleep(1);
			break;
		}

#if 0
		rc = check_digital_input();
		if(rc < 0)
		{
			printf("check_digital_input failed \n");
		}
#endif
		rc = check_panic_btn();
		if(rc < 0)
		{
			printf("check_digital_input failed \n");
		}
#if 0

		rc = check_time_fence();
		if(rc < 0)
		{
			printf("check_time_fence failed \n");
		}
#endif

		sleep(1);
	}

	printf("analytics_thread_l3 exit \n");

	return;
}


int check_time_fence(){


	time_t now;
	struct tm * tm_now;
	int rc = 0;
	char ts[64]={0};
	struct obd_data obd_qdata;
	//struct gps_pkt g_gps;
	//car_parameters carparam;
	//accelerometer_api_priv adata;

	char DESTZONE[256]={0};
	char time_zone[64]={0};

	if(!i_analytics.t_fence.notify){

		get_time_zone(time_zone);

		strcpy(DESTZONE,"TZ=");
		strcat(DESTZONE,time_zone);
		putenv(DESTZONE);                               // Switch to destination time zone

		now = time (NULL);
		tm_now = localtime (&now);

		rc = validate_time_fence(tm_now);
		if(rc == 1)
		{
			get_time(ts);

			//frame_o_spd_pkt_json(payload,ts,car_data.veh_speed,&gps_rmc,dmClient.ttl);
			printf("************************** TAN ALERT *****************************\n");
			//send_data_to_cloud(payload,OVERSPEED);
			//                        rc = read_req_data(&g_gps,&adata,ts);
			//                      if(rc < 0)
			//                    {
			//                          printf("read_req_data failed!\n");
			//                }

			//              rc = send_data_to_server(&g_gps,&carparam,ts,"TAN");

			strcpy(obd_qdata.data,ts);
			obd_qdata.msg_type = TAN;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf("TAN ALERT data send to server failed!\n");
			}
			else{
				i_analytics.t_fence.notify = 1;
			}

		}
	}
	else{

		printf("TAN ALERT already notified \n");
	}

	return 0;
}

int check_panic_btn(){
#if 0
	int rc = 0;
	char ts[64]={0};
	struct obd_data obd_qdata;
	static int prev_state = 0;
	
	prev_state = i_analytics.p_btn.saved_state;
		
	rc = get_p_btn_state(&i_analytics.p_btn.saved_state);
	if(rc < 0)
	{
		printf("Failed to read digital input state \n");
		goto exit;
	}
	else{
		if(i_analytics.p_btn.saved_state != prev_state){

			get_time(ts);
			printf("********************** PANIC BTN INPUT CHANGED from %d to %d **********************\n",rc,i_analytics.p_btn.saved_state);
			rc = final_payload_frame (ts, &obd_qdata, "PNC_BTN");
			obd_qdata.msg_type = PNC_BTN;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf("OVER PNC_BTNTEMP ALERT data send to server failed!\n");
			}
		}
	}

exit:
#endif
	return 0;

}

#if 0
int get_p_btn_state(int *pnc_btn_state)
{
	int ret;

	ret = get_gpio(PANIC_BTN, pnc_btn_state);

	IOBD_DEBUG_LEVEL1("panic button state = %d ret = %d \n",*pnc_btn_state,ret);
	if (ret == OBD2_APP_FAILURE)
		return OBD2_APP_FAILURE;
	else
		return OBD2_APP_SUCCESS;
}
#endif

int check_digital_input(){

	int rc = 0;
	char ts[64]={0};

	struct obd_data obd_qdata;

	rc = get_d_input_state();
	if(rc < 0)
	{
		printf("Failed to read digital input state \n");
		goto exit;
	}
	else{
		if(i_analytics.d_input.saved_state!=rc){

			get_time(ts);
			printf("********************* DIGITAL INPUT CHANGED from %d to %d *********************\n",i_analytics.d_input.saved_state,rc);
			i_analytics.d_input.saved_state = rc;
			strcpy(obd_qdata.data,ts);
			obd_qdata.msg_type = DGT_INP;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				printf("Digital Input ALERT data send to server failed!\n");
			}
		}
	}

exit:
	printf("check_digital_input \n");
	return 0;

}

int get_d_input_state()
{

	printf("get_d_input_state \n");
	return 0;
}

int over_temp_detection(double temp)
{
	int rc = 0;

	printf("over_temp_detection\n");
	if(temp > i_analytics.o_temp.o_temp_threshold){

		if(i_analytics.o_temp.notify == 0){
			i_analytics.o_temp.notify = 1;	
			printf("************************ OVERTEMP temp = %f**************************\n",temp);
			rc = 1;
		}
	}
	else{
		i_analytics.o_temp.notify = 0;
	}

	return rc;
}

int over_speed_detection(double speed)
{
	//printf("in overspeed detection\n");
	int rc = -1;
	int duration = 0;

	if(speed > i_analytics.o_spd.o_spd_threshold)
	{
		if(i_analytics.o_spd.is_o_spd == 0){
			if(i_analytics.o_spd.trigger!=1)
			{
				gettimeofday(&i_analytics.o_spd.sot,NULL);
				i_analytics.o_spd.trigger = 1;
			}
			else{
				gettimeofday(&i_analytics.o_spd.eot, NULL);
				duration = ((i_analytics.o_spd.eot.tv_usec - i_analytics.o_spd.sot.tv_usec) + (i_analytics.o_spd.eot.tv_sec - i_analytics.o_spd.sot.tv_sec)*1000000)/1000000;
			}
			printf("Speed more than threshold! speed %f for %d seconds \n",speed,duration);
			if(duration >= i_analytics.o_spd.duration)
			{
				printf("************************OVER SPEED ALERT   speed = %f**************************\n",speed);
				i_analytics.o_spd.trigger = 0;
				i_analytics.o_spd.is_o_spd = 1;
				rc = BUZZER_ON;
			}
		}
	}
	else
	{
		i_analytics.o_spd.trigger = 0;
		i_analytics.o_spd.is_o_spd = 0;
		rc = BUZZER_OFF;
	}

	printf("out overspeed detection rc = %d\n",rc);
	return rc;
}


/******************RPM DETECTION******************/
int rpm_detection (double speed,double rpm)         
{ 
printf("rpm_detection rpm is %lf\n",rpm);
	if(rpm > i_analytics.o_rpm.rpm_threshold)
	{
		if(speed == 0 && i_analytics.o_rpm.mode_idle != 1)
		{
			printf("*******************RPM DETECTED AT IDLE MODE-- r=%f s=%f********************\n",rpm,speed);
			i_analytics.o_rpm.mode_idle  = 1;
			return 1;
		}
		else if(speed > 0 && i_analytics.o_rpm.mode_ride != 1)
		{
			printf("*******************RPM DETECTED AT RIDE MODE-- r=%f s=%f*********************\n",rpm,speed);
			i_analytics.o_rpm.mode_ride = 1;
			return 2;
		}
	}
	else
	{
		i_analytics.o_rpm.mode_idle = 0;
		i_analytics.o_rpm.mode_ride = 0;
	}
	return 0;
}

/**************HARSH ACCELERATION and BRAKING****************/

int harsh_acc_braking (double speed)
{
	//	static double speed1 = -1,speed2,acc;
	int rc = 0;
	//	printf("in harsh_acc_braking \n");
	if(i_analytics.h_acc_brk.prev_speed == -1)
	{
		i_analytics.h_acc_brk.prev_speed = speed;
	}
	else
	{
		i_analytics.h_acc_brk.cur_speed = speed;
		printf("prev_speed = %lf , cur_speed = %lf\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed);
		//              printf("speed2 = %f in HARSH ACCELERATION and BRAKING\n",speed2);
		i_analytics.h_acc_brk.acc = (((i_analytics.h_acc_brk.cur_speed-i_analytics.h_acc_brk.prev_speed)*5)/(9.80665*1*18));
		//speed1 = speed2;
		printf("acc = %f in HARSH ACCELERATION and BREAKING\n",i_analytics.h_acc_brk.acc);

		if (i_analytics.h_acc_brk.acc >= i_analytics.h_acc_brk.acc_threshold)
		{	
			printf("*******************HARSH ACCELERATION-- speed1 = %f speed2 = %f acc = %f*******************\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed,i_analytics.h_acc_brk.acc);
			rc = 1;
		}

		if(i_analytics.h_acc_brk.acc <= i_analytics.h_acc_brk.brk_threshold)
		{
			printf("*********************HARSH BREAKING-- speed1 = %f speed2 = %f acc = %f*********************\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed,i_analytics.h_acc_brk.acc);
			rc = -1;
		}
		i_analytics.h_acc_brk.prev_speed = i_analytics.h_acc_brk.cur_speed;
	} 
	//	printf("out harsh_acc_braking \n");
	return rc;

}

int harsh_acc_braking_acc ()
{
	int rc = 0;
	static int flag = 0;
	double diff = 0.0;

	if (flag == 0){
		if (i_analytics.g_adata.x >= 1.0)
			diff = i_analytics.g_adata.x;
		flag = 1;
	}
	printf("in harsh_acc_braking_acc+\n");

	printf("i_analytics.g_adata.xaxis - %lf\n",i_analytics.g_adata.x);
	
	i_analytics.g_adata.x -= diff;
 
	if (i_analytics.g_adata.x >= i_analytics.h_acc_brk.acc_threshold) 
	{
		printf("*******************HARSH ACCELERATION****************acc = %lf\n",i_analytics.g_adata.x);
			rc = 1;
	}
	if(i_analytics.g_adata.x <= i_analytics.h_acc_brk.brk_threshold)
	{
		printf("*******************HARSH BREAKING****************acc = %lf\n",i_analytics.g_adata.x);
		rc = -1;
	}
	printf("out harsh_acc_braking rc = %d\n",rc);
	return rc;

}
/*********************FATIGUE DETECTION***********************/

int fatigue_detection (void)
{
	int rc = 0;
	//	printf("in fatigue_detection i_analytics.drive_start %d \n",i_analytics.ftg.drive_start);
	if(i_analytics.ftg.drive_start == 1)
	{
		//	printf("in fatigue_detection if \n");
		gettimeofday(&i_analytics.ftg.eot, NULL);
		i_analytics.ftg.duration = ((i_analytics.ftg.eot.tv_usec - i_analytics.ftg.sot.tv_usec) + (i_analytics.ftg.eot.tv_sec - i_analytics.ftg.sot.tv_sec)*1000000)/1000000;

		printf("duration inside fatigue detection %d FAT_Limit %d \n",i_analytics.ftg.duration,i_analytics.ftg.ftg_threshold);
		if(i_analytics.ftg.duration > i_analytics.ftg.ftg_threshold)
		{
			printf("*********************FATIGUE DETECTED************************\n");
			i_analytics.ftg.drive_start = 0;
			rc = 1;
		}
	}
	else
	{	
		//	printf("in fatigue_detection else \n");
		gettimeofday(&i_analytics.ftg.sot, NULL);
		i_analytics.ftg.drive_start = 1;

	}
	//	printf("out fatigue_detection \n");
	return rc;
}

int excess_idling (double rpm,double speed)
{

	//	static int idle_start = 0,car_idle_set = 0;
	//	static struct timeval sot,eot;

	//printf("in excess_idling rpm %lf speed %lf i_analytics.idle_start %d \n",rpm,speed,i_analytics.idle.idle_start);
	if(rpm > 400)//checking minimum rpm for ignition ON condition
	{
		if(speed == 0)
		{
			//	count1++;
			if (i_analytics.idle.idle_start == 0)
			{
				gettimeofday(&i_analytics.idle.sot,NULL);
				i_analytics.idle.idle_start = 1;
			}

			gettimeofday(&i_analytics.idle.eot, NULL);
			i_analytics.idle.duration = ((i_analytics.idle.eot.tv_usec - i_analytics.idle.sot.tv_usec) + (i_analytics.idle.eot.tv_sec - i_analytics.idle.sot.tv_sec)*1000000)/1000000;
			printf("duration inside idl_duration %d \n",i_analytics.idle.duration);

			if(i_analytics.idle.duration >= i_analytics.idle.idle_threshold)
			{
				if(i_analytics.idle.car_idle_on == 0)
				{
					printf("*****************************CAR IDLE ON-- rpm = %f speed = %f ***************************\n",rpm,speed);
					i_analytics.idle.car_idle_on = 1;
					return 1;
				}
			}
		}	
		else
		{
			if(i_analytics.idle.car_idle_on == 1)
			{
				printf("****************************CAR IDLE OFF-- rpm = %f speed = %f ***********************************\n",rpm,speed);
				i_analytics.idle.car_idle_on = 0;
				i_analytics.idle.idle_start = 0;
				return -1;
			}
		}
	}
	//printf("out excess_idling\n");
	return 0;
}





int total_odometer (int distance_dtc)
{
	int rc = 0;
	unsigned int cur_val;
	static unsigned int old_val;
	static int flag = 0;
	int base = usb_app.limit.tot_odo;
	int val1 = 0,val2 = 0;
	//FILE *fb;//fb = base file ;
	FILE *fp1,*fp2;// fp1 = file 1(odometer1.txt) ; fp2 = file 2(odometer2.txt)
	int file_write = 0;
	int file_value = 0;
	if(flag == 0)
	{
		old_val = distance_dtc;
		rc = 1;
	}
	printf("************************T_ODO********distance_dtc %d old_val  %d \n",distance_dtc,old_val);

	if(((access("/odometer1.txt", F_OK )) && (access("/odometer2.txt", F_OK ))))// if both file does not exists.
	{
		printf("both file does not exist\n");
		if((fp1 = fopen("/odometer1.txt", "w+")) == NULL)//create file1
		{
			printf("1.Can't open odometer1.txt \n");
			rc = -1;
		}

		if(!access("/sample.xml", F_OK ))
		{
#if 0
			if((fb = fopen("/iwtest/Application/odo_config.txt", "r")) == NULL)//open base file for getting base value
			{
				printf("1.Can't open odo_config.txt for reading base value \n");
				rc = -1;
			}
			else
				printf("1.odo_config.txt file opened successfully for reading base value\n");

			fscanf(fb,"%d",&base);//scanning base value
			fclose(fb);
#endif
			printf("************************base value is %d\n",usb_app.limit.tot_odo);
			file_value = usb_app.limit.tot_odo;
			file_write = 1;
		}
		else
		{
			file_value = base;
			file_write = 1;
		}
		fclose(fp1);

	}

	else if(((!access("/odometer1.txt", F_OK)) && (!access("/odometer2.txt", F_OK))))//if both file exists considering one file is corrupted
	{
		if((fp1 = fopen("/odometer1.txt", "r+")) == NULL)//open file1
		{
			printf("2.Can't open odometer1.txt \n");
			rc = -1;
		}
		if((fp2 = fopen("/odometer2.txt", "r+")) == NULL)//open file2
		{
			printf("2.Can't open odometer2.txt \n");
			rc = -1;
		}

		fscanf(fp1,"%d",&val1);//scanning file1 value
		fscanf(fp2,"%d",&val2);//scanning file2 value
		//		printf("2. val1 = %d val2 = %d\n",val1,val2);
		if(val1 == 0)//check file 1 corrupted
		{
			file_value = val2 + 1; //+1 = while writing if device unplugged ; +1 = for updating 2nd time condition true
			printf("2.inside if (val1 == 0) --------cur_val = %d\n",cur_val);
			file_write = 1;
		}
		else if (val2 == 0)//check file2 corrupted
		{
			file_value = val1 + 1;//+1 = while writing if device unplugged ; +1 = for updating 2nd time condition true
			printf("2. inside if (val2 == 0) --------cur_val = %d\n",cur_val);
			file_write = 2;
		}
		fclose(fp1);
		fclose(fp2);
	}
	else if(!access("/odometer1.txt", F_OK))//if file1 exists       
	{
		if((fp1 = fopen("/odometer1.txt", "r")) == NULL)//open file1
		{
			printf("3.Can't open odometer1.txt \n");
			rc = -1;
		}
		fscanf(fp1,"%d",&cur_val);//scanning file1 value
		printf("3.before cur_val = %d \n",cur_val);
		//printf("3.-----------> distance_dtc = %f \n",distance_dtc);
		file_value = cur_val;
		file_write = 2;
		//printf("3.after file_value = %d \n",file_value);
		// printf("3.cur_val = %d \n",cur_val);
		fclose(fp1);
	}
	else if(!access("/odometer2.txt", F_OK))//if file2 exists
	{
		if((fp2 = fopen("/odometer2.txt", "r")) == NULL)//open file1
		{
			printf("4.Can't open odometer1.txt \n");
			rc = -1;
		}
		else
			printf("4.odometer2.txt file opened successfully\n");
		fscanf(fp2,"%d",&cur_val);//scanning file1 value
		//printf("4.before cur_val = %d \n",cur_val);
		//printf("4.-----------> distance_dtc = %f \n",distance_dtc);
		file_value = cur_val;
		file_write = 1;
		//printf("4.after cur_val = %d \n",file_value);
		fclose(fp2);
	}

	if (distance_dtc > old_val)//checking for increment in distance
	{
		cur_val = file_value + ((distance_dtc - old_val));
		/* save current value as old value */
		old_val = distance_dtc;
		printf(" distance_dtc %d old_val  %d \n",distance_dtc,old_val);
		rc = 1;
	}
	else{
		/* Dont update the file, Value not updated, same as previous */
		cur_val = file_value;

		if(flag != 0){
			/* Dont write to file, as the value is same as previous */
			file_write = 0;
		}
		else{
			/* If its first time, dont avoid writing to file */
			flag = 1;
		}
	}

	if(file_write == 1)
	{
		if((fp1 = fopen("/odometer1.txt", "w+")) == NULL)//open file1
		{
			printf("3.Can't open odometer1.txt \n");
		}

		fprintf(fp1,"%d",cur_val);
		printf("value written to odometer1.txt\n");
		fclose(fp1);
		system("sync");
		if(!access("/odometer2.txt", F_OK))
			system("rm /odometer2.txt");
		system("sync");
	}
	else if (file_write == 2)
	{
		if((fp1 = fopen("/odometer2.txt", "w+")) == NULL)//open file1
		{
			printf("3.Can't open odometer2.txt \n");
		}
		else
			printf("3.odometer2.txt file opened successfully\n");

		fprintf(fp1,"%d",cur_val);
		printf("value written to odometer2.txt\n");
		fclose(fp1);
		system("sync");
		if(!access("/odometer1.txt", F_OK))
			system("rm /odometer1.txt");
		system("sync");
	}
	tot_odometer = cur_val;//updating odometer value
	i_analytics.t_odo.tot_odometer = cur_val;
	printf("***********out t_odo  tot_odometer %d*********\n",tot_odometer);
	return rc;
}

int get_tot_odometer()
{
	printf("*********** get_tot_odometer tot_odometer %lf *********\n",i_analytics.t_odo.tot_odometer);
	return i_analytics.t_odo.tot_odometer;

}

int crash_detection (double speed)
{
	int rc = 0;
	printf("in  crash detection \n");
	if(i_analytics.crash.prev_speed == -1)
	{
		i_analytics.crash.prev_speed = speed;
	}
	else
	{
		i_analytics.crash.cur_speed = speed;
		//              printf("speed2 = %f in HARSH ACCELERATION and BRAKING\n",speed2);
		i_analytics.crash.acc = (((i_analytics.crash.cur_speed-i_analytics.crash.prev_speed)*5)/(9.80665*1*18));
		//speed1 = speed2;
		printf("acc = %f in  CRASH DETECTION\n",i_analytics.crash.acc);
		if (i_analytics.crash.acc <= i_analytics.crash.crash_threshold)
		{
			printf("*******************CRASH DETECTION-- speed1 = %f speed2 = %f acc = %f*******************\n",i_analytics.crash.prev_speed,i_analytics.crash.cur_speed,i_analytics.crash.acc);
			rc = 1;
		}
		i_analytics.crash.prev_speed = i_analytics.crash.cur_speed;
	}
	printf("out  crash detection \n");
	return rc;

}

int harsh_cornering_acc (double *G)
{
	int rc = 0;
	accelerometer_api_priv adata;
	get_accelerometer (&adata);	
	if (rc == 0){//added peru
		//printf("***********************GYROSCOPE VALUE********************\n");
		printf("acc.y %f\n",adata.y);
		printf("H_COR_LIMIT = %f\n",i_analytics.h_crn.dps_threshold);
		*G = adata.y;

		if(*G > i_analytics.h_crn.dps_threshold){
			printf("*********************************HARSH CORNERING %f********************************\n",*G);
			rc = 1;
		}
	}
	else
		printf("Gyro failed in H_COR with rc = %d\n",rc);
	return rc;
}


int harsh_cornering (double *G)
{
	int rc = 0;
	//double dps,RPM;
	gyroscope_api_priv g_value;

	rc = get_gyroscope (&g_value);

	if (rc == 0){//added peru
		//printf("***********************GYROSCOPE VALUE********************\n");
		printf("Gx %f\n",g_value.x);
		printf("Gy %f\n",g_value.y);
		printf("Gz %f\n",g_value.z);
		printf("H_COR_LIMIT = %f\n",i_analytics.h_crn.dps_threshold);
		*G = g_value.z;
#if 0
		dps = g_value.z;
		printf("dps = %f\n",dps);
		if(dps > i_analytics.h_crn.dps_threshold || dps < -i_analytics.h_crn.dps_threshold){
			/* Revolutions per minute according to gyroscope dps values */
			RPM = dps/6;
			/* Constant * 90feet(radius) * RPM square */

			*G = 0.000001118 * 27432 * (RPM * RPM);
			printf("G = %f\n",*G);
			if(*G > 0.28){
				printf("*********************************HARSH CORNERING %f********************************\n",*G);
				rc = 1;
			}
		}
#endif
			if(*G > i_analytics.h_crn.dps_threshold){
				printf("*********************************HARSH CORNERING %f********************************\n",*G);
				rc = 1;
			}
	}
	else
		printf("Gyro failed in H_COR with rc = %d\n",rc);
	return rc;
}


#if 0
void critical_data_analytics()
{
	struct gps_rmc_t gps_rmc;
	char payload[512]={0};
	char time[100]={0};
	int ret = 0;
	double speed = 0;
	printf("critical_analytics_thread \n");
	{
		gps_start(&gps_rmc);

		printf("critical_analytics_thread get_car_status +\n");
		//get_car_speed(&speed);
		get_car_status();
		printf("critical_analytics_thread get_car_status -\n");

		printf("veh_speed %d \n",speed);
		if(over_speed_detection(speed) == 1){
			get_time(time);
			sprintf(payload,"{\"ts\":\"%s\",\"imei\":\"%s\",\"spd\":%f,\"lt\":%f,\"ln\":%f,\"ttl\":%d}",time,dmClient.cfg.deviceid,speed,gps_rmc.latitude,gps_rmc.longitude,ttl);
			printf("************************** OVER SPEED ALERT-- %f*****************************\n",speed);	
			send_data_to_cloud(payload,OVERSPEED);
		}
		memset(payload,0,sizeof(payload));

		ret = harsh_acc_braking (speed);
		if(ret == 1){
			get_time(time);
			printf("**********************************HARSH ACCELERATION********************************\n");
			sprintf(payload,"{\"ts\":\"%s\",\"imei\":\"%s\",\"lt\":%f,\"ln\":%f,\"ttl\":%d}",time,dmClient.cfg.deviceid,gps_rmc.latitude,gps_rmc.longitude,ttl);
			send_data_to_cloud(payload,H_ACCELERATION);
		}
		if(ret == -1){
			get_time(time);
			printf("************************************HARSH BRAKING**********************************\n");
			sprintf(payload,"{\"ts\":\"%s\",\"imei\":\"%s\",\"lt\":%f,\"ln\":%f,\"ttl\":%d}",time,dmClient.cfg.deviceid,gps_rmc.latitude,gps_rmc.longitude,ttl);
			send_data_to_cloud(payload,H_BREAK);
		}
		memset(payload,0,sizeof(payload));

		if(crash_detection(speed) == 1)
		{
			get_time(time);
			printf("**********************************CRASH DETECTION********************************\n");
			sprintf(payload,"{\"ts\":\"%s\",\"imei\":\"%s\",\"lt\":%f,\"ln\":%f,\"ttl\":%d}",time,dmClient.cfg.deviceid,gps_rmc.latitude,gps_rmc.longitude,ttl);
			send_data_to_cloud(payload,CRASH);
		}
	}
}
#endif


int car_data_analytics(double vehicle_speed, double rpm, int distance_dtc_clear)
{
	int rc = 0;
	int ret = 0;
	char payload[128]={0};
	struct obd_data obd_qdata;

	int get_gps = 0;
	char ts[100]={0};
#ifdef __USB__
	if ((usb_app.src.h_acc == SRC_ACCELEROMETER)||(usb_app.src.h_brk == SRC_ACCELEROMETER))
		ret = harsh_acc_braking_acc ();
	else if ((usb_app.src.h_acc == SRC_VEHICLE_SPEED)||(usb_app.src.h_brk == SRC_VEHICLE_SPEED)) 
		ret = harsh_acc_braking (vehicle_speed);
#else
	ret = harsh_acc_braking (vehicle_speed);
#endif
	if(ret == 1){
		get_time(ts);
		if(get_gps == 0){
			get_gps = 1;
		}
		printf("**********************************HARSH ACCELERATION %s ********************************\n",ts);
		
		rc = final_payload_frame (ts, &obd_qdata, "HARSH_ACC");
		obd_qdata.msg_type = HARSH_ACC;
		rc = send_msg_an_q(&obd_qdata);
		if(rc < 0)
		{
			printf(" HARSH_ACC send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL2 ("HARSH_ACC event sent to message queue");

	}
	if(ret == -1){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

		printf("************************************HARSH BRAKING %s **********************************\n",ts);

		strcpy(obd_qdata.data,ts);
		rc = final_payload_frame (ts, &obd_qdata, "HARSH_BRK");

		obd_qdata.msg_type = HARSH_BRK;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			printf(" HARSH_BRK send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL2 ("HARSH_BRK event sent to message queue");
	}
	memset(payload,0,sizeof(payload));
#ifndef __USB__
	 if (usb_app.src.crash == SRC_ACCELEROMETER)
                ret = crash_detection_acc (acc.x_axis);
        else if (usb_app.src.h_acc == SRC_VEHICLE_SPEED)
	        ret = crash_detection(vehicle_speed);
#else
        ret = crash_detection(vehicle_speed);
#endif

	if(ret == 1){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

		printf("**********************************CRASH DETECTION********************************\n");
		rc = final_payload_frame (ts, &obd_qdata, "CRASH");
		obd_qdata.msg_type = CRASH;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			printf(" CRASH send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL2 ("CRASH event sent to message queue");

	}

	memset(payload,0,sizeof(payload));

	ret = rpm_detection (vehicle_speed,rpm);
	if(ret == 1 ){
		get_time(ts);

		if(get_gps == 0){

			get_gps = 1;
		}

		printf("*******************RPM DETECTED AT IDLE MODE-- r=%f s=%f********************\n",rpm,vehicle_speed);

		rc = final_payload_frame (ts, &obd_qdata, "RPM_OVER");
		obd_qdata.msg_type = RPM_OVER;
		rc = send_msg_an_q(&obd_qdata);
		if(rc < 0)
		{
			printf("RPM_OVER at idle, send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL2 ("RPM_OVER event sent to message queue");
	}
	if(ret == 2 ){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

		printf("*******************RPM DETECTED AT RIDE MODE-- r=%f s=%f*********************\n",rpm,vehicle_speed);            

		rc = final_payload_frame (ts, &obd_qdata, "RPM_OVER");
		obd_qdata.msg_type = RPM_OVER;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			printf("RPM_OVER at idle, send to server failed!\n");
		}
	}
#if 0
	if(total_odometer(distance_dtc_clear) == 1){
		printf("*************************************TOTAL ODOMETER %d\n********************************",tot_odometer);
	}
#endif
	return 0;
}


int send_data_to_cloud(char * packet,int event)
{
	int rc = 0;
	struct obd_data obd_qdata;
	obd_qdata.msg_type = event;
	memset(obd_qdata.data,0x0,256);
	strncpy(obd_qdata.data,packet, strlen(packet));
	rc = send_msg_an_q(&obd_qdata);

	return rc;
}

void get_limit()
{
#ifdef _XLS__EN_
	int row = 0;
	int i=0;

	row = elimit[0].no_of_evt;

	printf("in CAN_Thread row = %d\n",row);

	for(i = 0; i < row; i++)
	{
		if(strcmp(elimit[i].events,"HARSH_ACCELERATION") == 0)
		{
			i_analytics.h_acc_brk.acc_threshold = ((elimit[i].limit*5)/(9.80665*1*18));
			printf("H_ACC_Limit = %f\n",i_analytics.h_acc_brk.acc_threshold);
		}
		else if(strcmp(elimit[i].events,"HARSH_BREAK") == 0)
		{
			//	H_BRK_Limit = elimit[i].limit;
			i_analytics.h_acc_brk.brk_threshold = ((elimit[i].limit * 5* -1)/(9.80665*1*18));
			printf("H_BRK_Limit = %f\n",i_analytics.h_acc_brk.brk_threshold);
		}
		else if(strcmp(elimit[i].events,"OVER_SPEED") == 0)
		{
			i_analytics.o_spd.o_spd_threshold = elimit[i].limit;
			printf("O_S_Limit = %d\n",i_analytics.o_spd.o_spd_threshold);
		}
		else if(strcmp(elimit[i].events,"RPM") == 0)
		{
			i_analytics.o_rpm.rpm_threshold = elimit[i].limit;
			printf("RPM_Limit = %d\n",i_analytics.o_rpm.rpm_threshold);
		}
		else if(strcmp(elimit[i].events,"FATIGUE") == 0)
		{
			i_analytics.ftg.ftg_threshold = elimit[i].limit;
			printf("FAT_Limit = %d\n",i_analytics.ftg.ftg_threshold);
		}
		else if(strcmp(elimit[i].events,"IDLING") == 0)
		{
			i_analytics.idle.idle_threshold = elimit[i].limit;
			printf("IDL_Limit = %d\n",i_analytics.idle.idle_threshold);
		}
		else if(strcmp(elimit[i].events,"CRASH") == 0)
		{
			i_analytics.crash.crash_threshold = ((elimit[i].limit * 5* -1)/(9.80665*1*18));
			printf(" CRASH_Limit = %f\n",i_analytics.crash.crash_threshold);
		}
		else if(strcmp(elimit[i].events,"OVERTEMP") == 0)
		{
			i_analytics.o_temp.o_temp_threshold = ((elimit[i].limit));
			printf(" OVERTEMP threshold = %f\n",i_analytics.o_temp.o_temp_threshold);
		}
		else;
	}
#else
	if (usb_app.src.h_acc == SRC_VEHICLE_SPEED){
		i_analytics.h_acc_brk.acc_threshold = ((usb_app.limit.h_acc*5)/(9.80665*1*18));
		printf("i_analytics.h_acc_brk.acc_threshold = %lf\n",i_analytics.h_acc_brk.acc_threshold);
	}
	else if(usb_app.src.h_acc == SRC_ACCELEROMETER){
		i_analytics.h_acc_brk.acc_threshold = usb_app.limit.h_acc;
		printf("i_analytics.h_acc_brk.acc_threshold = %lf\n",i_analytics.h_acc_brk.acc_threshold);
	}
	if (usb_app.src.h_brk == SRC_VEHICLE_SPEED){
		i_analytics.h_acc_brk.brk_threshold = ((usb_app.limit.h_brk * 5 * -1)/(9.80665*1*18)); 
		printf("i_analytics.h_acc_brk.brk_threshold = %lf\n",i_analytics.h_acc_brk.brk_threshold);
	}
	else if (usb_app.src.h_brk == SRC_ACCELEROMETER){
                i_analytics.h_acc_brk.brk_threshold = usb_app.limit.h_brk * -1;
                printf("i_analytics.h_acc_brk.brk_threshold = %lf\n",i_analytics.h_acc_brk.brk_threshold);
        }
	if (usb_app.src.crash == SRC_VEHICLE_SPEED){
		i_analytics.crash.crash_threshold = ((usb_app.limit.crash * 5 * -1)/(9.80665*1*18));
		printf("1.i_analytics.crash.crash_threshold = %lf usb_app.src.crash = %d\n",i_analytics.crash.crash_threshold,usb_app.src.crash);
	}
	else if(usb_app.src.crash == SRC_ACCELEROMETER){
                i_analytics.crash.crash_threshold = usb_app.limit.crash * -1;
                printf("2.i_analytics.crash.crash_threshold = %lf usb_app.src.crash = %d\n",i_analytics.crash.crash_threshold,usb_app.src.crash);
        }
	if (usb_app.src.harsh == SRC_GYROSCOPE){
		i_analytics.h_crn.dps_threshold = usb_app.limit.harsh/10.0;
                printf("1.i_analytics.h_crn.dps_threshold = %lf\n",i_analytics.h_crn.dps_threshold);
	}
	else if (usb_app.src.harsh == SRC_ACCELEROMETER){
		i_analytics.h_crn.dps_threshold = usb_app.limit.harsh;
                printf("2.i_analytics.h_crn.dps_threshold = %lf\n",i_analytics.h_crn.dps_threshold);
	}
			
i_analytics.o_spd.o_spd_threshold = usb_app.limit.o_spd;
printf("i_analytics.o_spd.o_spd_threshold = %d\n",i_analytics.o_spd.o_spd_threshold);
i_analytics.o_rpm.rpm_threshold = usb_app.limit.rpm;
printf("i_analytics.o_rpm.rpm_threshold = %lf\n",i_analytics.o_rpm.rpm_threshold);
i_analytics.ftg.ftg_threshold = usb_app.limit.fat;
printf("i_analytics.ftg.ftg_threshold = %d\n",i_analytics.ftg.ftg_threshold);
i_analytics.idle.idle_threshold = usb_app.limit.idle;
printf("i_analytics.idle.idle_threshold = %d\n",i_analytics.idle.idle_threshold);
i_analytics.o_temp.o_temp_threshold = usb_app.limit.o_temp;
printf("i_analytics.o_temp.o_temp_threshold = %lf\n",i_analytics.o_temp.o_temp_threshold);
#endif
}
#if 1
int evt_limits ()
{
	int rc = 0;
	char value [10];
	bzero (value,sizeof(value));
#ifdef _XLS__EN_
	xlsWorkBook* pWB;
	xlsWorkSheet* pWS;
	struct st_row_data* row;
	WORD t,tt;
	int i,r;
	printf("init_event_limits \n");
	pWB=xls_open("/iwtest/Application/threshold.xls","iso-8859-15//TRANSLIT");

	if (pWB!=NULL)
	{
		// open and parse the sheet
		pWS=xls_getWorkSheet(pWB,0);

		xls_parseWorkSheet(pWS);

		// process all rows of the sheet
		printf("pWS->rows.lastrow = %d\n",r = pWS->rows.lastrow);
		printf("pWS->rows.lastcol = %hd\n",pWS->rows.lastcol);

		elimit = (E_LIMIT *)calloc(pWS->rows.lastrow,sizeof(E_LIMIT));
		elimit[0].no_of_evt = pWS->rows.lastrow;
		for (i= 0,t=1;t<=pWS->rows.lastrow;i++,t++)
		{
			row=&pWS->rows.row[t];

			for (tt=0;tt<=pWS->rows.lastcol;tt++)
			{
				if (!row->cells.cell[tt].ishiden)
				{
					// display the value of the cell (either numeric or string)
					if (row->cells.cell[tt].id==0x27e || row->cells.cell[tt].id==0x0BD || row->cells.cell[tt].id==0x203)
					{
						elimit[i].limit = row->cells.cell[tt].d;
					}
					else if (row->cells.cell[tt].str!=NULL)
					{
						char *str = row->cells.cell[tt].str;
						if( tt == 0)
							strcpy(elimit[i].events,str);
						if( tt == 2)
							strcpy(elimit[i].units,str);
					}
					else
						continue;

				}
			}
		}
		xls_close(pWB);

		for(i = 0; i < r; i++)
			printf("events = %s \t limit = %d\n",elimit[i].events,elimit[i].limit);
	}
	else
		rc = -1;
#else
	/*!< HARSH_BRK_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_BRK, FIELD_NAME_SRC, value);
	usb_app.src.h_brk = atoi (value);
	printf ("usb_app.src.h_brk = %d\n",usb_app.src.h_brk);
	/*!< HARSH_ACC_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ACC, FIELD_NAME_SRC, value);
	usb_app.src.h_acc = atoi (value);
	printf ("usb_app.src.h_acc = %d\n",usb_app.src.h_acc);
	/*!< CRASH_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_CRASH, FIELD_NAME_SRC, value);
	usb_app.src.crash = atoi (value);
	printf ("usb_app.src.crash = %d\n",usb_app.src.crash);
	/*!< HARSH_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_HARSH, FIELD_NAME_SRC, value);
	usb_app.src.harsh = atoi (value);
	printf ("usb_app.src.harsh = %d\n",usb_app.src.harsh);
	/*!< O_SPEED_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_SRC, value);
	usb_app.src.o_spd = atoi (value);
	printf ("usb_app.src.o_spd = %d\n",usb_app.src.o_spd);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_DUR, value);
	i_analytics.o_spd.duration = atoi (value);
	printf ("i_analytics.o_spd.duration = %d\n",i_analytics.o_spd.duration);
	/*!< add lock to limits*/
	/*!< CRASH_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_CRASH, FIELD_NAME_THRESH, value);
	usb_app.limit.crash = atof (value);
	printf ("usb_app.limit.crash = %lf\n",usb_app.limit.crash);
	/*!< RPM_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_RPM, FIELD_NAME_THRESH, value);
	usb_app.limit.rpm = atof (value);
	printf ("usb_app.limit.rpm = %lf\n",usb_app.limit.rpm);
	/*!< H_ACC_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ACC, FIELD_NAME_THRESH, value);
	usb_app.limit.h_acc = atof (value);
	printf ("usb_app.limit.h_acc = %lf\n",usb_app.limit.h_acc);
	/*!< H_BRK_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_BRK, FIELD_NAME_THRESH, value);
	usb_app.limit.h_brk = atof (value);
	printf ("usb_app.limit.h_brk = %lf\n",usb_app.limit.h_brk);
	/*!< HARSH_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_HARSH, FIELD_NAME_THRESH, value);
	usb_app.limit.harsh = atof (value);
	printf ("usb_app.limit.harsh = %lf\n",usb_app.limit.harsh);
	/*!< ODOMETER_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ODO, FIELD_NAME_BASE, value);
	usb_app.limit.tot_odo = atoi (value);
	printf ("usb_app.limit.tot_odo = %d\n",usb_app.limit.tot_odo);
	/*!< O_SPD_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_THRESH, value);
	usb_app.limit.o_spd = atoi (value);
	printf ("usb_app.limit.o_spd = %d\n",usb_app.limit.o_spd);
	/*!< O_TEMP_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OTEMP, FIELD_NAME_THRESH, value);
	usb_app.limit.o_temp = atof (value);
	printf ("usb_app.limit.o_temp = %lf\n",usb_app.limit.o_temp);
#endif

	return rc;
}
#endif

int update_time_limit ()
{
	int rc = 0;
	char value[10];
	/*!< IDL_TIME_LIMIT */
	bzero(value,sizeof (value));
	rc = get_xml_content (SRC_XML_FILE,PARENT_NODE_FREQ ,PARENT_NODE_IDL , value);
	usb_app.limit.idle = atoi (value);
	printf ("usb_app.limit.idle = %d\n",usb_app.limit.idle);
	/*!< FATIGUE_LIMIT */
	bzero(value,sizeof (value));
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_FREQ, PARENT_NODE_FAT, value);
	usb_app.limit.fat = atoi (value);
	printf ("usb_app.limit.fat = %d\n",usb_app.limit.fat);
	return rc;

}

int update_io_function ()
{
	int rc = 0;
	char value[2];
	
	IO_PIN_STATE io_pin;
	/*!< DOUT1 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT1, FIELD_NAME_SRC, value);
	usb_app.io.dout1[0] = atoi (value);
	printf ("usb_app.io.dout1[0] = %d\n",usb_app.io.dout1[0]);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT1, "value", value);
	usb_app.io.dout1[1] = atoi (value);
	printf ("usb_app.io.dout1[1] = %d\n",usb_app.io.dout1[1]);
	/*!< DOUT2 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT2, FIELD_NAME_SRC, value);
	usb_app.io.dout2[0] = atoi (value);
	printf ("usb_app.io.dout2[0] = %d\n",usb_app.io.dout2[0]);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT2, "value", value);
	usb_app.io.dout2[1] = atoi (value);
	printf ("usb_app.io.dout2[1] = %d\n",usb_app.io.dout2[1]);
	/*!< DIN1 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DIN1, FIELD_NAME_SRC, value);
	usb_app.io.din1 = atoi (value);
	printf ("usb_app.io.din1 = %d\n",usb_app.io.din1);
	/*!< DIN2 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DIN2, FIELD_NAME_SRC, value);
	usb_app.io.din2 = atoi (value);
	printf ("usb_app.io.din2 = %d\n",usb_app.io.din2);

	io_pin.din1 = usb_app.io.din1;
	io_pin.din2 = usb_app.io.din2;
	io_pin.dout1 = usb_app.io.dout1[0];
	io_pin.dout2 = usb_app.io.dout2[0];
	io_pin.ain1 = usb_app.io.ain1;
	update_gpio_info (&io_pin);

	return rc;
}

int drive_gpio_state ()
{
	/*Relay - 1 Buzzer - 2*/
	int ret;
	printf("drive_gpio_state +\n");
	ret = set_gpio_value(36,usb_app.io.dout1[1]);
	ret = set_gpio_value(38,usb_app.io.dout2[1]);

	printf("drive_gpio_state - %d\n",ret);

	return ret;
}
