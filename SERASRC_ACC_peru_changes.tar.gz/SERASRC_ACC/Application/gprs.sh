#killall pppd
#sleep 4
pppd call gprs_4g
sleep 1
