cd obd2_lib/
make clean
make
cp libOBD2.so ../obd2_app/standard/lib/
sync
cp libOBD2.so ../obd2_app/analytics/lib/
sync
cd ../obd2_app/analytics/
make clean
make
cp libanalytics.so ../standard/lib/
sync
cd ../standard/
make clean
make
cd ../../
rm Application/iWaveOBD2FW
#rm Application_AZURE.tar.bz2
rm Application_usb.zip
sync
cp obd2_app/standard/iWaveOBD2FW Application/
sync
cp obd2_app/standard/lib/libanalytics.so Application/
sync
#p obd2_app/standard/lib/libOBD2.so Application/
sync
sync
sync
#zip -r Application_usb.zip Application/
tar -cvjf Application.tar.bz2 Application/
