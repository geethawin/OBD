/**
 * section: Tree
 * synopsis: Navigates a tree to print element names
 * purpose: Parse a file to a tree, use xmlDocGetRootElement() to
 *          get the root element, then walk the document and print
 *          all the element name in document order.
 * usage: tree1 filename_or_URL
 * test: tree1 test2.xml > tree1.tmp && diff tree1.tmp $(srcdir)/tree1.res
 * author: Dodji Seketeli
 * copy: see Copyright for the status of this software.
 */
#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <string.h>
#include <libxml2.h>


/*
 *To compile this file using gcc you can type
 *gcc `xml2-config --cflags --libs` -o xmlexample libxml2-example.c
 */

int get_content(xmlNode * a_node, char *parent_node, char *name, char *value)
{

 xmlNode *cur_node = NULL;
	xmlChar *local_content_name;

    for (cur_node = a_node; cur_node; cur_node = cur_node->next) {
        if (cur_node->type == XML_ELEMENT_NODE) {
			if(!(xmlStrcmp(cur_node->name,(const xmlChar *)name) || (xmlStrcmp(cur_node->parent->name,(const xmlChar *)parent_node))))
			{
				local_content_name = xmlNodeGetContent(cur_node);
				memcpy(value,local_content_name,strlen(local_content_name)+1);
			}
			
        }

        get_content(cur_node->children, parent_node,name, value);
    }
	return 0;

}

int set_content(xmlNode * a_node, char *parent_node, char *name, char *value)
{

 xmlNode *cur_node = NULL;
	xmlChar *local_content_name;

    for (cur_node = a_node; cur_node; cur_node = cur_node->next) {
        if (cur_node->type == XML_ELEMENT_NODE) {
			if(!(xmlStrcmp(cur_node->name,(const xmlChar *)name) || (xmlStrcmp(cur_node->parent->name,(const xmlChar *)parent_node))))
			{
				xmlNodeSetContent(cur_node,(const xmlChar *) value);
				local_content_name = xmlNodeGetContent(cur_node);
				
			}
			
        }

        set_content(cur_node->children, parent_node,name, value);
    }
	return 0;

}

int get_xml_content(char *filename, char *parent_node,char *name, char *value)
{

	xmlDoc *doc = NULL;
	xmlNode *root_element = NULL;
        int ret;

        ret = sem_wait(ret_value);
        if(ret != 0)
        {
                printf("sem_wait ERR = %d\n", errno);
        }



	doc = xmlReadFile(filename, NULL, 0);

	if (doc == NULL) {
		printf("error: could not parse file %s\n", filename);
		xmlFreeDoc(doc);
		xmlCleanupParser();
		system("cp /current.xml /sample.xml");
		system ("sync");
		system ("sync");
		doc = xmlReadFile(filename, NULL, 0);
	}
	if (doc != NULL){

		/*Get the root element node */
		root_element = xmlDocGetRootElement(doc);

		get_content(root_element, parent_node, name, value);

		xmlFreeDoc(doc);
		xmlCleanupParser();

		ret = sem_post(ret_value);
		if(ret != 0)
		{
			printf("sem_wait ERR = %d\n", errno);
		}

	}

	return 0;
}
int set_xml_content(char *filename, char *parent_node,char *name, char *value)
{

	xmlDoc *doc = NULL;
	xmlNode *root_element = NULL;
        int ret;

        ret = sem_wait(ret_value);
        if(ret != 0)
        {
                printf("sem_wait ERR = %d\n", errno);
        }


	doc = xmlReadFile(filename, NULL, 0);

	if (doc == NULL) {
		printf("error: could not parse file %s\n", filename);
	}

	/*Get the root element node */
	root_element = xmlDocGetRootElement(doc);


	set_content(root_element,parent_node,name,value);

	xmlSaveFileEnc(filename, doc, "UTF-8");
	system("sync");
	xmlFreeDoc(doc);
	xmlCleanupParser();
	system("cp -rf /sample.xml /current.xml");
	system("sync");

        ret = sem_post(ret_value);
        if(ret != 0)
        {
                printf("sem_wait ERR = %d\n", errno);
        }
	return 0;
}

int sem_init_usb (const char* sem_name)
{
        ret_value = sem_open(sem_name, 0, 0, 0);

        if (ret_value == SEM_FAILED) {
                /*
                 * No such file or directory
                 */
                if (errno == ENOENT) {
                        ret_value = sem_open(sem_name,
                                        O_CREAT | O_EXCL, 0777, 1);
                        if (ret_value == SEM_FAILED) {
                                printf("Error in creating semaphone file\n");
                                return -2;
                        }
                }
        }
        return 0;
}

int sem_init_4g (const char* sem_name, sem_t *semapore)
{
int ret;
//        semapore = sem_open(sem_name, 0, 0, 1);
	
  //      if (semapore == SEM_FAILED) {
//		printf("semaphore1111\n");
                /*
                 * No such file or directory
                 */
               // if (errno == ENOENT) {
			if (ret < 0)
				printf("sem_init_4g failed %d %d\n",ret, errno);
                        semapore = sem_open(sem_name, O_CREAT, 0644, 1);
                        //semapore = sem_open(sem_name,O_CREAT | O_EXCL, 0777, 1);
				printf("semaphore2222\n");
                        if (semapore == SEM_FAILED) {
                                printf("Error in creating semaphone file\n");
                                return -2;
                        }
               // }
      //  }
        return 0;
}
