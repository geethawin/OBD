#include "common.h"
/*!
 * \brief
 * gpio_export function to export the gpio
 *
 * \details
 * This function is to export the gpio from arguments
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \return
 * Success - E_SUCCESS
 */
int gpio_export(int gpio)
{
	FILE * pFile;
	int ret =0;
	char gpio_path[100] = {0};
	char gpio_buf[10] = {0};

	sprintf(gpio_buf,"%d",gpio);
	sprintf(gpio_path,"/sys/class/gpio/gpio%d", gpio);
	if (access(gpio_path, F_OK ) == 0){
		ret = 0;
	}else{
		pFile=fopen("/sys/class/gpio/export", "wr");
		if (pFile==NULL) {
			printf("File open error \r\n");
			ret = -1;
			goto end;
		}

		ret = fwrite(gpio_buf,1,sizeof(gpio),pFile);
		if (ret < 0)
		{
			ret = -1;
		}else
			ret = 0;

		fclose(pFile);
	}
end:
	return ret;
}

/*!
 * \brief
 * get_gpio_direction function to get the gpio value
 *
 * \details
 * This function is to get the gpio value
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \param [in] value
 * GPIO value
 *
 * \return
 * Success - E_SUCCESS
 */
int get_gpio(int gpio, int * value)
{
	int ret =0;
	FILE * pFile;
	char gpio_path[100] = {0};
	char gpio_buf[10] = {0};
	long fsize;

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);

	if (access(gpio_path, F_OK ) == 0){
		pFile=fopen(gpio_path, "r");
		if (pFile==NULL) {
			printf("File open error \r\n");
			ret = -1;
			goto end;
		}

		ret = fread(gpio_buf, 1, sizeof(gpio_buf), pFile);
		if (ret == strlen(gpio_buf))
		{
			*value = atoi(gpio_buf);
			printf("value before shifting %d \n\r",*value);
			*value = (*value & (1 << gpio))? 1: 0;
			printf("value after shifting %d \n\r",*value);
		}else{
			ret = -1;
		}

		fclose(pFile);

	}else{
		ret = -1;
	}
end:
	return ret;
}

int set_gpio_value(int gpio, int value)
{
        int ret;
        FILE * pFile;
        char gpio_path[100] = {0};
        char gpio_buf[10] = {0};

        sprintf(gpio_buf,"%d",value);
        sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);
        if (access(gpio_path, F_OK ) == 0){
                pFile=fopen(gpio_path, "wr");
                if (pFile==NULL) {
                        printf("File open error \r\n");
                        ret = -1;
                        goto end;
                }

                ret = fwrite(gpio_buf,1,sizeof(value),pFile);
                if (ret < 0 )
                {
                	IOBD_DEBUG_LEVEL2 ("gpio%d file write error", gpio);
                        ret = -2;
                }else
                        ret = 0;

                fclose(pFile);
        }else{
                IOBD_DEBUG_LEVEL2 ("gpio%d file does not exist", gpio);
		ret = -3;
        }
end:
        return ret;
}

int set_gpio_direction(int gpio, int direction)
{
	FILE * pFile;
	char gpio_path[100] = {0};
	int ret;

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/direction",gpio);
	pFile=fopen(gpio_path, "w");
	if (pFile==NULL) {
		printf("File open error \r\n");
		ret = -1;
		goto end;
	}else{
		if (direction == INPUT)
			ret = fwrite("in",1,2,pFile);
		if (direction == OUTPUT)
			ret = fwrite("out",1,3,pFile);
		if (ret < 0 )
			ret = -1;
		else
			ret = 0;
		fclose(pFile);
	}	
end:
	return ret;
}
