#include <stdio.h>
#include<ctype.h>
#include "init.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "serial.h"

#define DEV_NODE 	"/dev/ttymxc5"
#define BAUD_RATE	9600

int parse_raw_value_ert(char *buf,char *raw_data)
{
	int j = 0;
	int buf_len = 0;
	int length = 0;
	char str[10]={0};
	char temp[64]= {0};
	char len[4]={0};
	printf("buf %s \n",buf);
	char ERT[128]={0};
	//below response is assumption
	//0902:014 :0: 41 7F 01 31 47 31 :1: 4A 43 35 34 34 34 52 :2: 37 32 35  ::
	/*Skip the mode and pid echo */
	if(strlen(buf) > 17)
	{
		char * str1 = strstr(buf,":");
		/* Skip the colon */
		str1 = str1 + 1;

		/* skip the length bytes*/
		str1 = str1 + 4;

		/* skip index ':0:' */
		str1 = str1 + 3;

		/* skip header */
		str1 = str1 + 10;

		/* Copy first 3 bytes from index 0 */
		strncpy(ERT,str1,8);

		/* skip index ':1:' */
		str1 = str1 + 8;
		str1 = str1 + 1;
		str1 = str1 + 3;

		/* Copy the data from index 1 */
		strncat(ERT,str1,21);

		str1 = str1 + 21;

		/* skip the space */
		str1 = str1 + 1;

		/* skip index ':2:' */
		str1 = str1 + 3;

		/* Copy the data from index 1 */
		strncat(ERT,str1,9);

		length = strlen(ERT);

		strcpy(raw_data,ERT);
	}

	printf("Engine Run Time data is %s Length %d!!!!!!!!!!!!!!!!!! \n",raw_data,length);
	return 0;
}

int parse_raw_value(char * buf,char * raw_data)
{
	/*      int buf_len, i;
		char str[10], position = 0;*/
	int j = 0;
	int buf_leni = 0;
	int length = 0;
	char str[10]={0};
	char temp[64]= {0};

	char * str1 = strstr(buf,":");
	str1 = str1 + 1;
	for(j = 0;str1[j]!=':';j++)
		temp[j]=str1[j];

	//printf("temp is %s \n",temp);
	str1 = temp + 6;

	length = strlen(str1);


	strcpy(raw_data,str1);
	//printf("Data is %s Length %d!!!!!!!!!!!!!!!!!! \n",raw_data,length);
	return 0;
}


int read_dtc_value(char * buf,dtccodes * dtc_values)
{
	char *substr;
	char data_buf[254]={0};
	int i = 0, pos = 0;
	char str[100]={0};
	int first_byte, second_byte;
	int dtc_code[500]={0};
	char cmd[500]={0};

	memset(data_buf, 0 , sizeof(data_buf));
	substr = strstr(buf, "43");

	if(substr == NULL){
		return -1;
	}

	strcpy(data_buf, substr);

	str[0] = data_buf[3];
	str[1] = data_buf[4];
	str[2] = '\0';
	dtc_values->no_codes = (int)strtol(str, NULL, 16);

	if(dtc_values->no_codes != 0) {
		for(i = 5; i < strlen(substr)-1; i++) {
			if((data_buf[i] != 0x20) && (data_buf[i] != 0x0A) && (data_buf[i] != 0x0D)) {
				str[0] = data_buf[i];
				str[1] = data_buf[i+1];
				str[2] = '\0';
				if(isalnum(str[0]) && (isalnum(str[1]))) {
					dtc_code[pos++] =  (int)strtol(str, NULL, 16);
					if(pos == (dtc_values->no_codes * 2))
						break;
				}
				i = i + 1;
			}
		}
		pos = 0;

		for(i = 0; i < (dtc_values->no_codes*2); i++) {
			first_byte = dtc_code[i] & 0xF0;
			second_byte = dtc_code[i] & 0x0F;

			memset(cmd, 0, 255);

			if((first_byte & 0xF0) == 0x0)
				sprintf(cmd, "P0%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x10)
				sprintf(cmd, "P1%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x20)
				sprintf(cmd, "P2%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x30)
				sprintf(cmd, "P3%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x40)
				sprintf(cmd, "C0%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x50)
				sprintf(cmd, "C1%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x60)
				sprintf(cmd, "C2%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x70)
				sprintf(cmd, "C3%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x80)
				sprintf(cmd, "B0%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0x90)
				sprintf(cmd, "B1%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xa0)
				sprintf(cmd, "B2%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xb0)
				sprintf(cmd, "B3%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xc0)
				sprintf(cmd, "U0%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xd0)
				sprintf(cmd, "U1%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xe0)
				sprintf(cmd, "U2%x%02x" , second_byte, dtc_code[i+1]);
			else if((first_byte & 0xF0) == 0xf0)
				sprintf(cmd, "U3%x%02x" , second_byte, dtc_code[i+1]);

			dtc_values->dtc_str[pos] = malloc(strlen(cmd) + 1);
			strcpy(dtc_values->dtc_str[pos++], cmd);
			printf("dtc_str: %s\r\n", dtc_values->dtc_str[pos-1]);
			i = i+1;
		}
	}
	return dtc_values->no_codes;
}

int send_command(char * cmd)
{
	int pos = 0, nbytes = 0;
	do {
		nbytes = write(libClient.serial_intf.tty_fd, cmd+pos, 1 );
		pos += nbytes;
	} while (cmd[pos-1] != '\r' && nbytes > 0);

	return 0;
}

int receive_data(char * cmd,char * buf)
{
	int pos = 0, nbytes = 0, count = 0;
	char char_read;
	int count_greater = 0;
	//int i;
	/* NaND: Pass the cmd and buf parameters. Don't use global variable */

	while(1) {
		count++;
		nbytes = read(libClient.serial_intf.tty_fd, &char_read, 1);
		if((strncmp(cmd, "STSLVLS >", 9) == 0 || strncmp(cmd, "STSLVLW >", 9) == 0)) {
			if(char_read == '>')  
				count_greater++;

			if((char_read == '>' || count > 500) && (count_greater >= 2)){
				printf("count is greater : %d\r\n", count_greater);
				count = 0;
				break;
			}
		}
		else if (char_read == '>' || count >  500){
			count = 0;
			break;
		}
		if(char_read == 0x0D)
			char_read = 0x3A;
		buf[pos++] = char_read;
	}
	buf[pos]='\0';
	count_greater = 0;

	return 0;
}

int parse_ign_status(char * buf,struct obd_ * obd_data)
{
	int i, pos = 0 , rc = 0;

	memset(obd_data->res_buf, 0, sizeof(obd_data->res_buf));
	printf("parse_ign_status \r\n");
	int j = 0;
	for(i = 5; buf[i] != 0x3A; i++) {
		if(buf[5] == 0x34){ 
			obd_data->res_buf[pos++] = buf[i];
			rc = 0;
		}
		else {
			printf("parse_ign_status return -1 \n");
			rc = -1;
			break;
		}
	}
	obd_data->res_buf[pos] = '\0';

	//printf("obd string: %s\r\n", obd_data->res_buf);

	return rc;
}

int read_car_voltage(float *volt_val)
{
	char *cmd_buf[10] = {0};
	char cmd[30]={0}, buf[255]={0};

	char volt_buf[100]={0};

	printf("atrv obd_sem w\n");
	sem_wait(&libClient.obd_sem);
	printf("atrv obd_sem g\n");

	cmd_buf[0] = "ATRV";

	sprintf(cmd, "%s\r", cmd_buf[0]);

	/* To get proper voltage value,flush old value in the terminal buffer */
		tcflush(libClient.serial_intf.tty_fd,TCIOFLUSH);
	/* NaND: Its better to have an argument instead of global variable for send_command */
	send_command(cmd);
	/* NaND: Its better to have an argument instead of global variable for receive_data */
	receive_data(cmd,buf);

	memset(volt_buf, 0, sizeof(volt_buf));	
	strncpy(volt_buf, &buf[5], strlen(buf)-8);


	*volt_val = atof(volt_buf);
	printf("volt val: %f\r\n", *volt_val);

	printf("atrv obd_sem p+\n");
	sem_post(&libClient.obd_sem);
	printf("atrv obd_sem p-\n");

	return 0;
}

int config_sleep_wake_trigger_off()
{
	/*obd_reset */
	/* NaNC : */
	obd_reset();
	obd_reset();

	/* make sleep trigger on */
	sleep_wake_trigger_off();
	sleep_wake_trigger_off();

	/* voltage change wake trigger on */
	volt_change_wake_trigger_off();

	/* obd reset */
	obd_reset();
	obd_reset();


	return 0;
}

int config_sleep_wake_trigger_on()
{
	float volt_val;
	int ret;
	char ts[64] = {0};
	struct ign_stat ign_qdata;
	tcflush(libClient.serial_intf.tty_fd, TCIFLUSH );
	obd_reset();
	obd_reset();
	obd_reset();
	obd_reset();

	ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);

	/* make sleep trigger on */
	sleep_wake_trigger_on();

	/* voltage change wake trigger on */
	volt_change_wake_trigger_on();


	printf("config_sleep_wake_trigger_on ret = %d\r\n",ret);

	//	volt_val = 10.0;
	/* For sera requirement */
	volt_val = 9.0;

	if(ret != 2)
		set_voltage_wake(&volt_val);


	/* configure sleep trigger and wake trigger */
	set_voltage_sleep(&volt_val);
	config_volt_change_wake_trigger();

	ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);

	/* Check the ignition status here before doing obd_reset.
	   If device is on again, just re-init.
	   Otherwise, Interpreter never goes to sleep since, voltage level came back to > 13.2
	   If it doesn't goes to sleep, Wakeup event will not be received */

	if(ret == IGNITION_STATE_ON) {
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));
		get_time(ts);
		memset(ign_qdata.data,0x0,256);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		printf("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
		send_ign_q(&libClient,&ign_qdata);
		ret = IGNITION_STATE_ON_RESTART;	
	} else {
		ret = 0;
		/* obd reset */
		obd_reset();
	}

	return ret;
}


int sleep_wake_trigger_off()
{
	char cmd[30]={0}, buf[255]={0};
	struct obd_ obd_data;

	sprintf(cmd, "%s off, off\r", "STSLVL");

	obd_read_data(cmd,buf,&obd_data);

	printf("voltage sleep, wake trigger off\r\n");

	return 0; 
}

int sleep_wake_trigger_on()
{
	char *cmd_buf = "STSLVL on, on";
	char buf[255]={0};
	struct obd_ obd_data;
	short int rc = 0;

	rc = obd_read_data(cmd_buf,buf,&obd_data);
	if (rc == -1)
		printf("obd_read_data rc = -1\n");

		printf("voltage sleep, wake trigger on\r\n");
	return 0; 
}

int only_sleep_trigger_on()
{
	char cmd[30]={0}, buf[255]={0};
	struct obd_ obd_data;

	sprintf(cmd, "%s on, off\r", "STSLVL");
	obd_read_data(cmd,buf,&obd_data);

	printf("only voltage sleep trigger on\r\n");
	return 0; 
}

int set_voltage_sleep(float *volt_val)
{
	char cmd[30]={0}, buf[255]={0};
	struct obd_ obd_data;
	int ret = 0;

	sprintf(cmd, "%s <13.2, 1\r","STSLVLS");

	obd_read_data(cmd,buf,&obd_data);
	printf("voltage sleep trigger configured\r\n");

	return 0; 
}

int set_voltage_wake(float *volt_val)
{
	char cmd[128] = {0},buf[255]={0};
	struct obd_ obd_data;

	sprintf(cmd, "%s <%f, 1\r","STSLVLW", *volt_val);

	obd_read_data(cmd,buf,&obd_data);
	printf("voltage wake up trigger configured\r\n");

	return 0; 
}

int volt_change_wake_trigger_on()
{
	char *cmd_buf="STSLVG on";
	char buf[255]={0};
	struct obd_ obd_data;

	obd_read_data(cmd_buf,buf,&obd_data);

	printf("voltage change wake trigger on success \r\n");
	return 0;
}

int volt_change_wake_trigger_off()
{
	char cmd[30]={0}, buf[255]={0};
	struct obd_ obd_data;

	sprintf(cmd, "%s off\r","STSLVG");

	obd_read_data(cmd,buf,&obd_data);

	printf("voltage change wake trigger off\r\n");

	return 0;
}

int config_volt_change_wake_trigger()
{
	char cmd[30]={0},buf[255]={0};
	struct obd_ obd_data;

	sprintf(cmd, "%s 0.8, 750\r","STSLVGW");

	obd_read_data(cmd,buf,&obd_data);

	printf("voltage change wake trigger on\r\n");

	return 0;
}

int obd_reset()
{
	char *cmd_buf = "ATZ";
	char buf[255]={0};
	struct obd_ obd_data;

	obd_read_data(cmd_buf,buf,&obd_data);

	printf("OBD reset is done\r\n");

	return 0;
} 

int obd_read_dtc(char *buf_in,char *buf)
{
	struct obd_ obd_data;

	obd_read_data(buf_in,buf,&obd_data);

	return 0;
}

int obd_read_data(char *buf_in,char * buf,struct obd_ * out_obd_data) 
{

	int ret;
	char cmd[30]={0};
	printf("obd_sem w\n");
	sem_wait(&libClient.obd_sem);
	printf("obd_sem g\n");

	if (strcmp(buf_in,"ATSP") == 0)
		sprintf(cmd, "%s %s\r",buf_in, "0");
	else
		sprintf(cmd, "%s\r",buf_in);

	send_command(cmd);
	receive_data(cmd,buf);

	ret = parse_ign_status(buf,out_obd_data);

	if(ret != 0){
		printf("obd_sem fp+\n");
		sem_post(&libClient.obd_sem);
		printf("obd_sem fp-\n");
		return -1;
	}
	printf("obd_sem p+\n");
	sem_post(&libClient.obd_sem);
	printf("obd_sem p-\n");
	return 0;
}

int obd_init() 
{
	int rc = 0;
	char *cmd_buf;
	char buf[255] = {0};
	struct obd_ obd_data;

#if 0
	ret = write_sysfs_int ("value", "/sys/class/gpio/gpio32", 0);
        if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("1.acc_init: ret %d",ret);
                return ret;
        }
#endif

	rc = uart_init(DEV_NODE, BAUD_RATE);

	obd_reset();
	obd_reset();

	sleep_wake_trigger_off();

	volt_change_wake_trigger_off();

	obd_reset();
	/*No need to catch return value for other APi except uart_init*/
	/* set manually can protocol */
	cmd_buf = "ATSP";
	obd_read_data(cmd_buf,buf,&obd_data);


	/* send engine rpm command to initialise*/
	cmd_buf = "010C";
	obd_read_data(cmd_buf,buf,&obd_data);

	/* NaND : Failed case handling */

exit:
	return rc;
}
