#include"thread.h"
#include <stdio.h>
#include"init.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "common.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "can_header.h"

extern sem_t *sem_ser;

int pm_thread (void)
{
	FILE *ntp_fp;
	int ret;
	FILE *fp;
	char buf[255] = {0}, command[255] = {0};
	char *intf_conf;
	int con_status =0;
	short count = 0;

	sem_ser = sem_open(SNAME, O_CREAT, 0644, 1);// added for server and firmware synchronization 

	ntp_fp = fopen("/home/root/link_status.txt","w");
	fclose(ntp_fp);
	/* Create link status thread */
	if (pthread_create(&(libClient.tid[1]), NULL, (void*) link_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL2 ("link thread created\n");

	if(pthread_create(&(libClient.tid[3]), NULL, (void *) key_event_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL2("key_event_thread created\n");

	sem_init(&libClient.sem_board_init,0,0);	
	if(pthread_create(&(libClient.tid[5]), NULL, (void *) board_thread, NULL) != 0) 
	{
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}

	ntp_fp = fopen("/home/root/ntp_update.txt", "w");
	fclose(ntp_fp);

	ntp_fp = fopen("/home/root/mode.txt", "w");
	fclose(ntp_fp);

	int len,rc;
	struct ign_stat ign_qdata;
	char ts[64] = {0};
	while (1)
	{
		memset(ts,0,sizeof(ts));
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));

		len = mq_receive(libClient.pwr_mgmt_qid,(char *) &ign_qdata, sizeof(struct ign_stat), NULL);
		printf("in pm_thread Receive len = %d, errno =%d\r\n",len,errno);
		printf("msg_type = %d\r\n", ign_qdata.msg_type);
		strcpy(ts,ign_qdata.data);

		switch(ign_qdata.msg_type)
		{
			case PM_EVENT_IGN_ON_NORMAL:
				printf("PM_EVENT_IGN_ON_NORMAL\r\n");
				update_device_state(&libClient,libClient.state,OBDII_IGNON_NORMAL);
				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_IGNON_NORMAL_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}
				else
					printf("invalid ignition_on function address\n");
				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_NORMAL);
				break;
			case PM_EVENT_IGN_ON_RESTART:

				printf("PM_EVENT_IGN_ON_RESTART\r\n");
				libClient.dev_sleep = DEV_WAKE;
				/* Get the semaphoreTIMER_ENABLE and start */
				sem_wait(&libClient.sys_wake);	
				/*!< Switch on power rail */
				switch_on_power_rail ();				
				tcflush(libClient.serial_intf.tty_fd, TCIOFLUSH);

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_TRIGGER_OFF);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_IGN_ON_RESTART: config_sleep_wake_trigger_off");
				config_sleep_wake_trigger_off();
#ifdef __TIMER__	
				config_wakeup_timer_trigger(TIMER_DISABLE,NO_SLEEP_TIME);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_IGN_ON_RESTART: TIMER DISABLED!!!!!!!");
#endif
				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_BOARD_INIT);
				
				/* Wake Board init thread */
				sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_WAIT);
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_RESTART);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_COMPLETED);

				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}
				else
					printf("invalid ignition_on function address\n");

				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_RESTART);
				break;

			case PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE:

				printf("PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE\r\n");
				libClient.dev_sleep = DEV_WAKE;
				/* Get the semaphore and start */
				sem_wait(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
				//config_sleep_wake_trigger_off();

				/* Wake Board init thread */
				update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
				sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);

				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_VC_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}
				else
					printf("invalid ignition_on function address\n");

				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE);	
				break;

			case PM_EVENT_ACCEL_WAKE:

				printf("PM_EVENT_ACCEL_WAKE+\r\n");

                                sem_wait(&libClient.sys_wake);

				printf("PM_EVENT_ACCEL_WAKE-\r\n");
                                update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
                                /* Wake Board init thread */
                                update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
                                /*Release board_init Semaphore*/
                                //sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
				system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
				system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
				system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
				system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled

				switch_on_power_rail();
				board_init_4g_uart();
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_ACCEL_WAKE);
				/* Release the semaphore */
				sem_post(&libClient.sys_wake);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);

                                if(libClient.ign_fptr.crash_det != NULL){
                                        update_device_state(&libClient,libClient.state,OBDII_CRASH_DETECT_INDICATE_TO_APP);
                                        libClient.ign_fptr.crash_det(ts);
                                        /*Peru: Check it any sync required*/
                                        //wait_for_indicate_disconnect_completed(); 
                                        update_device_state(&libClient,libClient.state,OBDII_CRASH_DETECT_INDICATE_APP_COMPLETE);
                                }
                                /*push device to sleep*/
                                push_device_to_sleep(&libClient);
                                break;

			case PM_EVENT_SLEEP_DISCONNECTION :

				/*interpretter wakeup trigger OFF*/
				//config_sleep_wake_trigger_off();
				/*configuring the timer for 15min*/
#ifdef __TIMER__	
				config_wakeup_timer_trigger(TIMER_ENABLE,SLEEP_TIME);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_SLEEP_DISCONNECTION: TIMER CONFIGURED FOR 15MIN WAKEUP!!!!!!!");
#endif
				sem_wait(&libClient.sys_wake);
				update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
				/* Wake Board init thread */
                                update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
				/*Release board_init Semaphore*/
                                sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
                                /* Wait till board and Application initializes */
                                wait_for_sys_wake_completed(PM_EVENT_SLEEP_DISCONNECTION);
				/* Release the semaphore */
                                sem_post(&libClient.sys_wake);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);
				
				if(libClient.ign_fptr.dis_stat != NULL){
					update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_TO_APP);
					libClient.ign_fptr.dis_stat(ts);
					/*Peru: Check it any sync required*/
					//wait_for_indicate_disconnect_completed(); 
					update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_APP_COMPLETE);
				}
				/*push device to sleep*/
				push_device_to_sleep(&libClient);
                                break;

			case PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP:

				printf("PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP\r\n");

				libClient.dev_sleep = DEV_WAKE;
				/* Get the semaphore and start */
				sem_wait(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_BD_SW_TRIGGER_OFF);
				//config_sleep_wake_trigger_off();

				update_device_state(&libClient,libClient.state,OBDII_BD_BOARD_INIT);

				/* Wake Board init thread */
				sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_BD_SW_WAIT);
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	
				update_device_state(&libClient,libClient.state,OBDII_BD_SW_COMPLETED);

				if(libClient.ign_fptr.bat_drain != NULL){
					update_device_state(&libClient,libClient.state,OBDII_BD_INDICATE_APP);
					libClient.ign_fptr.bat_drain(ts);

					/* Get the semaphore and start */
					sem_wait(&libClient.btry_drain);

					wait_for_indicate_battery_drain_completed();

					/* Release the semaphore */                      
					sem_post(&libClient.btry_drain);
					update_device_state(&libClient,libClient.state,OBDII_BD_INDICATE_COMPLETED);
				}
				else
					printf("invalid ignition_off function address\n");

				push_device_to_sleep(&libClient);
				break;

			case PM_EVENT_IGN_OFF_NORMAL:

				printf("PM_EVENT_IGN_OFF_NORMAL\r\n");
				/* Get the semaphore and start */
				sem_wait(&libClient.ign_of_sem);

				update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL);
				if(libClient.ign_fptr.ign_OFF != NULL){
					printf("before calling ignition_off Call back function\n");
					//sem_wait(&ign_off_sem);//Peru : Added for missing Ignition off packet
					update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL_INDICATE_APP);
					libClient.ign_fptr.ign_OFF(ts);
					wait_for_indicate_ignition_off_completed();

					update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL_INDICATE_APP_COMPLETED);
				}
				else
					printf("invalid ignition_off function address\n");

				/* Release the semaphore */
				sem_post(&libClient.ign_of_sem);	

				push_device_to_sleep(&libClient);
				libClient.dev_sleep = DEV_SLEEP;
				break;

			case PM_EVENT_WAKE_DISCONNECTION:
				
				/*configuring the timer for 15min*/	
#ifdef __TIMER__	
				config_wakeup_timer_trigger(TIMER_ENABLE,SLEEP_TIME);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_WAKE_DISCONNECTION: TIMER CONFIGURED FOR 15MIN WAKEUP!!!!!!!");
#endif
				/* Get the semaphore and start */
				sem_wait(&libClient.ign_of_dis);
			
				update_device_state(&libClient,libClient.state,OBDII_REMOVE_DEVICE_REMOVED);
#if 0
				if(access(USB_2,F_OK)){	
					IOBD_DEBUG_LEVEL3 ("Module disconnected\n");
					update_device_state(&libClient,libClient.state,OBDII_REMOVE_SWITCH_MXC5);

					memset(buf, 0, 255);
					strcpy(buf, "/dev/ttymxc5");
					fp = fopen("/etc/ppp/peers/gprs_4g", "r+");
					fwrite(buf, strlen(buf), 1, fp);
					fclose(fp);
				}
#endif
					update_device_state(&libClient,libClient.state,OBDII_REMOVE_WAIT_FOR_PPP);

					/* Wait for connection for 40 seconds, If no network, go to sleep */
					while(1){
						con_status = check_connection();
						IOBD_DEBUG_LEVEL3 ("con_status: %d\r\n", con_status);
						if (con_status == 1 ){
							/* sending disconnection status */
							if(libClient.ign_fptr.dis_stat != NULL){
								update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_TO_APP);
								libClient.ign_fptr.dis_stat(ts);
								/*Peru: Check it any sync required*/
								//wait_for_indicate_disconnect_completed(); 
								update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_APP_COMPLETE);
							}
							break;
						}
						sleep(1);
						count++;
						if (count == 40)
							break;
						else
							IOBD_DEBUG_LEVEL3 ("count is %d\n",count);
					}
				

				/* Release the semaphore */
				sem_post(&libClient.ign_of_dis);

				push_device_to_sleep(&libClient);
				libClient.dev_sleep = DEV_SLEEP;
				break;
			default:
				IOBD_DEBUG_LEVEL3 ("Invalid packet type for power management \n");
		}
	}
}


int switch_on_power_rail ()
{
	int rc = 0;

	/*!< 12 V Switch */
	IOBD_DEBUG_LEVEL2 ("12 V Regulator on");
	rc = system("echo 1 > /sys/class/gpio/gpio92/value");
	/*!< 3V3 Switch */
	rc = system("echo 1 > /sys/class/gpio/gpio91/value");
	/*!< 4V4 Switch */
	IOBD_DEBUG_LEVEL2 ("4V4 Regulator on");
	rc = system("echo 1 > /sys/class/gpio/gpio90/value");
	/*!< Interpreter CAN ON */
	rc = system("echo 0 > /sys/class/gpio/gpio32/value");
	/*!< CPU CAN OFF */
	rc = system("echo 1 > /sys/class/gpio/gpio67/value");
	
	return rc;
}

int switch_off_power_rail ()
{
	IOBD_DEBUG_LEVEL2 ("12 V Regulator off");
	system("echo 0 > /sys/class/gpio/gpio92/value");
	IOBD_DEBUG_LEVEL2 ("4V4 Regulator off");
	system("echo 0 > /sys/class/gpio/gpio90/value");
	IOBD_DEBUG_LEVEL2 ("3V3 Regulator off");
	system("echo 0 > /sys/class/gpio/gpio91/value");
	/*!< Interpreter CAN SHUTDOWN */
	IOBD_DEBUG_LEVEL2 ("Interpreter CAN SHUTDOWN");
	system("echo 1 > /sys/class/gpio/gpio32/value");
	/*!< CPU CAN SHUTDOWN */
	IOBD_DEBUG_LEVEL2 ("CPU CAN SHUTDOWN");
	system("echo 1 > /sys/class/gpio/gpio67/value");
}

int push_device_to_sleep(_libClient * libclient,int type)
{
	struct ign_stat ign_qdata;
	char ts[64] = {0};
	int rc = 0;
	printf("push_device_to_sleep type %d \n",type);

	update_device_state(&libClient,libClient.state,OBDII_OFF_START_SLEEP);
	if(libclient->s_w.slp != NULL){
		update_device_state(&libClient,libClient.state,OBDII_OFF_SLEEP_INDICATE_TO_APP);
		printf(" Call application sleep handler callback \n");
		libclient->s_w.slp();
	}
	else{
		printf("Sleep handler not provided for application \n");
	}

	update_device_state(&libClient,libClient.state,OBDII_OFF_4G_SWITCHING_OFF);
	rc = module_3g_off();
	update_device_state(&libClient,libClient.state,OBDII_OFF_4G_OFF);
	if(rc == DEVICE_RESTART){
		return DEVICE_RESTART;
	}

	rc = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
#ifdef __TIMER__
	if (rc == IGNITION_STATE_OFF)
		config_wakeup_timer_trigger(TIMER_DISABLE,NO_SLEEP_TIME);
#endif
	printf("pm_thread ret is %d\r\n", rc);
	if(rc == IGNITION_STATE_ON)
	{
		get_time(ts);
		memset(ign_qdata.data,0x0,256);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		printf("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
		rc = send_ign_q(libclient,&ign_qdata);
		return DEVICE_RESTART;
	}

	update_device_state(&libClient,libClient.state,OBDII_OFF_TRIGGER_OFF);
	printf("****************calling sleep wake trigger on **************\r\n");
	rc = config_sleep_wake_trigger_on();
	if (rc == IGNITION_STATE_ON_RESTART)
		return DEVICE_RESTART;
#ifdef __TIMER__
	else if (rc == IGNITION_STATE_OFF)
		config_wakeup_timer_trigger(TIMER_DISABLE,NO_SLEEP_TIME);
#endif
	update_device_state(&libClient,libClient.state,OBDII_OFF_GPIO_OFF);

	switch_off_power_rail ();	
	libClient.system_wake_timer = 0;
	libClient.system_wake_acc = 0;
	update_device_state(&libClient,libClient.state,OBDII_OFF_SLEEP);
	rc = check_interpretter_sleep ();
	return 0;
}

int check_interpretter_sleep ()
{
	int ret = 0;
	struct timespec time_out;
	char ts[64] = {0};
        struct ign_stat ign_qdata;

	IOBD_DEBUG_LEVEL3 ("inside wait_for_3_sec_check_interpretter_sleep");

	if (clock_gettime(CLOCK_REALTIME, &time_out) == -1)
		IOBD_DEBUG_LEVEL3 ("clock_gettime error");
	time_out.tv_sec += 10;
	ret = sem_timedwait( &libClient.ign_off_restart, &time_out );
	if(ret < 0){
		IOBD_DEBUG_LEVEL3(" sem_wait returned. errno %d \n",errno);
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));
		get_time(ts);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		IOBD_DEBUG_LEVEL3("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
		send_ign_q(&libClient,&ign_qdata);
	}
		IOBD_DEBUG_LEVEL3("wait_for_3_sec_check_interpretter_sleep %d\n",ret);

return ret;
}
int wait_for_indicate_battery_drain_completed()
{
	/* Wait until Application indicates sys wake */
	printf("wait_for_indicate_disconnect_completed  + \n");
	sem_wait(&libClient.btry_drain);	
	printf("wait_for_indicate_disconnect_completed - \n");

}


int wait_for_indicate_disconnect_completed()
{
	/* Wait until Application indicates sys wake */
	printf("wait_for_indicate_disconnect_completed  + \n");
	sem_wait(&libClient.ign_of_dis);	
	printf("wait_for_indicate_disconnect_completed - \n");

}

int wait_for_indicate_ignition_off_completed()
{
	int ret = 0;
	struct timespec time_out;

	/* Wait for the semaphore with timeout.
	   Otherwise device will not move to power save mode,
	   if application fails to indicate the ignition off completion
	 */

	if (clock_gettime(CLOCK_REALTIME, &time_out) == -1)
	{
		printf("clock_get_time error \n");

		/* If get time fails, go without timeout */
		printf("wait_for_indicate_ignition_off_completed  + \n");
		/* Wait until Application indicates sys wake */
		sem_wait(&libClient.ign_of_sem);	
		printf("wait_for_indicate_ignition_off_completed - \n");

	}
	else{

		time_out.tv_sec += 60;

		printf("wait_for_indicate_ignition_off_completed  + \n");
		/* Wait until Application indicates sys wake or till timeout */
		ret = sem_timedwait( &libClient.ign_of_sem, &time_out );
		printf("wait_for_indicate_ignition_off_completed - \n");
		if(ret < 0)
		{
			if(errno == ETIMEDOUT)
				printf(" sem_wait returned due to timeout \n");
			else
				printf(" sem_wait returned. errno %d \n",errno);
		}

	}
}

int wait_for_sys_wake_completed(int type)
{
	/* Wait until Application indicates sys wake */
	printf("wait_for_sys_wake_completed type %d + \n",type);
	sem_wait(&libClient.sys_wake);	
	printf("wait_for_sys_wake_completed type %d - \n",type);

}


int start_ignition_thread(_libClient * libclient,int type)
{
	printf("start_ignition_thread type %d + \n",type);
	update_device_state(&libClient,libClient.state,OBDII_RUNNING);
	sem_post(&libclient->ign_t_sem);
}

int update_device_state(_libClient * libclient,int prev_state,int new_state)
{
	printf("Device state moving from (%d) -> (%d) \n",prev_state,new_state);
	libclient->state = new_state;
	return 0;
}


void ignition_thread (void)
{
	struct ign_stat ign_qdata;
	int len = 0;
	float voltage_value;
	printf("ignition_thread is started \n");
	int rc = 0;
	char ts[64] = {0};

	while (libClient.obdflag !=1)
	{
		sleep(1);
	}
	printf("while ignition thread............ \n");
	while(1)
	{
		/* check for ignition status */
		printf("get ign_t_sem +\n");
		/* If some data has sent to power management thread, then pm_thread will release the semaphore.
		   Otherwise, own thread will post
		 */

		/* Get the semaphore and start */
		sem_wait(&libClient.ign_t_sem);
		printf("get ign_t_sem -\n");

		rc = check_ign_status(IGNITION_STAT_WITH_DIP);
		/* ToDo NaNC : this thread is blocking obd_read_dat. sleep(1) */
		sleep(1);
		/* send ignition on status */
		if(rc == IGNITION_STATE_ON && libClient.state == OBDII_INIT)
		{
			printf("inside ign_on \n");
			printf("Ignition is ON!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_IGN_ON_NORMAL;
			printf("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);
			printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
			rc = send_ign_q(&libClient,&ign_qdata);

		}			
		else if(rc == IGNITION_STATE_OFF)
		{
			printf("Ignition is IGN_OFF_NORMAL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_IGN_OFF_NORMAL;
			printf("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);

			printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
			rc = send_ign_q(&libClient,&ign_qdata);

		}
		else if(rc == IGNITION_STATE_DEVICE_REMOVED)
		{
			printf("Ignition is IGNITION_STATE_DEVICE_REMOVED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_WAKE_DISCONNECTION;
			printf("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);
			printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
			rc = send_ign_q(&libClient,&ign_qdata);

		}
		else{
			printf("post ign_t_sem +\n");
			sem_post(&libClient.ign_t_sem);
			printf("post ign_t_sem +\n");
		}
	}
}


