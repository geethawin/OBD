#include "q_gps.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include "init.h"

int agps_init()
{
	int rc;

	rc = system("/home/root/example -token aeu2IC0knkmvwWCvvXUYJQ -test online -p /dev/ttymxc2 -b 9600 -gnss gps/glo");
	if (rc == -1)
		printf("AGPS_INIT FAILED\n");
	else
		printf("AGPS_INIT SUCCESS\n");
	return rc;
}

int gps_init(void)
{
	int fd;
	if ((fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1)
	{
		printf("Cannot open output file\r\n");
		exit(1);
	}

	/* NaNC : */
	return fd;
}

void gps_deinit(int gps_fd)
{
	sleep(2); //required to make flush work, for some reason
	tcflush(gps_fd,TCIOFLUSH);
	close(gps_fd);

}

/*
   RMC,225446.33,A,4916.45,N,12311.12,W,000.5,054.7,191194,020.3,E,A*68
   225446.33    Time of fix 22:54:46 UTC
   A            Status of Fix A = Autonomous, valid; 
   D = Differential, valid; V = invalid
   4916.45,N    Latitude 49 deg. 16.45 min North
   12311.12,W   Longitude 123 deg. 11.12 min West
   000.5        Speed over ground, Knots
   054.7        Course Made Good, True north
   191194       Date of fix  19 November 1994
   020.3,E      Magnetic variation 20.3 deg East
   A            FAA mode indicator (NMEA 2.3 and later)
   A=autonomous, D=differential, E=Estimated,
   N=not valid, S=Simulator, M=Manual input mode
 *68          mandatory nmea_checksum

 * SiRF chipsets don't return either Mode Indicator or magnetic variation.
 */
#if 0
int ParseGNRMC(struct gps_rmc_t *gps_rmc, char buf[200], size_t nbytes)
{
	int j,k,l;
	int ret;
	static int gprs_set = 0;
	char field[15][100];
	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(buf[j] != ',') && (buf[j] != '\0');k++,j++)
		{
			field[l][k] = buf[j];
		}
		field[l][k] = '\0';
		k=0;
	}

	memset(gps_rmc,0,sizeof(struct gps_rmc_t));
	gps_rmc->hour = atoi(field[TIME_STAMP]) / 10000;
	gps_rmc->minutes = (atoi(field[TIME_STAMP])/100) % 100;
	gps_rmc->seconds = atoi(field[TIME_STAMP]) % 100;

	if(*field[FIX_STATUS] != 'A'){
		printf("\nGPS Not Valid\n");
		gps_rmc->gps_valid = 0;

	}
	else
	{
		if (libClient.gps_init_fix == 0){
			libClient.gps_init_fix = 1;
		}

		printf("GPS is Valid!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
		gps_rmc->latitude = (fmod(atof(field[CUR_LATITUDE]),100.00)/60) +  (atoi(field[CUR_LATITUDE])/100);

		if (*field[HEMISPHERE] != 'N')
			gps_rmc->latitude = -gps_rmc->latitude;

		gps_rmc->longitude = (fmod(atof(field[CUR_LONGITUDE]),100.00)/60 ) + (atoi(field[CUR_LONGITUDE])/100);
		if (*field[GREENWICH] != 'E')
			gps_rmc->longitude = -gps_rmc->longitude;

		//	gps_rmc->direction = atof(field[DIRECTION]);
		gps_rmc->gps_valid = 1;
		//	printf("Lat : %f lon : gps_rmc->longitude: %f  gps_rmc->speed : %f gps_rmc->direction:%f \n",gps_rmc->latitude,gps_rmc->longitude, gps_rmc->speed,gps_rmc->direction);
		//	printf("Lat : %f lon : %f gps_rmc->gps_valid %d\n",gps_rmc->latitude,gps_rmc->longitude,gps_rmc->gps_valid);
	}
	gps_rmc->gps_init_fix = libClient.gps_init_fix;
	return libClient.gps_init_fix;
}


int get_gps_data(struct gps_rmc_t *gps_rmc)
{
	char dummy_buf[8*1024];
	int rc = 0;
	struct timeval gps_start_time,gps_end_time;
	gettimeofday(&gps_start_time, NULL);
	/*peru : for synchronisation*/

	printf("gps w+ \n");
	sem_wait(&libClient.gps_sem);
	printf("gps w- \n");
	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			read(libClient.gps_fd, &dummy_buf, 8*1024);
			libClient.gps_node_open = 1;
		}
	}
	rc = get_gps_vals(libClient.gps_fd,gps_rmc);
	gettimeofday(&gps_end_time, NULL);
	libClient.run_time.gps_duration = ((gps_end_time.tv_usec - gps_start_time.tv_usec) + (gps_end_time.tv_sec - gps_start_time.tv_sec)*1000000)/1000;
	printf("gps p+ \n");
	sem_post(&libClient.gps_sem);
	printf("gps p- \n");
	return rc;	
}
#endif
int get_gps_rmc_data(char * rmc_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[500];
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	int c = 0;
	char buf[200];

	memset(buf,'\0',sizeof(buf));

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("GPS_NODE OPENED\n");
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 500);
		}
	}
	//	tcflush(libClient.gps_fd,TCIOFLUSH);
	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if( (strncmp(buf, "GNRMC", 5) == 0) )
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
					if(char_read == '*')
						break;
				}
				break;
			}
		}
	}


	*g_nbytes = nbytes;
	strcpy(rmc_nmea,buf);
//	printf("buf %s nbytes %d \n",buf,nbytes);
	printf("rmc_nmea %s g_nbytes %d \n",rmc_nmea,*g_nbytes);
	return rc;
}

int get_gps_gsv_data(char * gsv_nmea, size_t * g_nbytes)
{

	char char_read;
	char dummy_buf[8*1024];
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char command[100] = {0};
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	//tcflush(libClient.gps_fd,TCIOFLUSH);

	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GPGSV", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
					if(char_read == '*')
						break;
				}
				break;
			}
		}
	}               

	*g_nbytes = nbytes;
	strcpy(gsv_nmea,buf);

//	printf("gsv buf %s nbytes %d \n",buf,nbytes);
	printf("gsv_nmea %s g_nbytes %d \n",gsv_nmea,*g_nbytes);

	return rc; 
}

int get_gps_gga_data(char * gga_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	//tcflush(libClient.gps_fd,TCIOFLUSH);

	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNGGA", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}

	*g_nbytes = nbytes;
	strcpy(gga_nmea,buf);

//	printf("gga_nmea buf %s nbytes %d \n",buf,nbytes);
	printf("gga_nmea %s g_nbytes %d \n",gga_nmea,*g_nbytes);

	return rc;
}
#if 0
int get_gps_vtg_data(char * vtg_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char command[100] = {0};
	char buf[200] = {0};

	bzero(buf,sizeof(buf));

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	tcflush(libClient.gps_fd,TCIOFLUSH);

	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNVTG", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}

	*g_nbytes = nbytes;
	memcpy(vtg_nmea, buf, nbytes);

	printf("vtg_nmea buf %s nbytes %d \n",buf,nbytes);
	printf("vtg_nmea %s g_nbytes %d \n",vtg_nmea,*g_nbytes);

	return rc;
}
#endif

int get_gps_gsa_data(char * gsa_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			printf("Cannot open output file\r\n");
		}
		else{
			printf("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

//	tcflush(libClient.gps_fd,TCIOFLUSH);

	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNGSA", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}

	*g_nbytes = nbytes;
	strcpy(gsa_nmea, buf);

//	printf(" gsa_nmea buf %s nbytes %d \n",buf,nbytes);
	printf("gsa_nmea %s g_nbytes %d \n",gsa_nmea,*g_nbytes);

	return rc;
}


#if 0
void enable_only_rmc()
{
	int rc = 0;
	printf("inside enable_only_rmc\n");
	rc = system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x02\x00\x00\x00\x00\x00\x01\x02\x32"" > /dev/ttymxc2");//GSA
	if(rc < 0)
		printf("GSA disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x05\x00\x00\x00\x00\x00\x00\x04\x46"" > /dev/ttymxc2");//VTG
	if(rc < 0)
		printf("VTG disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x03\x00\x00\x00\x00\x00\x00\x02\x38"" > /dev/ttymxc2");//GSV
	if(rc < 0)
		printf("GSV disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x01\x00\x00\x00\x00\x00\x00\x00\x2A"" > /dev/ttymxc2");//GLL
	if(rc < 0)
		printf("GLL disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x00\x00\x00\x00\x00\x00\x00\xFF\x23"" > /dev/ttymxc2");//GGA
	if(rc < 0)
		printf("GGA disable failed");

	printf("exit enable_only_rmc\n");

}

int get_gps_vals(int gps_fd, struct gps_rmc_t *gps_rmc)
{
	char buf[200];
	char char_read;
	int ret;
	size_t nbytes;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char command[100];

	//printf("get_gps_vals+ \n");
	while(1)
	{
		counter++;
		bytes_read = read(gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if( (strncmp(buf, "GNRMC", 5) == 0) )
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					read(gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				//printf("%s\n",buf);
				rc = ParseGNRMC(gps_rmc, buf, nbytes);
				break;
			}
		}
	}
	//printf("get_gps_vals - \n");
	return rc;
}

#endif
