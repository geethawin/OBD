/* headers */
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <linux/input.h>
#include "acc_mma8451.h"
#include "init.h"


int get_accelerometer_event() {

	int event_no = 0, i = 0;
	FILE *fp;
	char command[100];
	char *intf_conf;
	char file[256];

	system("cat /sys/class/input/input0/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mma");
	if(intf_conf) {
		event_no = 0;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input1/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mma");
	if(intf_conf) {
		event_no = 1;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input2/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mma");
	if(intf_conf) {
		event_no = 2;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);

	system("rm -rf event.txt");

	system("cat /sys/class/input/input3/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mma");
	if(intf_conf) {
		event_no = 3;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input4/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mma");
	if(intf_conf) {
		event_no = 4;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");
}


int acc_init()
{
	int acc_event_no = 0;
	char acc_event_name[128] = {0};
	acc_event_no = get_accelerometer_event();

	system("i2cset -f -y 1 0x1C 0x0E 0x00");
	system("i2cset -f -y 1 0x1C 0x2A 0x02");
	system("i2cset -f -y 1 0x1C 0x2B 0x3D");

	sprintf(acc_event_name,"echo 1 > /sys/class/input/input%d/enable",acc_event_no);
	printf("accelerometer event name %s \n",acc_event_name);

	system(acc_event_name);
	return 0;
}
int acc_deinit()
{
	int acc_event_no = 0;
	char acc_event_name[128] = {0};
	acc_event_no = get_accelerometer_event();

	printf(" acc_deinit +\n");

	sprintf(acc_event_name,"echo 0 > /sys/class/input/input%d/enable",acc_event_no);

	printf("accelerometer event name %s \n",acc_event_name);
	system(acc_event_name);

	printf(" acc_deinit -\n");

	return 0;
}

/* Accelerometer read function reads raw data */
int accelerometer_read(accelerometer_api_priv *adata)
{
	char command[100]={0};
	FILE *fp;
	char x_msb[2], x_lsb[2];
	int x, xmsb, xlsb; 
	char y_msb[2], y_lsb[2];
	long y, ymsb, ylsb; 
	char z_msb[2], z_lsb[2];
	long z, zmsb, zlsb; 
	int rc = 0;

	strcpy(command,"i2cget -f -y 1 0x1C 0x01 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("1 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}
	fread(&x_msb[0], 1, 1, fp);
	fread(&x_msb[1], 1, 1, fp);
	fread(&x_msb[0], 1, 1, fp);
	fread(&x_msb[1], 1, 1, fp);
	x_msb[2]='\0';
	xmsb = (int)strtol(x_msb, NULL, 16);
	fclose(fp);

	strcpy(command,"i2cget -f -y 1 0x1C 0x02 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("2 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}
	fread(&x_lsb[0], 1, 1, fp);
	fread(&x_lsb[1], 1, 1, fp);
	fread(&x_lsb[0], 1, 1, fp);
	fread(&x_lsb[1], 1, 1, fp);
	x_lsb[2]='\0';
	xlsb = (int)strtol(x_lsb, NULL, 16);
	fclose(fp);

	adata->x = (xmsb << 8 | xlsb);

	strcpy(command,"i2cget -f -y 1 0x1C 0x03 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("3 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}

	fread(&y_msb[0], 1, 1, fp);
	fread(&y_msb[1], 1, 1, fp);
	fread(&y_msb[0], 1, 1, fp);
	fread(&y_msb[1], 1, 1, fp);
	y_msb[2]='\0';
	ymsb = (int)strtol(y_msb, NULL, 16);
	fclose(fp);

	strcpy(command,"i2cget -f -y 1 0x1C 0x04 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("4 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}
	fread(&y_lsb[0], 1, 1, fp);
	fread(&y_lsb[1], 1, 1, fp);
	fread(&y_lsb[0], 1, 1, fp);
	fread(&y_lsb[1], 1, 1, fp);
	y_lsb[2]='\0';
	ylsb = (int)strtol(y_lsb, NULL, 16);
	fclose(fp);

	adata->y = (ymsb << 8 | ylsb);

	strcpy(command,"i2cget -f -y 1 0x1C 0x05 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("5 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}
	fread(&z_msb[0], 1, 1, fp);
	fread(&z_msb[1], 1, 1, fp);
	fread(&z_msb[0], 1, 1, fp);
	fread(&z_msb[1], 1, 1, fp);
	z_msb[2]='\0';
	zmsb = (int)strtol(z_msb, NULL, 16);
	fclose(fp);

	strcpy(command,"i2cget -f -y 1 0x1C 0x06 > acc.txt");
	system(command);
	fp = fopen("acc.txt","r");
	if(fp < 0)
	{
		printf("6 Failed to open acc.txt errno %d \n",errno);
		rc = -1;
		goto exit;
	}
	fread(&z_lsb[0], 1, 1, fp);
	fread(&z_lsb[1], 1, 1, fp);
	fread(&z_lsb[0], 1, 1, fp);
	fread(&z_lsb[1], 1, 1, fp);
	z_lsb[2]='\0';
	zlsb = (int)strtol(z_lsb, NULL, 16);
	fclose(fp);

	adata->z = (zmsb << 8 | zlsb);

	usleep(100000);
exit:
	printf("return rc %d \n",rc);
	return rc;
}


int get_accelerometer(accelerometer_api_priv *adata)
{
	int rc = 0;
	struct timeval acc_start_time,acc_end_time;
	gettimeofday(&acc_start_time, NULL);
	rc = accelerometer_read(adata);
	gettimeofday(&acc_end_time, NULL);
	libClient.run_time.acc_duration = ((acc_end_time.tv_usec - acc_start_time.tv_usec) + (acc_end_time.tv_sec - acc_start_time.tv_sec)*1000000)/1000;
	if(rc < 0)
	{
		rc = -1;
		printf("accelerometer_read failed \n");
		goto exit;
	}

exit:
	printf("get_accelerometer returns %d \n",rc);
	return rc;
	/* NaND : adata must be of type accelerometer_api_priv. dont use char buffer */
}
