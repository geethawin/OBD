#include "battery.h"
#include <stdio.h>
#include "debug.h"

int i_battery_get_current()
{

	int fd;
	int ret_read;
	char var[50];
	int current = 0;


	fd = open(BATTERY_NODE "/current_now", O_RDONLY);

	if (fd > 0)
	{
		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		if( ret_read == -1 )
		{
			printf("File read failed\r\n");
		}else{

			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));
			current = atoi(var);
		}
		close(fd);
	}
	else {
		perror ("i_battery_get_current: open");
		IOBD_DEBUG_LEVEL3 ("File open error: %d",errno);
	}

	return current;
}

int i_battery_get_voltage()
{
	int fd;
	int ret_read;
	char var[50];
	int voltage = 0;

	fd = open(BATTERY_NODE "/voltage_now", O_RDONLY);

	if (fd > 0)
	{

		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		
		if(ret_read == OBD2_LIB_FAILURE)
		{
			perror ("i_battery_get_voltage: read");
			IOBD_DEBUG_LEVEL3("File read failed with errno : %d\r\n",errno);
		}else{

			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));

			voltage = atoi(var);
		}
			close(fd);

	}
	else {
		perror ("i_battery_get_voltage: open");
		IOBD_DEBUG_LEVEL3 ("File open error: %d",errno);
	}

	return voltage;
}

int i_battery_get_health()
{
	int fd;
	int ret_read;
	char var[50];
	int health = 0;
	int rc = 0;

	fd = open(BATTERY_NODE "/health", O_RDONLY);

	if (fd > 0)
	{
		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		if( ret_read == -1 )
		{
			printf("i_battery_get_health :File read failed %d\r\n",errno);
			close(fd);
			rc = -1;
		}
		else{
			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));
			printf("battery status is %s\n",var);
			health = strncmp(var, "Good", 4);
			close(fd);
			if (health == 0)
				rc = 1;
			else
				rc = 0;
		}
	}
	else{
		rc = -1;
		printf("i_battery_get_health node read error %d\n",errno);
	}
	return rc;
}

