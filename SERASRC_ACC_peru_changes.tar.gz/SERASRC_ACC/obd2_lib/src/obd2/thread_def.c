#include"thread.h"
#include"init.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "pwr_mgmt.h"
#include "can_header.h"

sem_t *sem_ser;
static int mod_init = 0;
IO_PIN_STATE gpio_pin;
int start_pm_client()
{

	/* Create power management thread */
	if (pthread_create(&(libClient.tid[0]), NULL, (void*) pm_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL1 (" pthread_create for power management failed. Closing APP \r\n");
		return -1;
	}
	else
		IOBD_DEBUG_LEVEL1("powermanagement thread is created\n");

	/* After board_init completes, pause will come out due to SIGUSR1 signal */
	sem_wait(&libClient.sem_board_init_complete);
	IOBD_DEBUG_LEVEL2("Board_init completed\n");

#ifdef __TIMER__
	if(pthread_create(&(libClient.tid[4]), NULL, (void *) timer_event_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for timer_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL2("timer_event_thread created\n");
#endif	


	IOBD_DEBUG_LEVEL2 ("Release semaphore\n");
	sem_post(&libClient.sem_board_init_complete);

	return 0;
}

int init_ign_dis_handler()
{
	printf(" init_ign_dis_handler car_mode %d \r\n",libClient.car_mode);

	if(libClient.car_mode == 1) {
		/* Create can thread */
		if (pthread_create(&(libClient.tid[7]), NULL, (void*) ignition_thread, NULL) != 0)
		{
			printf(" pthread_create for CAN failed. Closing APP \r\n");
			return -1;
		}
		else
			printf(" pthread_create ignition_thread created\r\n");
	}
	libClient.obdflag = 1;
	return 0;
}


int link_thread (void)
{
	printf("inside link thread\n");
	int read_event_ret = 0;
	struct sockaddr_nl addr;


	// Netlink socket creation
	int nl_socket = socket (AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	sem_init(&libClient.sem_ppp0_link_down, 0, 0);

	if(pthread_create(&(libClient.tid[2]), NULL, &link_status_thread, NULL)!= 0)
	{
		printf("error\r\n");
		return 0;
	}
	else
		printf("link status thread created\n");
	// Socket open error
	if (nl_socket < 0) {
		printf ("Netlink socket open error, error number %d\n", errno);
	} 
	else 
	{
		memset ((void *) &addr, 0, sizeof (addr));

		// Kernel user interface
		addr.nl_family = AF_NETLINK;

		// Get the process ID
		addr.nl_pid = getpid ();

		/* Listen to the RTMGRP_LINK (network interface create/delete/up/down events) 
		   and RTMGRP_IPV4_IFADDR (IPv4 addresses add/delete events) */
		addr.nl_groups = RTMGRP_LINK | RTMGRP_IPV4_IFADDR | RTMGRP_IPV6_IFADDR;
		// Bind the socket an address to netlink group
		if (bind (nl_socket, (struct sockaddr *) &addr, sizeof (addr)) < 0) 
			printf ("Netlink socket bind failed, error number %d\n", errno);

		else 
		{
			while (1) 
			{
				read_event_ret = read_event (nl_socket);
				if (read_event_ret < 0) 
					printf ("Netlink read_event() error, error number %d\n", errno);

			}
		}
	}
	return 0;



}

void* link_status_thread(void *arg)
{
	pthread_t id = pthread_self();
	int try_count = 0;


	if(pthread_equal(id,libClient.tid[2])){
		while(1){
			printf("wait for semaphore in link_status_thread\r\n");
			sem_wait(&libClient.sem_ppp0_link_down);
			do{
				if (!access(USB_2,F_OK)){
					if (mod_init == 1){
						printf("calling pppd \r\n");
						system("pppd call gprs_4g");//added bec it takes 15 seconds to establish connection
						try_count++;
						printf("count %d\r\n",try_count);
						if(try_count == 20 && (!access(USB_2,F_OK))){
							flight_mode();
							try_count = 0;
						}
						system("pppd call gprs_4g");
					}
				}
				sleep(1);

			}while(libClient.ppp0_link_status == LINK_DOWN);
			try_count = 0;
		}
	}
}

int board_thread (void)
{
	printf("board thread starts\n");	
	float voltage;
	char volt[20];
	bzero(volt,sizeof(volt));
	while(1)
	{
		
		system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
		system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
		system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
		system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
		read_car_voltage(&voltage);  
		sprintf(volt,"%f",voltage);
//		printf("volt is %s\n",volt);
		set_xml_content (SRC_XML_FILE, "home", "ext_bat",volt);	
		if(voltage < 3.0){
			board_init_4g_uart();
		}
		else{
			board_init_4g_usb();	
		}

		sem_wait(&libClient.sem_board_init);
		mod_init = 0;//before 3g mod ON dont run pppd
		IOBD_DEBUG_LEVEL3 ("Board_semaphore Released");
	}
	return 0;


}

void GPIO_config(void)
{

	/* GPIO to turn on/off 3G module */
	system("echo 47 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio47/direction");

	/* GPIO to turn on/off Status LED */
	system("echo 77 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio77/direction");

	/* GPIO to turn on/off USB Power switch */
	system("echo 78 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio78/direction");

	/* GPIO for RESET_N of 3G module */
	system("echo 79 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio79/direction");

	/* GPIO to turn on/off 12V regulator */
	system("echo 92 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio92/direction");

	/* GPIO to turn on/off 4V4 regulator */
	system("echo 90 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio90/direction");

	/* GPIO to turn on/off 3V3 regulator */
	system("echo 91 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio91/direction");

	/* GPIO to turn on/off Buzzer */
	system("echo 36 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio36/direction");

	/* GPIO to turn on/off Relay */
	system("echo 38 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio38/direction");

	
	/* GPIO to turn on/off Interpretter CAN */
	system("echo 32 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio32/direction");

	/* GPIO to turn on/off CPU CAN */
	system("echo 67 > /sys/class/gpio/export");
	system("echo out > /sys/class/gpio/gpio67/direction");

	/* enable auto enumeration for usb device */
//	system("echo on > /sys/devices/platform/soc/2100000.aips-bus/2184200.usb/ci_hdrc.1/usb2/power/control");
}

int read_event (int sockint)
{
	int status = 0;
	int ret = 1;
	char buf[4096] = {0};
	struct iovec iov = {buf, sizeof buf };
	struct sockaddr_nl snl;
	struct msghdr msg = { (void *) &snl, sizeof snl, &iov, 1, NULL, 0, 0 };
	struct nlmsghdr *h;
	int fread_val = 0;
	FILE *fp;
	char buf_status[200];
	char ifname[1024] = {0};
	struct ifinfomsg *ifi;

	status = recvmsg (sockint, &msg, 0);

	if (status <= 0) {
		printf("Error has occurred\r\n");
	}
	else {
		for (h = (struct nlmsghdr *) buf; NLMSG_OK (h, (unsigned int) status);h = NLMSG_NEXT (h, status)) {
			if (h->nlmsg_type == NLMSG_DONE) {
				return 0;
			}
			else if (h->nlmsg_type == RTM_NEWLINK) {
				ifi = NLMSG_DATA(h);
				if_indextoname (ifi->ifi_index,ifname);
				printf ("iwave: netlink_link_state: Link %s %s\n",ifname,(ifi->ifi_flags & IFF_RUNNING)?"Up":"Down");

				if(((ifi->ifi_flags & IFF_RUNNING) == 0) && (strcmp(ifname, "ppp0") == 0)){

					fp = fopen("/home/root/link_status.txt","r+");
					strcpy(buf_status, "link is down");
					fwrite(&buf_status, strlen(buf_status), 1, fp);
					fclose(fp);
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","0");
					/* if link status was up before, then kill pppd */
					if (libClient.ppp0_link_status == LINK_UP){
						IOBD_DEBUG_LEVEL3 ("killall pppd");
						system("killall pppd");
					}
					/* Update the link status */
					libClient.ppp0_link_status = LINK_DOWN;

					IOBD_DEBUG_LEVEL2 ("releasing Semaphore for  link status thread\n");
					sem_post(&libClient.sem_ppp0_link_down);
				}
				if(((ifi->ifi_flags & IFF_RUNNING) != 0) && (strcmp(ifname, "ppp0") == 0)){
					fp = fopen("/home/root/link_status.txt","r+");
					strcpy(buf_status, "link is up");
					fwrite(&buf_status, strlen(buf_status), 1, fp);
					fclose(fp);
					libClient.ppp0_link_status = LINK_UP;
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","1");
				}
			}
		}
	}
	return 0;
}

int update_gpio_info (IO_PIN_STATE *io_pin)
{
	int ret = 0;
//	printf("io_pin->din1 = %hd\tio_pin->din2 = %hd\tio_pin->dout1 = %hd\tio_pin->dout2 = %hd\t",io_pin->din1, io_pin->din2, io_pin->dout1,io_pin->dout2);
	if (gpio_pin.dout1 == 1){
                ret = set_gpio_value(36,1);/*Relay high in dout1*/
        }
	if (gpio_pin.dout2 == 1){
                ret = set_gpio_value(38,1);/*Relay high in dout2*/
        }

	gpio_pin.din1  = io_pin->din1;	
	gpio_pin.din2  = io_pin->din2;	
	gpio_pin.dout1 = io_pin->dout1;	
	gpio_pin.dout2 = io_pin->dout2;	
	gpio_pin.ain1  = io_pin->ain1;	
	printf("update_gpio_info ret %d\n",ret);
	return ret;
}

int get_gpio_event(char *path, char *event) {

	int event_no = 0;	
	FILE *fp;
	char command[100];
	char *intf_conf;
	char *file_name = "/name";
	char event_file[72];
	int i;
	
	for (i = 0; i < 5; i++){
		sprintf (event_file, "%s%d%s",path,i,file_name);	
		fp = fopen(event_file, "r");
		if (fp == NULL){
			perror (event_file);
			continue;
		}
		fread(&command, 30, 1, fp);
		intf_conf = strstr(command,event);
		if (intf_conf){
			event_no = i;
			fclose (fp);
			break;
		}
	}
	
	return event_no;
}	

int key_event_thread()
{
	int fd, fp, rc = 0;
	char ts[100];
	struct input_event ev[64];
	int i, rd;
	unsigned int type, code;
	struct timeval timeout;
	int retval;
	fd_set rdfs;
	struct ign_stat ign_qdata;
	int ret = 0;
	int event_no;
	char file[50] = {0};
	int panic_button = 0;

	event_no = get_gpio_event(GPIO_EVENT_PATH, GPIO_EVENT_NAME);
	printf("the event number of gpio-key is %d\r\n", event_no);

	sprintf(file, "/dev/input/event%d", event_no);

	printf("Event file : %s\r\n", file);

	if ((fd = open (file, O_RDWR)) < 0) {
		printf("Error Occured while opening Device File.!!\n");
		return -1;
	}
	else {
		printf("Device Opened Successfully !! /dev/input/event%d\n", event_no);
	}


	FD_ZERO(&rdfs);
	FD_SET(fd, &rdfs);

	/* timeout wait for 500ms */
	timeout.tv_sec = 0;
	timeout.tv_usec = 10000;

	while(1) {
		retval = select(fd + 2, &rdfs, NULL, NULL, &timeout);

		if(retval) {
			rd = read(fd, ev, sizeof(ev));
			if (rd < (int) sizeof(struct input_event)) {
				printf("expected %d bytes, got %d\n", (int) sizeof(struct input_event), rd);
				return 1;
			}

			for (i = 0; i < rd / sizeof(struct input_event); i++) {

				type = ev[i].type;
				code = ev[i].code;
			//	printf("i : %d, code : %d, value : %d \r\n", i, ev[i].code, ev[i].value);
				if(ev[i].code == 29 && ev[i].value == 0) {
					/* put the system to sleep */
					IOBD_DEBUG_LEVEL3 ("Key_event_thread sem_post");
					sem_post(&libClient.ign_off_restart);
					system("echo mem > /sys/power/state");
					printf("##############SYSTEM_HAS_AWAKE##############");
				}
				else if (ev[i].code == 29 && ev[i].value == 1) {
					printf("system has wakeup %d %d\r\n",libClient.system_wake_timer,libClient.system_wake_acc);
					config_sleep_wake_trigger_off();
					if (libClient.system_wake_timer == 1 || libClient.system_wake_acc == 1)
						break;
					config_wakeup_timer_trigger(TIMER_DISABLE, NO_SLEEP_TIME);
					system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
					system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
					system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
					system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled

					/*!< 12 V Switch */
					system("echo 1 > /sys/class/gpio/gpio92/value");
					/*!< 3V3 Switch */
					system("echo 1 > /sys/class/gpio/gpio91/value");
					/*!< 4V4 Switch */
					system("echo 1 > /sys/class/gpio/gpio90/value");
					/*!< Interpreter CAN ON */
					system("echo 0 > /sys/class/gpio/gpio32/value");
					/*!< CPU CAN OFF */
					system("echo 1 > /sys/class/gpio/gpio67/value");
					
					tcflush(libClient.serial_intf.tty_fd, TCIOFLUSH);
					memset(ign_qdata.data,0,sizeof(ign_qdata.data));
					get_time(ts);
					strcpy(ign_qdata.data,ts);
					printf("Wake up timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
					ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
					if(ret == IGNITION_STATE_BATTERY_DRAIN){
						ign_qdata.msg_type = PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP;
					}
					else if (ret == IGNITION_STATE_DEVICE_REMOVED){
						ign_qdata.msg_type = PM_EVENT_SLEEP_DISCONNECTION;
					}
					else if (ret == IGNITION_STATE_OFF){
						config_sleep_wake_trigger_on();
						break;
					}
					else{
						ign_qdata.msg_type = PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE;	
					}
					printf("send saved time stamp %s \n",ts);
					rc = send_ign_q(&libClient,&ign_qdata);
				}
				else if (ev[i].code == 30 ){//DIN2 PANIC_BUTTON- 3 IGN_PIN - 4 as per GUI
					printf("inside 30 - DIN2\n");
					get_time(ts);
					if (gpio_pin.din2 == 3 && ev[i].value == 0){
						if (libClient.init_connect == 1 ){
							if(libClient.ign_fptr.pnc_btn != NULL){
								libClient.ign_fptr.pnc_btn(ts);
							}
							else
								printf("invalid panic_button function address\n");	
						}
					}
					else if (gpio_pin.din2 == 4 && ev[i].value == 0){
						printf ("IGNITION ON IN DIN2\n");
						set_xml_content (SRC_XML_FILE, "io_status", "ignition_pin","1");
					}
					else if (gpio_pin.din2 == 4 && ev[i].value == 1){
						printf ("IGNITION OFF IN DIN2\n");
                                                set_xml_content (SRC_XML_FILE, "io_status", "ignition_pin","0");
					}
				}
				else if (ev[i].code == 48){//DIN1
					printf("inside 48 - DIN1\n");
					get_time(ts);
					if (gpio_pin.din1 == 3 && ev[i].value == 0){
						if (libClient.init_connect == 1 ){
							if(libClient.ign_fptr.pnc_btn != NULL){
								libClient.ign_fptr.pnc_btn(ts);
							}
							else
								printf("invalid panic_button function address\n");	
						}
					}
					else if (gpio_pin.din1 == 4 && ev[i].value == 0){
						printf ("IGNITION ON IN DIN1\n");
						set_xml_content (SRC_XML_FILE, "io_status", "ignition_pin","1");
					}
					else if (gpio_pin.din1 == 4 && ev[i].value == 1){
						printf ("IGNITION OFF IN DIN1\n");
						set_xml_content (SRC_XML_FILE, "io_status", "ignition_pin","0");
					}
				}
			}
		}
		FD_SET(fd, &rdfs);
		/* timeout wait for 35ms */
		timeout.tv_sec = 0;
		timeout.tv_usec = 10000;
	}
	close(fd);   // Close the device
}

#ifdef __TIMER__
int timer_event_thread()
{
	int rtc_fd,ret;
	int i, rd;
	struct timeval timeout;
	struct ign_stat ign_qdata;
	int retval;
	unsigned long data;
	fd_set rdfs;

	rtc_fd = open (TIMER_CFG_FILE, O_RDWR);
	ret = CHK_ERR (rtc_fd, stderr, "timer_event_thread:open");
	if (ret == OBD2_LIB_FAILURE) {
		IOBD_DEBUG_LEVEL1 ("Error Occured while opening RTC File.!!\n");
		return OBD2_LIB_FAILURE;
	}
	else {
		IOBD_DEBUG_LEVEL2("Device File Opened Successfully !! /dev/rtc0\n");
	}

	FD_ZERO(&rdfs);
	FD_SET(rtc_fd, &rdfs);

	/* timeout wait for 100ms */
	timeout.tv_sec = 0;
	timeout.tv_usec = 100000;

	while(1){
		IOBD_DEBUG_LEVEL3 ("timer_thread : select +");
retry:		retval = select(rtc_fd + 2, &rdfs, NULL, NULL, NULL);
//retry:		retval = select(rtc_fd + 2, &rdfs, NULL, NULL, &timeout);
		IOBD_DEBUG_LEVEL3 ("timer_thread : select -");

		if(retval) {
			retval = read(rtc_fd, &data, sizeof(unsigned long));
			ret = CHK_ERR (retval, stderr, "timer_event_thread:read");
			config_wakeup_timer_trigger(TIMER_DISABLE, 0);
			if (ret == OBD2_LIB_FAILURE){
				IOBD_DEBUG_LEVEL1 ("Error Occured while Reading RTC File...!!!!\n");
				goto retry;
			}
			system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
			system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
			system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
			system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
			/*!< 12V Switch */
			system("echo 1 > /sys/class/gpio/gpio92/value");
			/*!< 3V3 Switch */
			system("echo 1 > /sys/class/gpio/gpio91/value");
			/*!< 4V4 Switch */
			system("echo 1 > /sys/class/gpio/gpio90/value");

			IOBD_DEBUG_LEVEL2 ("system wakeup with timer : retval : %d , data : %lu\r\n", retval, data);
			libClient.system_wake_timer = 1;
			config_sleep_wake_trigger_off();
			ign_qdata.msg_type = PM_EVENT_SLEEP_DISCONNECTION;
			ret = send_ign_q(&libClient,&ign_qdata);
		}
		FD_SET(rtc_fd, &rdfs);
		/* timeout wait for 100ms*/
		timeout.tv_sec = 0;
		timeout.tv_usec = 100000;
	}
	printf("%s : close value is :%d\r\n", __func__, rtc_fd);
	close(rtc_fd);   // Close the device
}
#endif

int board_init_4g_uart()
{
	char buf[255];
	int ret;
	FILE *fp;
	struct hostent *hostinfo;
	char *hostname = "google.com";
	static int intf_count = 0;
	double in_bat_volt = 0.0;
	char volt[20]={0};
#if 0
	memset(buf, 0, 255);
	strcpy(buf, "/dev/ttymxc5");
	fp = fopen("/etc/ppp/peers/gprs_4g", "r+");
	fwrite(&buf, strlen(buf), 1, fp);
	fclose(fp);
#endif
	check_in_bt_volt (&in_bat_volt);	
        set_xml_content (SRC_XML_FILE, "home", "imei","000000000000000");
	sprintf(volt,"%lf",&in_bat_volt);
	set_xml_content (SRC_XML_FILE, "home", "int_bat",volt);			
	module_3g_on ();
	while(1)
	{
		if(access("/dev/ttyUSB4",F_OK)){
			continue;
		}
		else{
			IOBD_DEBUG_LEVEL1 ("\nModule Initialization Completed\n");
			//system("pppd call gprs_4g");
			break;
		}
	}
	ret = check_registration ();
	while(ret == -2);//if sim not inserted block

	while(1){
		intf_count++;
		system("/iwtest/Application/gprs.sh");
		sleep(1);
		IOBD_DEBUG_LEVEL1("inside board_uart count is   %d\r\n",intf_count);
		hostinfo = gethostbyname (hostname);

		if (hostinfo == NULL){
			IOBD_DEBUG_LEVEL1("-> no connection!_uart\n");
			continue;
		}
		else{
			IOBD_DEBUG_LEVEL1("-> connection established!_uart\n");
			break;
		}
	}
	
	/* NaN : Moved from sampleDev */
	while(1)
	{
		ret = check_connection();
		IOBD_DEBUG_LEVEL1("Uart ---- check_connection link value is %d \n",ret);
		sleep(1);
		if(ret == 1){
			ntp_server();
			break;
		}
	}

	while(1)
	{
		ret = check_connection();
		IOBD_DEBUG_LEVEL1("Uart ---- check_connection link value is %d \n",ret);
		sleep(1);
		if(ret == 1){
			agps_init();
			break;
		}
	}

	sleep(1);

	if(libClient.fresh_boot != 1 ){
		if(libClient.s_w.wake!=NULL){
			IOBD_DEBUG_LEVEL1(" Call application slp_disconnection handler callback \n");
			libClient.s_w.slp_dis();
		}
		else{
			IOBD_DEBUG_LEVEL1("wakeup handler not provided for application \n");
		}
	}
	else
	{
		/* NaN : First boot */
		sem_post(&libClient.sem_board_init_complete);
		libClient.fresh_boot = 0;
	}
	return 0;
}

int board_init_4g_usb()
{

	char buf[255];
	int ret,rc = 0;
	FILE *fp;
	char *intf_conf;
	struct hostent *hostinfo;
	char *hostname = "google.com";
	static int ping_count = 0;
	static module_reset =0;
	static module_init_count =0;
	static module_reset_count =0;
	double in_bat_volt = 0.0;
	char volt[20]={0};
#if 0
	memset(buf, 0, 255);
	strcpy(buf, "/dev/ttyUSB3");
	fp = fopen("/etc/ppp/peers/gprs_4g", "r+");
	fwrite(&buf, strlen(buf), 1, fp);
	fclose(fp);
#endif
	check_in_bt_volt (&in_bat_volt);	
        set_xml_content (SRC_XML_FILE, "home", "imei","000000000000000");
	sprintf(volt,"%lf",in_bat_volt);
	set_xml_content (SRC_XML_FILE, "home", "int_bat",volt);			
	module_3g_on ();

	while(1)
	{
		//if(access(USB_2,F_OK)){
		if(access("/dev/ttyUSB4",F_OK)){
			continue;
		}
		else{
			IOBD_DEBUG_LEVEL1 ("\nModule Initialization Completed\n");
			break;
		}
	}
//	usleep (500000);
	ret = check_registration ();
	while(ret == -2);//if sim not inserted block
	mod_init = 1;
	while(1)
	{
		//system ("pppd call gprs_4g");
		if (module_reset == 1)
		{
			system ("rmmod g_serial.ko");
			system ("rmmod usb_f_acm.ko");
			system ("rmmod usb_f_serial.ko");
			system ("rmmod u_serial.ko");
			system ("rmmod ci_hdrc_imx.ko");
			system ("rmmod usbmisc_imx.ko");
			system ("rmmod ci_hdrc.ko");
			system ("rmmod libcomposite.ko");
			system ("rmmod udc-core.ko");

			//	system("echo 0 > /sys/class/gpio/gpio47/value");
			//	usleep(100000);
			system("echo 1 > /sys/class/gpio/gpio47/value");
			usleep(600000);
			system("echo 0 > /sys/class/gpio/gpio47/value");
			usleep(300000);

			while(1)
			{
					module_reset_count++;
					sleep(1);
					IOBD_DEBUG_LEVEL1("\nModule Reset Loading.... %d\n",module_reset_count);
					if ((module_reset_count > 30) || (access(USB_2,F_OK)) != 0)
					break;
					else
					continue;
			}
			system("echo 0 > /sys/class/gpio/gpio78/value");
			usleep(100000);
		
			module_3g_on ();
			while(1)
			{
				if(access(USB_3,F_OK) != 0){
					module_init_count++;
					if(module_init_count == 50){
						IOBD_DEBUG_LEVEL1("Module Initialization Loading....");
						module_init_count =0;
					}
					usleep (300000);
					continue;
				}
				else{
					IOBD_DEBUG_LEVEL1("Module Initialization Completed");
					break;
				}
			}
			ret = check_registration ();
			while(ret == -2);//if sim not inserted block
			ping_count = 0;
			module_reset = 0;
			module_reset_count = 0;
		}
		system("/iwtest/Application/gprs.sh");

			hostinfo = gethostbyname (hostname);
			if (hostinfo == NULL)
			{
				system ("pppd call gprs_4g");
				IOBD_DEBUG_LEVEL1("-> no connection! ping_count %d\n",ping_count);
				ping_count++;
				if (ping_count == 40){
					module_reset = 1;
				}
				continue;
			}
			else 
			{
				IOBD_DEBUG_LEVEL1("-> connection established! ping_count %d\n",ping_count);
				ping_count = 0;
				break;
			}
	}

	/* NaN : Moved from sampleDev */
	while(1)
	{
		rc = check_connection();
		IOBD_DEBUG_LEVEL1("check_connection link value is %d \n",rc);
		sleep(1);
		if(rc == 1){
			/* NanC : */
			ntp_server();
			break;
		}
	}

	while(1)
	{
		rc = check_connection();
		IOBD_DEBUG_LEVEL1("check_connection link value is %d \n",rc);
		sleep(1);
		if(rc == 1){
			agps_init();
			break;
		}
	}

	sleep(1);
	if(libClient.fresh_boot != 1 ){
		if(libClient.s_w.wake!=NULL){
			IOBD_DEBUG_LEVEL1 (" Call application wake up  handler callback \n");
			libClient.s_w.wake();
		}
		else{
			IOBD_DEBUG_LEVEL1 ("wakeup handler not provided for application \n");
		}
	}
	else
	{
		sem_post(&libClient.sem_board_init_complete);
		libClient.fresh_boot = 0;
	}
	return 0;
}

void pm_enable(void)
{
	libClient.powermgmt = 1;
}

void pm_disable(void)
{
	libClient.powermgmt = 0;
}

int raw_can_enable(void)
{
	int ret = 0;

	if(libClient.set_raw_can == 1)
		ret = 1;
	else
		ret = 0;

	return ret;		
}

int get_ign_stat_voltage_no_dip()
{
	float volt_val;
	int ret;

	read_car_voltage(&volt_val);

	if(volt_val > 24.0)
		read_car_voltage(&volt_val);

	if(volt_val < 13.2){
		if(volt_val < 10.0){
			if(volt_val < 4.0)
				ret = IGNITION_STATE_DEVICE_REMOVED;
			else
				ret = IGNITION_STATE_BATTERY_DRAIN;
		}
		else
			ret = IGNITION_STATE_OFF;
	}
	else
		ret = IGNITION_STATE_ON;


	printf("volt_val : %f, ret : %d \r\n", volt_val, ret);

	return ret;

}

float get_ext_power_voltage()
{
	float volt_val = 0;
	printf("get_ext_power_voltage +\n");
	read_car_voltage(&volt_val);
	printf("get_ext_power_voltage volt_val %f -\n",volt_val);

	return volt_val;

}

int indicate_ignition_off_completed()
{
	struct ign_stat ign_qdata;
	int rc = 0;
	printf("indicate_ignition_off_completed sem_ign_off + \n");
	sem_post(&libClient.ign_of_sem);
	printf("indicate_ignition_off_completed sem_ign_off - \n");
	return rc;
}

//int indicate_device_exit(pthread_t id)
int indicate_device_exit()
{
	int rc = 0;
	printf("Waiting for thread to join \n");
//	pthread_join(id, NULL);
	pthread_join((libClient.tid[0]), NULL);
	printf("Thread joined \n");
exit:	
	return rc;
}

void check_ignition_off(char *thread)
{
	int ret = 0;
	ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
	/* ToDo : whether all return state must be handeled? or only IGNITION_STATE_OFF is fine? */
	if(ret != IGNITION_STATE_ON)
	{
		printf("%s  enter in to pause()\n",thread);
		sem_wait(&libClient.ign_off_sem);
		printf("Got the signal!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
		sem_post(&libClient.ign_off_sem);

	}
	else 
		return;
}

void server_connection_complete(void)
{

	if(libClient.check_raw_can == 1) {
		libClient.set_raw_can = 1;		
		can_init(500000);
	}
	libClient.init_connect = 1;
}
#ifdef __TIMER__
int config_wakeup_timer_trigger(bool enable, long secs)
{
        char enable_alarm[100];

        if(enable) {
                printf("%s : %lu\r\n",__func__,secs);
                sprintf(enable_alarm, TIMER_WAKEUP_ALARM_ENABLE, secs);
                system(enable_alarm);
		IOBD_DEBUG_LEVEL2 ("Timer wakeup alarm enabled");	
        }
        else {
                system(TIMER_WAKEUP_ALARM_DISABLE);
		IOBD_DEBUG_LEVEL2 ("Timer wakeup alarm disabled");	
        }

        return 0;
}
#endif
