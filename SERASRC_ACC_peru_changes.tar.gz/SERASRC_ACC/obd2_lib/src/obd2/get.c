#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "init.h"
#include "common.h"
#include <unistd.h>
#include <string.h>
#include "serial.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"
//#include "libxml2.h"

void get_time (char *timebuf)
{
	struct timeval tv;
	struct tm* ptm;
	char time_string[40];
	long milliseconds;

	/* Obtain the time of day, and convert it to a tm struct.  */
	gettimeofday (&tv, NULL);
	ptm = localtime (&tv.tv_sec);

	/* Format the date and time, down to a single second.  */
	strftime (time_string, sizeof (time_string), "%Y-%m-%dT%H:%M:%S", ptm);

	/* Compute milliseconds from microseconds.  */
	milliseconds = tv.tv_usec / 1000;

	/* Print the formatted time, in seconds, followed by a decimal point
	   and the milliseconds.  */
	sprintf (timebuf,"%s.%03ldZ", time_string, milliseconds);
	//printf("&timebuf %x timebuf %s \n",timebuf,timebuf);
}

int get_serial_no()
{
	char buf_lo[10], buf_hi[10];
	char dummy_buf[2];
	FILE *fp0, *fp1;

	memset(buf_lo, 0, 10);
	memset(buf_hi, 0, 10);

	/* read unique id lsb */
	fp0 = fopen(CPU_UNIQUE_ID_LO, "r");
	fread(&dummy_buf, 2, 1, fp0);
	fread(&buf_lo, 8, 1, fp0);
	fclose(fp0);

	/* read unique id lsb */
	fp1 = fopen(CPU_UNIQUE_ID_HI, "r");
	fread(&buf_hi, 10, 1, fp1);
	fclose(fp1);

	/* NaNR : Some Junk characters were observed in printf */

	printf ("CPU Unique ID MSB\t:\t %s \r\n", buf_hi);
	printf ("CPU Unique ID LSB\t:\t 0x%s \r\n", buf_lo);

	return 0;
}

int check_protocol()
{
	int rc = 0,count = 5;
	printf ("checking protocol..............\n");
	while (count--){
		rc = check_ign_status(IGNITION_STAT_WITH_DIP);
		if (rc == IGNITION_STATE_ON){
			libClient.check_raw_can = 0;
			break;
		}
		else{
			libClient.check_raw_can = 1;
			continue;
		}
	}
        printf("libClient.check_raw_can : %d\r\n", libClient.check_raw_can);
	return libClient.check_raw_can;
}

int check_mode()
{
	struct timeval start, end;
	gettimeofday(&start, NULL);
	char command[20];
	char value[2];
	int rc = -1; 
	FILE *fp = fopen("/home/root/mode.txt","r+");
	if(fp == NULL){
		printf(" no mode.txt is found and error created\r\n");
	}
	memset(command, 0, 20);
	fread(&command, 11, 1, fp);
	fclose(fp);
	printf("MODE is %s......................\r\n", command);

	if((strncmp(command, "MODE-1", 6) != 0) && (strncmp(command, "MODE-2", 6) != 0))
	{
		while(1) 
		{
			get_xml_content (SRC_XML_FILE, "general", "mode", value);
			libClient.lab_mode = atoi (value);
			printf("in Check_Mode is %d\n",libClient.lab_mode);
			rc = check_ign_status(IGNITION_STAT_WITH_DIP);
			if((rc == IGNITION_STATE_ON || rc == IGNITION_STATE_ON_VOLTAGE) && libClient.car_mode == 0)
			{
				printf("Ignition is ON***************\r\n");
				memset(command, 0, 20);
				fp = fopen("/home/root/mode.txt","r+");
				strcpy(command, "MODE-1");  // CAR mode
				fwrite(&command, strlen(command), 1, fp);
				fclose(fp);
				libClient.car_mode = 1;
			//	set_xml_content (SRC_XML_FILE, "io_status", "ignition_pin","1");
				break;
			}
			else if(rc == IGNITION_STATE_OFF ) 
			{

				printf("Ignition is OFF***************\r\n");
				gettimeofday(&end, NULL);

				memset(command, 0, 20);

				libClient.run_time.duration = ((end.tv_usec - start.tv_usec) + (end.tv_sec - start.tv_sec)*1000000)/1000000;

				if(libClient.run_time.duration >= 600) 
				{	 /* write as car mode */
					fp = fopen("/home/root/mode.txt","r+");
					strcpy(command, "MODE-1");  //CAR mode
					fwrite(&command, strlen(command), 1, fp);
					fclose(fp);
					libClient.car_mode = 1;
					sleep(1);
				}
				else if(libClient.lab_mode == 2){
					libClient.car_mode = 0;
                                        break;
				}

				memset(command, 0, 20);
			#if 0	
				fp = fopen("/home/root/mode.txt","r+");
				fread(&command, 7, 1, fp);
				fclose(fp);

				printf("command is ------> %s\r\n", command);
				if(strncmp(command,"MODE-1",6) == 0){
					libClient.car_mode = 1;
					break;
				}
				else if(strncmp(command,"MODE-2",6) == 0){
					libClient.car_mode = 0;
					break;
				}
			#endif
			}
			else if (rc == IGNITION_STATE_DEVICE_REMOVED){
				libClient.car_mode = 1;
				break;
			}
		}
	}
	else {
		/* NaND : This if and else if condition never meets!? */

		if(strncmp(command,"MODE-1",6) == 0)
			libClient.car_mode = 1;

		else if(strncmp(command,"MODE-2",6) == 0)
			libClient.car_mode = 0;
	}

	if(libClient.car_mode == 1)			 
		printf("***********************************THE MODE IS CAR MODE********************\r\n");
	else if(libClient.car_mode == 0)
		printf("******************************THE MODE IS LAB MODE******************\r\n");

	memset(command, 0, 20);
	return libClient.car_mode;
}


int get_ign_stat_voltage_check_dip()
{
	int ret = IGNITION_STATE_ON;
	float volt;
	int duration_ign_off;
	struct timeval start_ign_off, end_ign_off;

	read_car_voltage(&volt);

	printf("voltage : %f \r\n", volt);

	gettimeofday(&start_ign_off, NULL);

	if(volt < 13.1) {
		while(1) {
			gettimeofday(&end_ign_off, NULL);
			duration_ign_off = ((end_ign_off.tv_usec-start_ign_off.tv_usec)+(end_ign_off.tv_sec-start_ign_off.tv_sec)*1000000)/1000000;

			printf("duration_ign_off : %d \r\n", duration_ign_off);

			read_car_voltage(&volt);
			if(volt < 3.5){
				ret = IGNITION_STATE_DEVICE_REMOVED;
				break;
			}

			if(volt < 13.1 && duration_ign_off >= 8) {
				printf("voltage is less than 13.2 ignition off \r\n");
				if(volt < 10.5){
					ret = IGNITION_STATE_BATTERY_DRAIN;
				}
				else{
					ret = IGNITION_STATE_OFF;
				}

				break;
			}
			else if(volt > 13.1) {
				printf("voltage is greater than 13.2 between \r\n");
				ret = IGNITION_STATE_ON;
				break;
			}
		}
	}
	else {
		printf("volatge is greater than 13.2 \r\n");
				ret = IGNITION_STATE_ON_VOLTAGE;
	}

	printf("get_ign_stat_voltage_check_dip returns %d \r\n",ret);
	return ret;
}


int check_ign_status(int voltage_dip)
{
	int ret;
	char *cmd_buf = "010C";
	char buf[255] = {0};
	struct obd_ obd_data;

	/* send command and receive the data response */
	ret = obd_read_data(cmd_buf,buf,&obd_data);

	if(strncmp(obd_data.res_buf, "41", 2) == 0){
		if(strncmp(obd_data.res_buf, "41 0C 00 00", 11) == 0) {
			printf("iwave: engine is off\r\n");
			if(voltage_dip){
				ret = get_ign_stat_voltage_check_dip();
			}
			else{
				ret = get_ign_stat_voltage_no_dip();	
			}
		}
		else {
			ret = IGNITION_STATE_ON;
		}
	}
	else if(ret != IGNITION_STATE_ON){
		printf("iwave: engine may be off\r\n");
		if(voltage_dip){
			ret = get_ign_stat_voltage_check_dip();
		}
		else{
			ret = get_ign_stat_voltage_no_dip();	
		}
	}


	printf(" check_ign_status returns %d \r\n",ret);
	return ret;
}

int check_adc_voltage (double *volt)
{
	FILE *fp;
	char buf[10];
	int raw_value;
	double voltage_value;
	int rc = 0;

	bzero (buf,sizeof(buf));
	
	fp = fopen(ADC_READ_NODE, "r");
	if(fp == NULL){
		printf("ADC_READ_NODE: Error opening file\r\n");
		rc = -1;
		goto end;
	}

	fread(&buf, 10, 1, fp);
	fclose(fp);

//	printf ("adc_volt_buf : %s\n",buf);

	raw_value = (int)strtol(buf, NULL, 10);
	voltage_value = raw_value;
	printf("voltage_value %lf\n",voltage_value);

	*volt = ((((voltage_value / 4096.00) * 3.3 * 7.848) - 2.1621));

	printf("raw_value : %d\t voltage_value: %lf\r\n", raw_value, *volt);
end:
	return rc;
}


int check_in_bt_volt (double *volt)
{
	FILE *fp;
	char buf[10];
	int raw_value;
	double voltage_value;
	int rc = 0;

	bzero (buf,sizeof(buf));
	
	fp = fopen(IN_BT_READ_NODE, "r");
	if(fp == NULL){
		printf("IN_BT_READ_NODE: Error opening file\r\n");
		rc = -1;
		goto end;
	}

	fread(&buf, 10, 1, fp);
	fclose(fp);

	printf ("In_battery_volt_buf : %s\n",buf);

	raw_value = (int)strtol(buf, NULL, 10);
	voltage_value = raw_value;
	printf("IN_BT_voltage_value %lf\n",voltage_value);

	*volt = ((voltage_value / 4096.00) * 3.3 * 1.5);

	printf("IN_BTRY raw_value : %d\t voltage_value: %lf\r\n", raw_value, *volt);
end:
	return rc;
}
