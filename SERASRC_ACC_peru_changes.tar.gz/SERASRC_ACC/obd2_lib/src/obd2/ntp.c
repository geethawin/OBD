#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "init.h"

void ntp_server()
{

	FILE *ntp_fp;
	char command[200];
	char time[100];
	char buf_status[200];

	ntp_fp = fopen("/home/root/ntp_update.txt","r+");
	if(ntp_fp == NULL){
		printf("error created\r\n");
	}
	fread(&command, 21, 1, ntp_fp);
	fclose(ntp_fp);

	printf("------------------->command: %s\r\n", command);


	if(strncmp(command, "ntp is up", 9) != 0) {

		/* ntp server update */
		ntp_server_update();

		get_time(time);
		ntp_fp = fopen("/home/root/ntp_update.txt","r+");
		strcpy(buf_status, "ntp is up");
		strncat(buf_status, time, 10);
		printf("------------------->buf_status: %s\r\n", buf_status);
		fwrite(&buf_status, strlen(buf_status), 1, ntp_fp);
		fclose(ntp_fp);
	}
	else 
	{
		get_time(time);
		ntp_fp = fopen("/home/root/ntp_update.txt","r+");
		fread(&buf_status, 21, 1, ntp_fp);
		if(strncmp(time, &buf_status[9], 10) != 0) 
		{
			/* ntp server update */
			ntp_server_update();

			get_time(time);
			ntp_fp = fopen("/home/root/ntp_update.txt","r+");
			strcpy(buf_status, "ntp is up");
			strncat(buf_status, time, 10);
			fwrite(&buf_status, strlen(buf_status), 1, ntp_fp);
			fclose(ntp_fp);
		}
	}

}

int ntp_server_update()
{
	char command[255];
	char s[100]={0}, fname[20];
	FILE *file;
	FILE *fd;
	char ch;
	int  count = 0;
	size_t nread;
	char buffer[512] = {0};
	char data[512] = {0};
	int ret;
	int i=0;
	int found = 0;
	char c;
	int j=0,k=0;
	char timezone[50]={0};
	static zone_valid =0;
	int rc,l=0;

	strcpy(command, "date -s 2018.07.30-00:00:00");
	system("unlink /etc/localtime");
	ret = system(command);
	while(l<=10){
		rc = check_connection();
		if(rc == 1)
			break;
		l++;
		sleep(1);
	}

	//system("wget https://worldtime.io/ --output-document=/home/root/index.html");

	if(!access("/home/root/index.html", F_OK )){
		printf("index.html File is downloaded \n");

		file = fopen("/home/root/index.html", "r");

		while((c = getc(file)) != EOF)
		{
			if(c == '\n'){
				char *ptr = strstr(buffer,"Timezone Reference");
				if(ptr!=NULL){
					break;
				}
				i = 0;
				memset(buffer,0,sizeof(buffer));
			}
			else{
				buffer[i]=c;
				i++;
			}
		}
		i = 0;
		memset(buffer,0,sizeof(buffer));

		while((c = getc(file)) != EOF)
		{
			if(c == '\n'){
				if(found==1)
				{
					char *ptr2 = strstr(buffer,"</div>");
					strcat(data,buffer);
					if(ptr2!=NULL)
						break;
				}

				char *ptr = strstr(buffer,"<div");
				if(ptr!=NULL){
					found = 1;
					strcpy(data,buffer);
				}
				i = 0;
				memset(buffer,0,sizeof(buffer));
			}
			else
			{
				buffer[i]=c;
				i++;
			}
		}

		char *start = strstr(data,">");
		start++;
		while(start[j]!='<'){
			if(start[j]==' ')
			{
				j++;
				continue;
			}
			timezone[k++] = start[j];
			j++;
		}
		zone_valid = 1;
		printf("timezone is %s \n",timezone);
	}else{
		printf("index.html File is not downloaded\n");
		system("wget http://ip-api.com/line/ --output-document=/home/root/timezone.txt");
		strcpy(command,"sed '10!d' /home/root/timezone.txt > /home/root/time.txt");
		system(command);
		memset(command,0,200);
		memset(timezone,0,200);

		if(!access("/home/root/time.txt", F_OK )){
			printf("time.txt is downloaded\n");
			fd=fopen("/home/root/time.txt","r");
			fseek(fd, 0, SEEK_END);
			nread = ftell(fd);
			fseek(fd, 0, SEEK_SET);
			fread(&timezone, nread, 1, fd);
			timezone[nread-1] ='\0';
			sprintf(command,"ls /usr/share/zoneinfo/%s",timezone);
			system("rm /home/root/timezone.txt");
			system("rm /home/root/time.txt");
			fclose(fd);
			zone_valid = 1;
		}
	}
	if(zone_valid == 1) {
		printf("set timezone %s--\n",timezone);
		sprintf(command,"ls /usr/share/zoneinfo/%s",timezone);
		ret = system(command);
		if(ret == 0) {
			memset(command,0,200);
			printf("set zone\r\n");
			sprintf(command,"ln -s /usr/share/zoneinfo/%s /etc/localtime",timezone);
			printf("%s\r\n", command);
			system(command);
		}else{
			printf("NOT Valid\r\n");
			system("ln -s /usr/share/zoneinfo/GMT /etc/localtime");
		}
	}
	else{
		printf("Time Zone not updated\r\n");
		system("ln -s /usr/share/zoneinfo/GMT /etc/localtime");
	}

	system("rm /home/root/index.html");

	while(l<=10){
		rc = check_connection();
		if(rc == 1)
			break;	
		l++;
		sleep(1);
	}
	printf("ntpdate start\n\r");
	memset(command, 0, 200);
	strcpy(command, "ntpdate pool.ntp.org");
	ret = system(command);
	l = 0;
	printf("ntpdate ret = %d\n",ret);
	while (ret != OBD2_LIB_SUCCESS){
		++l;
		IOBD_DEBUG_LEVEL3 ("ntpdate failed retry l = %d",l);
		if (l == 1)
			strcpy(command, "ntpdate jp.pool.ntp.org");
		if (l == 2)
			strcpy(command, "ntpdate id.pool.ntp.org");
		if (l == 3)
			strcpy(command, "ntpdate asia.pool.ntp.org");
		ret = system(command);
		if (l == 3)
			break;
	}
		
	printf("ntpdate end\n\r");

	strcpy(command, "hwclock -w");
	ret = system(command);
	sleep(1);

	return 0;
}

