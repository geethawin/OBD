/* headers */
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/dir.h>
#include <linux/types.h>
#include <string.h>
#include <poll.h>
#include <endian.h>
#include <getopt.h>
#include <inttypes.h>
#include <math.h>
#include <semaphore.h>
#include "iio_utils.h"
#include "gyro_ism330dlc.h"
#include "debug.h"
#include <signal.h>

static struct iio_channel_info *channels; 
static int num_channels;
static gyroscope_api_priv gdata;
static int gyro_init_flag = 0;
static int event_no = 0;
int scan_size;
pthread_t gyro_thread_id;
sem_t gyro_lock;
static char event_file[72];
void process_scan_gyro (char *, struct iio_channel_info *, int);
void print2byte_gyro (int, struct iio_channel_info *, int);

static int interrupt;
                
void signal_gyro_h(int signo)
{
        interrupt = 1;
        printf ("interrupt received !!!!\n");
        //pthread_exit(NULL);;
}

int gyro_init()
{
	int ret;

	signal(SIGUSR1, signal_gyro_h);

	event_no = get_gpio_event(GYRO_MAIN_PATH, GYRO_EVENT_NAME);	

	sprintf (event_file, "%s%d%s", GYRO_MAIN_PATH, event_no, GYRO_SUB_PATH_SCAN);
	IOBD_DEBUG_LEVEL2 ("1.event_file : %s",event_file);

	/*!< Gyroscope x-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_X_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("1.gyro_init: ret %d",ret);
		return ret;
	}
	/*!< Gyroscope y-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_Y_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("2.gyro_init: ret %d",ret);
		return ret;
	}
	/*!< Gyroscope z-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_Z_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("3.gyro_init: ret %d",ret);
		return ret;
	}
	bzero (event_file, sizeof (event_file));
	sprintf (event_file, "%s%d",GYRO_MAIN_PATH,event_no);
	IOBD_DEBUG_LEVEL2 ("2.event_file : %s",event_file);
	ret = build_channel_array (event_file, &channels, &num_channels);	
	if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("2.gyro_init: ret %d",ret);
                return ret;
        }
	scan_size = size_from_channelarray (channels, num_channels);

	bzero (event_file, sizeof (event_file));
	sprintf (event_file, "%s%d%s",GYRO_MAIN_PATH, event_no, GYRO_SUB_PATH_BUF);
	IOBD_DEBUG_LEVEL2 ("3.event_file : %s",event_file);
        /* Enable the buffer */
        ret = write_sysfs_int (GYRO_BUFFER_ENABLE, event_file, ENABLE);

	/*!< switch ON Gyroscope and ... */
        system("i2cset -f -y 1 0x6a 0x11 0x60");
#if 0	
	/* Enable data ready interrupt*/
	system("i2cset -f -y 1 0x6a 0x0d 0x03");
#endif
	if (sem_init(&gyro_lock, 0, 1) == -1){
                printf("Sem Create Failed\r\n");
	}
	
//	if (gyro_init_flag == 0){
		if((pthread_create(&(gyro_thread_id), NULL, (void *) gyroscope_read_thread, NULL))!= 0) {
                        IOBD_DEBUG_LEVEL2 ("pthread_create for gyroscope_read_thread failed\n");
                        return OBD2_LIB_FAILURE;
                }
		else{
			IOBD_DEBUG_LEVEL2 ("gyroscope_read_thread created successfully");
			gyro_init_flag = 1;
		}
//	}
	return ret;
}

int gyro_deinit()
{
	int ret;
	IOBD_DEBUG_LEVEL2 ("gyro_deinit +");
	if (gyro_init_flag == 1){
		pthread_kill(gyro_thread_id, SIGUSR1);

		/* Disable data ready interrupt*/
		//        system("i2cset -f -y 1 0x6a 0x0d 0x00");
		//	IOBD_DEBUG_LEVEL2 ("gyro_deinit: data_ready interrupt disabled");

		bzero (event_file, sizeof (event_file));
		sprintf (event_file, "%s%d%s",GYRO_MAIN_PATH, event_no, GYRO_SUB_PATH_BUF);
		IOBD_DEBUG_LEVEL2 ("3.event_file : %s",event_file);
		/* Enable the buffer */
		ret = write_sysfs_int (GYRO_BUFFER_ENABLE, event_file, DISABLE);
		IOBD_DEBUG_LEVEL2 ("gyro_deinit: Gyro_buffer disabled");
		sem_destroy (&gyro_lock);
		gyro_init_flag = 0;
	}
		IOBD_DEBUG_LEVEL2 ("gyro_deinit -");
#if 0

	bzero (event_file, sizeof (event_file));
	sprintf (event_file, "%s%d%s", GYRO_MAIN_PATH, event_no, GYRO_SUB_PATH_SCAN);
	IOBD_DEBUG_LEVEL2 ("event_file : %s",event_file);

	/*!< Gyroscope x-axis interupt disable*/
        ret = write_sysfs_int (GYRO_INTERRUPT_X_AXIS, event_file, DISABLE);
        if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("1.gyro_deinit: ret %d",ret);
                return ret;
        }
        /*!< Gyroscope y-axis interupt disable*/
        ret = write_sysfs_int (GYRO_INTERRUPT_Y_AXIS, event_file, DISABLE);
        if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("2.gyro_deinit: ret %d",ret);
                return ret;
        }
        /*!< Gyroscope z-axis interupt disable*/
        ret = write_sysfs_int (GYRO_INTERRUPT_Z_AXIS, event_file, DISABLE);
        if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("3.gyro_deinit: ret %d",ret);
                return ret;
        }
	IOBD_DEBUG_LEVEL2 ("gyro_deinit: 3axis interrupt disabled");
#endif

#if 0
	/*!< Gyroscope x-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_X_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("1.gyro_init: ret %d",ret);
		return ret;
	}
	/*!< Gyroscope y-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_Y_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("2.gyro_init: ret %d",ret);
		return ret;
	}
	/*!< Gyroscope z-axis interupt enable*/
	ret = write_sysfs_int (GYRO_INTERRUPT_Z_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("3.gyro_init: ret %d",ret);
		return ret;
	}
	bzero (event_file, sizeof (event_file));
	IOBD_DEBUG_LEVEL2 ("gyro_deinit: 3axis interrupt enabled");
#endif


	return 0;
}

void gyroscope_read_thread (void)
{
        int ret;
        char *buffer_access;
        unsigned long buf_len = 128;
        unsigned long timedelay = 1000000;
        int fp, i = 0;
        int toread;
        int retval;
        fd_set rdfs;
        struct timeval timeout;
        ssize_t read_size;
        char *data;

        /* timeout wait for 10ms */
        timeout.tv_sec = 0;
        timeout.tv_usec = 10000;

        data = malloc(scan_size*buf_len);
        if (!data) {
                ret = -ENOMEM;
        }

        ret = asprintf(&buffer_access, "/dev/iio:device%d", event_no);
        if (ret < 0) {
                ret = -ENOMEM;
        }

        toread = buf_len;

        /* Attempt to open non blocking the access dev */
        fp = open(buffer_access, O_RDONLY | O_NONBLOCK);
        if (fp == -1) { /* If it isn't there make the node */
                printf("Failed to open %s\n", buffer_access);
                ret = -errno;
        }
	
	FD_ZERO(&rdfs);
        FD_SET(fp, &rdfs);

        while(1){
		if (interrupt == 1){
			printf("interrupt received\n");	
			break;
		}

                retval = select(fp + 1 , &rdfs, NULL, NULL, &timeout);

                if(retval) {
                        read_size = read(fp, data, toread*scan_size);
                        if (read_size == -EAGAIN) {
                                printf("nothing available\n");
                                continue;
                        }
                        for (i = 0; i < read_size/scan_size; i++){
				sem_wait (&gyro_lock);
                                process_scan_gyro (data + scan_size * i, channels, num_channels);
				sem_post (&gyro_lock);
			}
                }

		usleep (300000); 

                FD_SET(fp, &rdfs);

                /* timeout wait for 100ms */
                timeout.tv_sec = 0;
                timeout.tv_usec = 100000;
        }

        close(fp);

	printf("gyroscope_read_thread Exits \n");
	/* NaND : adata must be of type accelerometer_api_priv. dont use char buffer */
}

/**
 * process_scan() - print out the values in SI units
 * @data:               pointer to the start of the scan
 * @channels:           information about the channels. Note
 *  size_from_channelarray must have been called first to fill the
 *  location offsets.
 * @num_channels:       number of channels
 **/
void process_scan_gyro (char *data, struct iio_channel_info *channels, int num_channels)
{
        int k;
        int channel_num;

        for (k = 0; k < num_channels; k++){
                switch (channels[k].bytes) {
                        /* only a few cases implemented so far */
                case 2:
                        channel_num = k;
                        print2byte_gyro (*(uint16_t *)(data + channels[k].location),
                                   &channels[k], channel_num);
                        break;
                case 4:
                        if (!channels[k].is_signed) {
                                uint32_t val = *(uint32_t *)
                                        (data + channels[k].location);
                                printf("%05f ", ((float)val +
                                                 channels[k].offset)*
                                       channels[k].scale);

                        }
                        break;
                case 8:
                        if (channels[k].is_signed) {
                                int64_t val = *(int64_t *)
                                        (data +
                                         channels[k].location);
                                if ((val >> channels[k].bits_used) & 1)
                                        val = (val & channels[k].mask) |
						~channels[k].mask;
                                /* special case for timestamp */
                                if (channels[k].scale == 1.0f &&
                                    channels[k].offset == 0.0f)
                                        printf("%" PRId64 " ", val);
                                else
                                        printf("%05f ", ((float)val + channels[k].offset)*channels[k].scale);
                        }
                        break;
                default:
                        break;
                }
	}
}

void print2byte_gyro (int input, struct iio_channel_info *info, int channel_num)
{
        float final_val;
        /* First swap if incorrect endian */
        if (info->be)
                input = be16toh((uint16_t)input);
        else
                input = le16toh((uint16_t)input);

        /*
         * Shift before conversion to avoid sign extension
         * of left aligned data
         */
        input = input >> info->shift;
        if (info->is_signed) {
                int16_t val = input;
                val &= (1 << info->bits_used) - 1;
                val = (int16_t)(val << (16 - info->bits_used)) >>
                        (16 - info->bits_used);
                final_val = (float)(val + info->offset)*info->scale;
                //printf("%05f ", ((float)val + info->offset)*info->scale);
        } else {
                uint16_t val = input;
                val &= (1 << info->bits_used) - 1;
                //printf("%05f ", ((float)val + info->offset)*info->scale);
                final_val = ((float)val + info->offset)*info->scale;
        }
        if(channel_num == 0)
                gdata.x = (double) final_val;
        if(channel_num == 1)
                gdata.y = (double) final_val;
        if(channel_num == 2){
                gdata.z = (double) final_val;
//                printf("x: %05f, y: %05f, z: %05f, acc: %05f\r\n", adata.x, adata.y, adata.z, adata.acc);
        }
}

int get_gyroscope (gyroscope_api_priv *g_data)
{
	int ret;

	if (g_data == NULL){
		IOBD_DEBUG_LEVEL2 ("Not valid argument");
		return OBD2_LIB_FAILURE;	
	}	
	sem_wait (&gyro_lock);
	g_data -> x = gdata.x;
	g_data -> y = gdata.y;
	g_data -> z = gdata.z;
	sem_post (&gyro_lock);
	IOBD_DEBUG_LEVEL2 ("Gyroscope value: x : %f y: %f z: %f",g_data -> x, g_data -> y, g_data -> z);	
	return OBD2_LIB_SUCCESS;
}
