#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <semaphore.h>
#include "init.h"
#include "init.h"
#include "common.h"

#ifdef _XLS__EN_
int check_data_frequency(int id)
{

	int slp_time = 0;
	int rc = 0;

	switch(id){
		case FREQ_GPSUPDATE:
			libClient.run_time.duration = ((libClient.run_time.gps_duration + 10) * 1000);
			//                                printf("GPSUPDATE gps_duration %d duration %d \n",libClient.run_time.gps_duration,libClient.run_time.duration);
			break;

		case FREQ_CARSTATUS:
			libClient.run_time.duration = ((libClient.run_time.car_duration + 10) * 1000);
			//                              printf("CARSTATUS duration %d duration %d\n",libClient.run_time.car_duration,libClient.run_time.duration);
			break;

		case FREQ_ACCELEROMETER:
			libClient.run_time.duration = ((libClient.run_time.acc_duration + 10) * 1000);
			//                            printf("ACCELEROMETER acc_duration %d duration %d \n",libClient.run_time.acc_duration,libClient.run_time.duration);
			break;

		case FREQ_DTCCODE:
			libClient.run_time.duration = ((libClient.run_time.dtc_duration + 10) * 1000);
			//                          printf("DTCCODE duration %d \n",libClient.run_time.duration);
			break;
		case FREQ_GYROSCOPE:
			libClient.run_time.duration = ((libClient.run_time.gyro_duration + 10) * 1000);
			//                        printf("FREQ_GYROSCOPE gyro_duration %d duration %d \n",libClient.run_time.gyro_duration,libClient.run_time.duration);
			break;
		default:
			printf("Invalid feature id. Setting default frequency to 1 second \n");
			slp_time = 1 * 1000000;

	}

	//  printf("freq[id].value %d \n",libClient.xls_elem.freq[id].value);
	slp_time = (libClient.xls_elem.freq[id].value * 1000000) - libClient.run_time.duration;

	if(slp_time < 0)
		slp_time = 0;

	printf("frequency id %d sleep time is %d \n",id,slp_time);

	usleep(slp_time);

	return 0;
}
#endif
int init_ign_q(_libClient * libclient)
{
	struct mq_attr attr1;
	attr1.mq_flags = 0;
	attr1.mq_maxmsg = MAX_MESSAGES;
	attr1.mq_msgsize = MAX_MSG_SIZE+4;
	attr1.mq_curmsgs = 0;

	libclient->pwr_mgmt_qid = mq_open("/ign_status", O_RDWR | O_CREAT,NULL, &attr1);

	if (libclient->pwr_mgmt_qid == -1)
	{
		printf(" Message queue create failed ERROR--- %d \r\n",errno);
		return -1;
	}

	return 0;
}

int send_ign_q(_libClient * libclient,struct ign_stat *data)
{
	IOBD_DEBUG_LEVEL3 ("send_ign_q w+");
	sem_wait(&libclient->ign_sem);
	IOBD_DEBUG_LEVEL3 ("send_ign_q w-");
	//printf("Send Data is %s\r\n",data->msg_type);
	if (mq_send(libclient->pwr_mgmt_qid,(const char*) data, sizeof(struct ign_stat),0)  == -1) {
		printf("6.Message Queue send failed ERROR %d\r\n",errno);
		sem_post(&libclient->ign_sem);
		return -1;
	}
	IOBD_DEBUG_LEVEL3 ("send_ign_q p+");
	sem_post(&libclient->ign_sem);
	IOBD_DEBUG_LEVEL3 ("send_ign_q p-");
	return 0;
}
