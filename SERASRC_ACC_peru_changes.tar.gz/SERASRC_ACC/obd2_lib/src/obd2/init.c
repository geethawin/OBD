#include <stdlib.h>
#include<stdio.h>
#include<semaphore.h>
#include"netinet/in.h"
#include"init.h"
#include "common.h"
#include<string.h>
#include "q_gps.h"
#ifdef _XLS__EN_
#include "xls.h"
#else
#include "libxml2.h"
#endif
#include "obd2lib.h"

int init_mode_pid(car_parameters *carparams)
{
	int rc = 0;
#ifdef _XLS__EN_

	xlsWorkBook* pWB;
	xlsWorkSheet* pWS;
	struct st_row_data* row;
	WORD t,tt;
	int i,r;
	int mode,pid;
	mode = 0;
	pid = 0;
	char temp[64]={0},pidbuf[64]={0};
	pWB=xls_open("/iwtest/Application/modepid.xls","iso-8859-15//TRANSLIT");
	if (pWB!=NULL)
	{
		// open and parse the sheet
		pWS=xls_getWorkSheet(pWB,0);
		xls_parseWorkSheet(pWS);
		// process all rows of the sheet
		printf("init_mode_pid:pWS->rows.lastrow = %d\n",r = pWS->rows.lastrow);
		printf("init_mode_pid:pWS->rows.lastcol = %hd\n",pWS->rows.lastcol);

		carparams->modepid = (mode_pid *)calloc(pWS->rows.lastrow,sizeof(mode_pid));
		carparams->no_of_pids = pWS->rows.lastrow;

		for (i= 0,t=1;t<=pWS->rows.lastrow;i++,t++)
		{
			row=&pWS->rows.row[t];
			// process cells

			for (tt=0;tt<=pWS->rows.lastcol;tt++)
			{
				memset(temp,0,sizeof(temp));
				memset(pidbuf,0,sizeof(pidbuf));

				if (!row->cells.cell[tt].ishiden)
				{
					// display the value of the cell (either numeric or string)
					if (row->cells.cell[tt].id==0x27e || row->cells.cell[tt].id==0x0BD || row->cells.cell[tt].id==0x203)
					{
						if(tt == 0){
							mode = row->cells.cell[tt].d;
							carparams->modepid[i].mode = mode;
						}
						else if(tt==1){
							pid = row->cells.cell[tt].d;
							sprintf(temp,"%d",pid);
							if(strlen(temp)<2){
								strcpy(pidbuf,"0");
								strcat(pidbuf,temp);
							}
							else
								strcpy(pidbuf,temp);
							strcpy(carparams->modepid[i].pid,pidbuf);
						}
					}
					else if (row->cells.cell[tt].str!=NULL)
					{
						char *str = row->cells.cell[tt].str;

						if(tt == 1){
							if(strlen(str)<2)
							{
								strcpy(pidbuf,"0");
								strcat(pidbuf,str);
							}
							else
								strcpy(pidbuf,str);
							strcpy(carparams->modepid[i].pid,pidbuf);
						}
						else
							(tt == 3)?strcpy(carparams->modepid[i].description,str) : strcpy(carparams->modepid[i].topic,str);
					}
					else
						continue;

				}
			}
		}
		xls_close(pWB);
		for(i = 0; i < r; i++)
			printf("mpd.mode = %d\tmpd.pid = %s\tmpd.topic = %s\tmpd.des = %s\n",carparams->modepid[i].mode,carparams->modepid[i].pid,carparams->modepid[i].topic,carparams->modepid[i].description);
	}
	else{
		printf("modepid.xls File couldn't open!! \n");
		rc = -1;
	}
#else
	char value [5];
	char pid_no[10];
	int i;	
	carparams->modepid = (mode_pid *)calloc(10,sizeof(mode_pid));
	for (i = 0;i<10;i++){
		bzero (pid_no,sizeof(pid_no));
		bzero (value,sizeof(value));
		sprintf(pid_no,"%s%d","pid",i+1);
		rc = get_xml_content (SRC_XML_FILE, "mode_1", pid_no, value);
		strcpy (carparams->modepid[i].pid, value);
		carparams->modepid[i].mode = 1;
	}
		carparams->no_of_pids = i;
#endif
	return rc;

}


int set_default_freq_values(struct frequency *freq)
{
	strcpy(freq[0].name,"GPSUPDATE");
	strcpy(freq[0].select,"Yes");
	freq[0].value = 1;

	strcpy(freq[1].name,"CARSTATUS");
	strcpy(freq[1].select,"Yes");
	freq[1].value = 2;

	strcpy(freq[2].name,"ACCELEROMETER");
	strcpy(freq[2].select,"Yes");
	freq[2].value = 2;

	strcpy(freq[3].name,"DTCCODE");
	strcpy(freq[3].select,"Yes");
	freq[3].value = 2;

	strcpy(freq[4].name,"GYROSCOPE");
	strcpy(freq[4].select,"Yes");
	freq[4].value = 2;

	return 0;
}

int init_frequency(struct frequency * freq)
{
	int rc = 0;
#ifdef _XLS__EN_
	xlsWorkBook* pWB;
	xlsWorkSheet* pWS;
	struct st_row_data* row;
	WORD t,tt;
	int i,r;
	int mode,pid;
	mode = 0;
	pid = 0;
	pWB=xls_open("/iwtest/Application/frequency.xls","iso-8859-15//TRANSLIT");
	printf(" pWB=xls_open %x \n",pWB);
	if (pWB!=NULL)
	{
		// open and parse the sheet
		pWS=xls_getWorkSheet(pWB,0);

		xls_parseWorkSheet(pWS);

		// process all rows of the sheet
		printf("init_frequency:pWS->rows.lastrow = %d\n",r = pWS->rows.lastrow);
		printf("init_frequency:pWS->rows.lastcol = %hd\n",pWS->rows.lastcol);

		//carparams->modepid = (MODE_PID *)calloc(pWS->rows.lastrow,sizeof(MODE_PID));
		for (i= 0,t=1;t<=pWS->rows.lastrow;i++,t++)
		{
			row=&pWS->rows.row[t];

			// process cells
			for (tt=0;tt<=pWS->rows.lastcol;tt++)
			{
				if (!row->cells.cell[tt].ishiden)
				{
					// display the value of the cell (either numeric or string)
					if (row->cells.cell[tt].id==0x27e || row->cells.cell[tt].id==0x0BD || row->cells.cell[tt].id==0x203)
					{
						if(tt == 2){
							freq[i].value = row->cells.cell[tt].d;
						}
					}
					else if (row->cells.cell[tt].str!=NULL)
					{
						char *str = row->cells.cell[tt].str;

						if(tt == 0){
							strcpy(freq[i].name,str);
						}
						else if(tt == 1) {
							strcpy(freq[i].select,str);
						}
					}
					else
						continue;
				}
			}
		}
		xls_close(pWB);
		for(i = 0; i < r; i++)
			printf("name = %s \tselect = %s\tvalue = %d\t\n",freq[i].name,freq[i].select,freq[i].value);
	}
	else{
		printf("frequency.xls File couldn't open!! \n");
		rc = -1;
	}
#else
	char value [10];
        
        int i;
	char sub_node[][24] = {"sampling_frequency", "can_sign", "duration"};

	get_xml_content (SRC_XML_FILE, "general", sub_node[0], value);	
	freq[0].value = atoi(value);
	get_xml_content (SRC_XML_FILE, "general", sub_node[1], value);	
	freq[1].value = atoi(value);
	get_xml_content (SRC_XML_FILE, "overspeed", sub_node[2], value);	
	freq[2].value = atoi(value);

#endif
	return rc;
}


int hw_init(void)
{
	int rc = 0;
	printf("hw_init +\n");
	system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
	system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
	system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
	system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
	/*!< 12 V Switch */
	system("echo 1 > /sys/class/gpio/gpio92/value");
	/*!< 3V3 Switch */
	system("echo 1 > /sys/class/gpio/gpio91/value");
	/*!< 4V4 Switch */
	system("echo 1 > /sys/class/gpio/gpio90/value");
	/*!< Interpreter CAN ON */
	system("echo 0 > /sys/class/gpio/gpio32/value");
	/*!< Interpreter CAN ON */
	system("echo 1 > /sys/class/gpio/gpio67/value");
	/* NaNC: */
	rc = obd_init();	
	/* NaNC */

	printf("hw_init - rc %d \n",rc);
	return rc;
}

void hw_deinit(void)
{
	printf(" hw_deinit +\n");
	gps_deinit(libClient.gps_fd);
	/* NaNC : Flag reset for gps handle */
	libClient.ppp0_link_status = LINK_DOWN;
	libClient.gps_node_open=0;
	libClient.init_connect = 0;
	if(libClient.set_raw_can == 1)
		can_deinit();
	/*LED OFF*/
	system ("echo 0 > /sys/class/gpio/gpio77/value");
	printf(" hw_deinit -\n");

}

#ifdef _XLS__EN_ 
int init (IGN_PTRS *ptr,SLEEP_WAKE *sw,_xls * xls_objs)
{

	int rc = 0;

	libClient.ign_fptr.ign_ON   = ptr->ign_ON;
	libClient.ign_fptr.ign_OFF  = ptr->ign_OFF;
	libClient.ign_fptr.dis_stat = ptr->dis_stat;
	libClient.ign_fptr.bat_drain = ptr->bat_drain;
	libClient.ign_fptr.pnc_btn = ptr->pnc_btn;
	libClient.ign_fptr.crash_det = ptr->crash_det;

	libClient.dev_sleep = DEV_WAKE;

	libClient.s_w.slp 	= sw->slp;
	libClient.s_w.wake	= sw->wake;
	libClient.s_w.slp_dis 	= sw->slp_dis;

	/* Init Msg Q */
	if (init_ign_q(&libClient) == -1) {
		printf("init_ign_q : Message Queue Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.acm_node, 0, 1) == -1)
	{
		printf("libClient.acm_node : Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_off_sem, 0, 1) == -1)
	{
		printf("libClient.ign_off_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.sem_board_init_complete, 0, 0) == -1)
	{
		printf("libClient.sem_board_init_complete: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.sys_wake, 0, 1) == -1)
	{
		printf("libClient.sys_wake :sys_wake Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_sem, 0, 1) == -1)
	{
		printf("libClient.ign_of_sem: ign_of_sem Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_off_restart, 0, 0) == -1)
	{
		printf("libClient.ign_off_restart: ign_off_restart Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_dis, 0, 1) == -1)
	{
		printf("libClient.ign_of_dis: Sem Create Failed\r\n");
		rc = -1;
	}
	/* Init Semaphore*/
	if (sem_init(&libClient.ign_t_sem, 0, 1) == -1)
	{
		printf("libClient.ign_t_sem: ign_t_sem Sem Create Failed\r\n");
		rc = -1;
	}
	if (sem_init(&libClient.btry_drain, 0, 1) == -1)
	{
		printf("libClient.btry_drain: btry_drain Sem Create Failed\r\n");
		rc = -1;
	}



	/* Init Semaphore*/
	if (sem_init(&libClient.ign_sem, 0, 1) == -1)
	{
		printf("libClient.ign_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore for obd_read_data*/
	if (sem_init(&libClient.obd_sem, 0, 1) == -1)
	{
		printf("libClient.obd_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	if (sem_init(&libClient.gps_sem, 0, 1) == -1)
	{
		printf("libClient.gps_sem: Sem Create Failed\r\n");
		rc = -1;
	}
	printf("\n********************************************************************************\n");
	printf("\n****************************** OBD - Version %s *******************************\n",OBD_VERSION);
	printf("\n********************************************************************************\n");

	libClient.fresh_boot = 1;
	libClient.car_mode = 0;
	libClient.init_connect = 0;
	libClient.gyro_mounted = 0;
	libClient.gps_init_fix = 0;

	rc = init_mode_pid(&libClient.xls_elem.car_params);
	if(rc < 0)
	{
		printf("init_mode_pid failed!!\n");
	}

	memcpy(&xls_objs->car_params,&libClient.xls_elem.car_params,sizeof(car_parameters));

	rc = set_default_freq_values(libClient.xls_elem.freq);
	if(rc < 0)
	{
		printf("set_default_values failed!!\n");
	}
	memcpy(xls_objs->freq,libClient.xls_elem.freq,(sizeof(libClient.xls_elem.freq)));

	rc = init_frequency(libClient.xls_elem.freq);
	if(rc < 0)
	{
		printf("init_init_frequency failed!! loading default values \n");
	}
	memcpy(xls_objs->freq,libClient.xls_elem.freq,(sizeof(libClient.xls_elem.freq)));
#if 0
	int i = 0;
	for(i = 0; strlen(xls_objs->freq[i].name)>0; i++)
		printf(" \n\n out name = %s \tselect = %s\tvalue = %f\t\n",xls_objs->freq[i].name,xls_objs->freq[i].select,xls_objs->freq[i].value);
#endif
	GPIO_config();
	printf("GPIO configured\n");

	return rc;
}
#endif

int init (IGN_PTRS *ptr,SLEEP_WAKE *sw,_xml * xml_objs)
{
	IOBD_DEBUG_LEVEL3 ("init +");
	int rc = 0;

	libClient.ign_fptr.ign_ON   = ptr->ign_ON;
	libClient.ign_fptr.ign_OFF  = ptr->ign_OFF;
	libClient.ign_fptr.dis_stat = ptr->dis_stat;
	libClient.ign_fptr.bat_drain = ptr->bat_drain;
	libClient.ign_fptr.pnc_btn = ptr->pnc_btn;
	libClient.ign_fptr.crash_det = ptr->crash_det;

	libClient.dev_sleep = DEV_WAKE;

	libClient.s_w.slp 	= sw->slp;
	libClient.s_w.wake	= sw->wake;
	libClient.s_w.slp_dis 	= sw->slp_dis;

	/* Init Msg Q */
	if (init_ign_q(&libClient) == -1) {
		printf("init_ign_q : Message Queue Create Failed id = \r\n",libClient.pwr_mgmt_qid);
		rc = -1;
	}
	
	if (sem_init_usb("/sem_16") == -2)
		printf("sem_init_usb - failed\n");
	
#if 0
//	libClient.acm_node = sem_open("/my_sema", O_CREAT, 0644, 1);
	if (sem_init_4g ("/sem_4g",libClient.acm_node) == -2)
		printf("sem_init_4g - failed\n");
	else
		printf("sem_init_4g - success\n");
#endif
	/* Init Semaphore*/
	if (sem_init(&libClient.acm_node, 0, 1) == -1)
	{
		printf("libClient.acm_node : Sem Create Failed\r\n");
		rc = -1;
	}
	/* Init Semaphore*/
	if (sem_init(&libClient.ign_off_sem, 0, 1) == -1)
	{
		printf("libClient.ign_off_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.sem_board_init_complete, 0, 0) == -1)
	{
		printf("libClient.sem_board_init_complete: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.sys_wake, 0, 1) == -1)
	{
		printf("libClient.sys_wake :sys_wake Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_sem, 0, 1) == -1)
	{
		printf("libClient.ign_of_sem: ign_of_sem Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_off_restart, 0, 0) == -1)
	{
		printf("libClient.ign_off_restart: ign_off_restart Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_dis, 0, 1) == -1)
	{
		printf("libClient.ign_of_dis: Sem Create Failed\r\n");
		rc = -1;
	}
	/* Init Semaphore*/
	if (sem_init(&libClient.ign_t_sem, 0, 1) == -1)
	{
		printf("libClient.ign_t_sem: ign_t_sem Sem Create Failed\r\n");
		rc = -1;
	}
	if (sem_init(&libClient.btry_drain, 0, 1) == -1)
	{
		printf("libClient.btry_drain: btry_drain Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_sem, 0, 1) == -1)
	{
		printf("libClient.ign_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore for obd_read_data*/
	if (sem_init(&libClient.obd_sem, 0, 1) == -1)
	{
		printf("libClient.obd_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	if (sem_init(&libClient.gps_sem, 0, 1) == -1)
	{
		printf("libClient.gps_sem: Sem Create Failed\r\n");
		rc = -1;
	}
	printf("\n********************************************************************************\n");
	printf("\n****************************** OBD - Version %s 1*******************************\n",OBD_VERSION);
	printf("\n********************************************************************************\n");

	libClient.fresh_boot = 1;
	libClient.car_mode = 0;
	libClient.init_connect = 0;
	libClient.gyro_mounted = 0;
	libClient.gps_init_fix = 0;

	rc = init_mode_pid(&libClient.xml_elem.car_params);
	if(rc < 0)
	{
		printf("init_mode_pid failed!!\n");
	}

	memcpy(&xml_objs->car_params,&libClient.xml_elem.car_params,sizeof(car_parameters));

	rc = init_frequency(libClient.xml_elem.freq);
	if(rc < 0)
	{
		printf("init_init_frequency failed!! loading default values \n");
	}
	memcpy(xml_objs->freq,libClient.xml_elem.freq,(sizeof(libClient.xml_elem.freq)));
#if 0
	int i = 0;
	for(i = 0; strlen(xls_objs->freq[i].name)>0; i++)
		printf(" \n\n out name = %s \tselect = %s\tvalue = %f\t\n",xls_objs->freq[i].name,xls_objs->freq[i].select,xls_objs->freq[i].value);
#endif
	GPIO_config();

	IOBD_DEBUG_LEVEL3 ("init -");
	return rc;

}

void sys_sleep_completed(void)
{
	printf("sys_sleep_completed \n");
	return;
}

void sys_wake_completed(void)
{
	/* NaNC : Clear all the ignition flags */
	printf(" sys_wake_completed + \n");
	sem_post(&libClient.sys_wake);
	printf(" sys_wake_completed - \n");

	return;
}
