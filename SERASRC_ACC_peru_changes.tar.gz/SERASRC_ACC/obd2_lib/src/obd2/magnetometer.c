/* headers */
#include "magnetometer.h"
#include "init.h"
struct input_event ev[64];
int mag_set = 0;
int mag_event_no = 0;

int mag_init()
{
	system(MAGNETOMETER_ENABLE);
	return 0;
}

int mag_deinit()
{
	/* NaND : Disable all 3 pins  */
	printf(" mag_deinit +\n");

	system(MAGNETOMETER_DISABLE);

	printf(" mag_deinit -\n");

	return 0;
}

int get_magnetometer_event() {

	int event_no = 0, i = 0;
	FILE *fp;
	char command[100];
	char *intf_conf;
	char file[256];

	system("cat /sys/class/input/input0/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mag");
	if(intf_conf) {
		event_no = 0;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input1/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mag");
	if(intf_conf) {
		event_no = 1;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input2/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mag");
	if(intf_conf) {
		event_no = 2;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);

	system("rm -rf event.txt");

	system("cat /sys/class/input/input3/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mag");
	if(intf_conf) {
		event_no = 3;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");

	system("cat /sys/class/input/input4/name > event.txt");
	fp = fopen("event.txt", "r");
	fread(&command, 100, 1, fp);
	intf_conf = strstr(command,"mag");
	if(intf_conf) {
		event_no = 4;
		fclose(fp);
		system("rm -rf event.txt");
		return event_no;
	}
	fclose(fp);
	system("rm -rf event.txt");
}

/* magnetometer read function reads raw data */
int magnetometer_read(void)
{
	int fd;
	int i, rd;
	unsigned int type, code;
	struct timeval timeout;
	int retval;
	double x,y,z;
	float heading,prev_head;
	static int j=0;
	int rc = 0;
	fd_set rdfs;
	char file[100] = {0};

	if(mag_set == 0) {
		mag_event_no = get_magnetometer_event();
		printf("mag_event_no : %d\r\n", mag_event_no);
		mag_set = 1;
	}

	if (mag_event_no == 0) {
		printf("magnetometer is not mounted\r\n");
		rc = -1;
	}
	else {
		sprintf(file, "/dev/input/event%d", mag_event_no);

		if ((fd = open (file, O_RDWR)) < 0) {
			printf("Error Occured while opening Device File.!!\n");
			return -1;
		}
		else {
			printf("Device File Opened Successfully !! /dev/input/event2\n");
		}

		FD_ZERO(&rdfs);
		FD_SET(fd, &rdfs);

		/* timeout wait for 500ms */
		timeout.tv_sec = 0;
		timeout.tv_usec = 10000;

		retval = select(fd + 2, &rdfs, NULL, NULL, &timeout);
		if(retval) {
			rd = read(fd, ev, sizeof(ev));
			if (rd < (int) sizeof(struct input_event)) {
				printf("expected %d bytes, got %d\n", (int) sizeof(struct input_event), rd);
				return 1;
			}

			for (i = 0; i < rd / sizeof(struct input_event); i++) {

				type = ev[i].type;
				code = ev[i].code;
				if(i == 2)
				{
					printf("MAG_LIB : x %d y %d z %d \r\n", ev[0].value,ev[1].value,ev[2].value);
					rc = 0;
				}
			}

			FD_SET(fd, &rdfs);
			printf("%s : close value is :%d\r\n", __func__, fd);
			close(fd);

		}else
			rc = -1;
	}

	return rc;
}

int get_magnetometer(magnetometer_api_priv *mdata)
{
	int rc = 0;
	struct timeval mag_start_time, mag_end_time;
	printf("get_magnetometer data \n");
	gettimeofday(&mag_start_time, NULL);
	memset(mdata,0,sizeof(magnetometer_api_priv));
	rc = magnetometer_read();
	gettimeofday(&mag_end_time, NULL);
	libClient.run_time.mag_duration = ((mag_end_time.tv_usec - mag_start_time.tv_usec) + (mag_end_time.tv_sec - mag_start_time.tv_sec)*1000000)/1000;
	if (rc == 0)
	{
		mdata->x = (float)ev[0].value * 0.1;
		mdata->y = (float)ev[1].value * 0.1;
		mdata->z = (float)ev[2].value * 0.1;

		printf("in lib magnetometer_read [x-axis: %f] \r\n", mdata->x);
		printf("in lib magnetometer_read [y-axis: %f] \r\n", mdata->y);
		printf("in lib magnetometer_read [z-axis: %f] \r\n", mdata->z);

	}
	if(rc < 0)
	{
		rc = -1;
		printf("magnetometerometer_read failed \n");
	}

	return rc;
}
