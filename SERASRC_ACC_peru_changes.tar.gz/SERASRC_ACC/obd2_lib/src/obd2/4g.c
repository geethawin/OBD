#include <stdio.h>
#include <stdlib.h>
#include "4g.h"
#include "q_gps.h"
#include "init.h"
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "err_macro.h"

static int flight_on;

int get_imei_modem(char *imei_no)
{
	char val[20];
	char at_cmd[10];
	int numberofbytesent, numberofbytesrcvd;
	int serial_fd = 0;
//	FILE *fp;
	int rc = 0;
//	fp = fopen("/home/root/imei.txt","w");

	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");

	serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(serial_fd <= 0)
	{
		printf ("get_imei_modem: iW_Serial_Init: failed\n");

		printf("acm fp+ \n");
		sem_post(&libClient.acm_node);
		printf("acm fp- \n");

		return -1;
	}
	bzero (imei_no,20);
	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
	strcpy(at_cmd, "ate0\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc = -1;
	}
	usleep(1000000);
	numberofbytesrcvd = read(serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
		rc = -1;
	}

	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
send_again:	strcpy(at_cmd, "at+gsn\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("get_imei_modem:iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc= -1;
	}
	usleep(1000000);
	numberofbytesrcvd = read(serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
		rc = -1;
	}

	strncpy(imei_no, &val[2], 15);
	if ((imei_no[1] != '6') && (imei_no[0] != '8'))
		goto send_again;

	printf("imei_no:%s\r\n", imei_no);
//	fprintf(fp,"id=%s",imei_no);
	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
//	fclose(fp);
	close(serial_fd);

	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");

	return rc;
}

int get_gps_data_from_gprs(int serial_fd, double *lat, double *lon)
{
	int ret;
	int timeout;
	char longt_buf[200];
	char lat_buf[200];
	size_t nbytes;
	int i,numberofbytesent,numberofbytesrcvd;
	char read_buff;
	char loc_buff[200];
	char *datap;
	char *lonp;
	char at_cmd[1024];
	char val[300];
	static int r_count =0;

	memset(val, 0x0, 200);
	memset(at_cmd, 0x0, 200);
	strcpy(at_cmd,"AT+QCELLLOC=1\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		return -1;
	}
	usleep(500000);
	while(1){
		memset( loc_buff, 0x0, 200);
		numberofbytesrcvd = read(serial_fd,loc_buff,100);
		if(numberofbytesrcvd <= 0)
		{
#if DEBUG_PRINT
			perror("get_gps_data_from_gprs:iw_serial_read:\nerror while reading from serial device");
			printf("errno = %d \r\n",errno);
#endif
			r_count++;
			if (r_count == 3)
				usleep(500000);

			if (r_count == 5){
				r_count = 0;
				return -1;
			}
		}
		r_count = 0;
		break;
	}

	datap = strstr(loc_buff,"+QCELLLOC:");

	if (datap)
	{
		lonp = strstr(datap,",");
		if (lonp)
		{
			strncpy(longt_buf,&datap[11],(lonp - (datap + 11)));

			*lon = atof (longt_buf);
			*lat = atof (&lonp[1]);


		}
		else
		{
			printf(" Found +QCELLLOC: but didnt find comma. Return\r\n");
		}

	}
	else
	{
		printf(" QCELLLOC Response is not proper \r\n");
		return -1;
	}
	close(serial_fd);
	return 0;
}

int check_connection()
{
	FILE *fp;
	char command[200];
	int ret = 0;

	fp = fopen("/home/root/link_status.txt", "r");
	if(fp == NULL){
		printf("error created\r\n");
	}

	fread(&command, 11, 1, fp);
	if(strncmp(command, "link is up", 10) == 0) {
		ret = 1;
		printf("the link is up\r\n");
	}
	else {
		ret = 0;
		printf("the link is down\r\n");
	}

	fclose(fp);

	return ret;
}

int flight_mode()
{

	char val[300];
	char at_cmd[1024];
	int i,numberofbytesent;
	int rc = 0;
	int serial_fd = 0;

	printf("Entered Flight mode\n");
	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");

	if (flight_on != 1){
		serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
		if(serial_fd <= 0)
		{
			printf ("flight_mode: iW_Serial_Init: failed\n");
			printf("acm fp+ \n");
			sem_post(&libClient.acm_node);
			printf("acm fp- \n");
			return -1;

		}

		memset(val, 0x0, 200);
		memset(at_cmd, 0x0, 200);
		strcpy(at_cmd,"AT+CFUN=0\r");
		numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
		if(numberofbytesent <= 0)
		{
			perror("iw_serial_write:\nerror while writing to serial device\n");
			printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
			rc = -1;
			goto exit;
		}

		memset(val, 0x0, 200);
		memset(at_cmd, 0x0, 200);
		strcpy(at_cmd,"AT+CFUN=1\r");
		numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
		if(numberofbytesent <= 0)
		{
			perror("iw_serial_write:\nerror while writing to serial device\n");
			printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
			rc = -1;
		}

exit:
		close(serial_fd);
	}
	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");

	return rc;
}

int flight_mode_on()
{

	char val[300];
	char at_cmd[1024];
	int i,numberofbytesent;
	int rc = 0;
	int serial_fd = 0;

	printf("Entered Flight mode_on\n");
	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");

	serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(serial_fd <= 0)
	{
		printf ("flight_mode_on: iW_Serial_Init: failed\n");
		printf("acm fp+ \n");
		sem_post(&libClient.acm_node);
		printf("acm fp- \n");
		return -1;

	}

	memset(val, 0x0, 200);
	memset(at_cmd, 0x0, 200);
	strcpy(at_cmd,"AT+CFUN=0\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc = -1;
		goto exit;
	}

	memset(val, 0x0, 200);
	memset(at_cmd, 0x0, 200);
	
	flight_on = 1;
exit:
	close(serial_fd);
	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");

	return rc;
}

int flight_mode_off()
{

	char val[300];
	char at_cmd[1024];
	int i,numberofbytesent;
	int rc = 0;
	int serial_fd = 0;

	printf("Entered Flight mode_off\n");
	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");

	serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(serial_fd <= 0)
	{
		printf ("flight_mode_off: iW_Serial_Init: failed\n");
		printf("acm fp+ \n");
		sem_post(&libClient.acm_node);
		printf("acm fp- \n");
		return -1;

	}

	memset(val, 0x0, 200);
	memset(at_cmd, 0x0, 200);
	strcpy(at_cmd,"AT+CFUN=1\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc = -1;
		goto exit;
	}

	memset(val, 0x0, 200);
	memset(at_cmd, 0x0, 200);
	flight_on = 0;
	
exit:
	close(serial_fd);
	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");

	return rc;
}

int module_3g_on()
{

	/*!< USB power Switch */
	system("echo 1 > /sys/class/gpio/gpio78/value");
	/*!< RESET_N pin high */
//	system("echo 0 > /sys/class/gpio/gpio79/value");
//	usleep(100000);
	
	system("echo 0 > /sys/class/gpio/gpio47/value");
	usleep(200000);

	system("echo 1 > /sys/class/gpio/gpio47/value");
	usleep(600000);

	system("echo 0 > /sys/class/gpio/gpio47/value");
	sleep(2);// required to perform insmod properly: /*peru*/
	
	system ("insmod /usb/udc-core.ko");
	system ("insmod /usb/libcomposite.ko");
	system ("insmod /usb/ci_hdrc.ko");
	system ("insmod /usb/usbmisc_imx.ko");
	system ("insmod /usb/ci_hdrc_imx.ko");
	system ("insmod /usb/u_serial.ko");
	system ("insmod /usb/usb_f_serial.ko");
	system ("insmod /usb/usb_f_acm.ko");
	system ("insmod /usb/g_serial.ko");
	return 0;
}

int module_3g_off()
{
	int ret = 0;
	//int count = 0;
	int count = 1;
	char command[200];
	FILE *fp;
	char *intf_conf;
	char ts[64] = {0};
	struct ign_stat ign_qdata;
	printf("module_3g_off \n");
	int ign_on_restart = 0;	
	/* make 4g module off */
//	system("echo 0 > /sys/class/gpio/gpio47/value");
//	usleep(100000);
        system ("rmmod g_serial");
        system ("rmmod usb_f_acm");
        system ("rmmod usb_f_serial");
        system ("rmmod u_serial");
        system ("rmmod ci_hdrc_imx");
        system ("rmmod usbmisc_imx");
        system ("rmmod ci_hdrc");
        system ("rmmod libcomposite");
	system ("rmmod udc-core");

	system("echo 1 > /sys/class/gpio/gpio47/value");
	usleep(600000);
	system("echo 0 > /sys/class/gpio/gpio47/value");
	/* wait for 30 secs during turning off 4g module */
	//	count = 15;
	/* NaN : check on status every second */
	while(1){
		printf("While Sleep count %d ign_on_restart %d\n",count,ign_on_restart);
		count++;
		if((count == 10) || (access("/dev/ttyUSB3",F_OK)))//before 30
			break;
		if(ign_on_restart!=1){
			ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
			printf("module_3g_off ret is %d\r\n", ret);
			if(ret == IGNITION_STATE_ON) {
				get_time(ts);
				ign_on_restart = 1;					
				config_wakeup_timer_trigger(TIMER_DISABLE, 0);
			}
		}
		sleep(1);
	}
	system("echo 0 > /sys/class/gpio/gpio78/value");

	printf("*******3G module is off*********\r\n");
	if(ign_on_restart == 1)
	{
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		printf("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		printf("ignition on timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
		send_ign_q(&libClient,&ign_qdata);
		return DEVICE_RESTART;
	}

	return ret;
}

int check_registration()
{
	/*commented for R2.0*/
	int sim_fd = 0;
	int ret = 0;
	int status, i;
	char at_cmd[16];
	char val[300];
	int numberofbytesent,numberofbytesrcvd;
	int r_count;
	int s_val;
	char imei[20];

	printf ("check_registration+\n");
	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");

	sim_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(sim_fd <= 0)
	{
		printf ("iW_Init: iW_Serial_Init: failed\n");
		printf("acm fp+ \n");
		sem_post(&libClient.acm_node);
		printf("acm fp- \n");

		return -1;
	}

	while(1){	
			numberofbytesrcvd = read(sim_fd, val,20);
		//	printf("response after module on\n res = %s\n",val);
			if (strstr (val,"CPIN")){
				if (strstr(val,"READY")){
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","1");
					printf("sim status READY\n");
				}
				else if (strstr(val,"NOT")){
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","0");
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","0");
					printf("sim status NOT INSERTED\n");
					ret = -2;
					break;
				}
			}		
			if (strstr(val,"PB DONE"))
				break;
		//tcflush(sim_fd, TCIFLUSH);  /////peru commented
	#if 0
		memset(val, 0x0, 200);
		memset(at_cmd, 0x0, sizeof(at_cmd));
		strcpy(at_cmd, "AT+CREG?\r");
		printf("check_registration 1 sim_fd %d \r\n",sim_fd);
		numberofbytesent = write (sim_fd ,at_cmd, strlen(at_cmd));
		printf("**************at_cmd %s **************\nnumberofbytesent %d \r\n",at_cmd,numberofbytesent);
		if(numberofbytesent <= 0)
		{
			//#if DEBUG_PRINT
			perror("check_registration:iw_serial_write:\nerror while writing  \"AT+CREG?\" to serial device\n");
			printf("errno = %d, sim_fd %d\r\n",errno,sim_fd);
			//#endif
		}

		while(1){
			sleep(1);
			numberofbytesrcvd = read(sim_fd, val,100);
			printf("AT+CREG Response is %s sim_fd %d numberofbytesrcvd %d\n",val,sim_fd,numberofbytesrcvd);
			if(numberofbytesrcvd <= 0)
			{	
				r_count++;
				if (r_count <= 2){
					//#if DEBUG_PRINT
					perror("check_registration:iw_serial_read:\nerror while reading \"AT+CREG?\" from serial device");
					printf("errno = %d \r\n",errno);
					//#endif
					if (r_count == 2)
						usleep(500000);

					continue;
				}else{
					r_count = 0;
					break;
				}
			}
			r_count = 0;
			break;
		}
		//#if DEBUG_PRINT_RES
		printf("\nAT+CREG? Response\n");
		for(i=0;i<numberofbytesrcvd;i++)
		{
			printf ("%c",val[i]);
		}
		//#endif


		for (i = 0; val[i];i++){
			if(val[i] == ','){
				status = val[i+1] - 48;
				break;
			}
			else
				continue;
		}

		if(status != 1 && status != 5)
			continue;
		else
			break;
		#endif
	}

	close(sim_fd);

	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");
	get_imei_modem (imei);
        set_xml_content (SRC_XML_FILE, "home", "imei",imei);
	return ret;
}

int get_sim_status ()
{
	int sim_status;
        char temp_str[64]={0};
        char val[100] = {0};
        char at_cmd[50] = {0};
        int numberofbytesent, numberofbytesrcvd;
        int serial_fd = 0;

        printf("get_sim_status +\n");

        printf("acm w+ \n");
        sem_wait(&libClient.acm_node);
        printf("acm w- \n");
        serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
        if(serial_fd <= 0)
        {
                printf ("get_sim_status: iW_Serial_Init: failed\n");
                printf("acm fp+ \n");
                sem_post(&libClient.acm_node);
                printf("acm fp- \n");
                return -1;
        }

        memset(val, 0x0, 100);
        memset(at_cmd, 0x0, 50);
	strcpy(at_cmd, "ate0\r");
        numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
        if(numberofbytesent <= 0)
        {
                perror("get_sim_status:iw_serial_write:\nerror while writing to serial device\n");
                printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
        }
        usleep(500000);
        numberofbytesrcvd = read(serial_fd, val, 100);
        if(numberofbytesrcvd <= 0)
        {
                perror("get_sim_status:iw_serial_read:\nerror while reading from serial device");
                printf("errno = %d \r\n",errno);
        }

        memset(val, 0x0, 100);
        memset(at_cmd, 0x0, 50);
        strcpy(at_cmd, "at+cpin?\r");
        numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
        if(numberofbytesent <= 0)
        {
                perror("get_sim_status:iw_serial_write:\nerror while writing to serial device\n");
                printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
        }
        usleep(500000);
        numberofbytesrcvd = read(serial_fd, val, 100);
        if(numberofbytesrcvd <= 0)
        {
                perror("get_sim_status:iw_serial_read:\nerror while reading from serial device");
                printf("errno = %d \r\n",errno);
        }

	printf("sim_status is %s\n",val);
	if (strstr(val,"READY"))
		sim_status = 1;
	else if (strstr(val,"+CME ERROR: 10"))
		sim_status = 0;
	else
		sim_status = -1;
        printf("get_sim_status - %d\n",sim_status);

	return sim_status;

}

int get_sim_id(char *sim_id)
{

	char * sim_id_ptr;
	char temp_str[64]={0};
	char val[100] = {0};
	char at_cmd[50] = {0};
	int numberofbytesent, numberofbytesrcvd;
	int serial_fd = 0;

	printf("get_sim_id + \n");

	printf("acm w+ \n");
	sem_wait(&libClient.acm_node);
	printf("acm w- \n");
	serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(serial_fd <= 0)
	{
		printf ("get_sim_id: iW_Serial_Init: failed\n");
		printf("acm fp+ \n");
		sem_post(&libClient.acm_node);
		printf("acm fp- \n");
		return -1;
	}

	memset(val, 0x0, 100);
	memset(at_cmd, 0x0, 50);
	strcpy(at_cmd, "ate0\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("get_sim_id:iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
	}
	usleep(500000);
	numberofbytesrcvd = read(serial_fd, val, 100); 
	if(numberofbytesrcvd <= 0)
	{
		perror("get_sim_id:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
	}

	memset(val, 0x0, 100);
	memset(at_cmd, 0x0, 50);
	strcpy(at_cmd, "at+qccid\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("get_sim_id:iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
	}
	usleep(500000);
	numberofbytesrcvd = read(serial_fd, val, 100);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_sim_id:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
	}

	sim_id_ptr = strtok(val, ":");
	sim_id_ptr = strtok(NULL, "\n");

	strcpy(temp_str,sim_id_ptr+1);
	strncpy(sim_id,temp_str,strlen(temp_str)-1);
	printf("sim_id_ptr: %s\r\n", sim_id_ptr);
	printf("sim_id: %s\r\n", sim_id);
	memset(val, 0x0, 100);
	memset(at_cmd, 0x0, 50);
	close(serial_fd);

	printf("acm p+ \n");
	sem_post(&libClient.acm_node);
	printf("acm p- \n");
	printf("get_sim_id iccid %s \n",sim_id);
	return 0;
}

int set_cell_network_mode (int type)
{
	char at_cmd [64];
	char val [64];	
	int ret;
	int serial_fd;

	IOBD_DEBUG_LEVEL1("acm w+");
        sem_wait(&libClient.acm_node);
        IOBD_DEBUG_LEVEL1("acm w-");
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0, sizeof(at_cmd));

	if(access(USB_0,F_OK)){
                IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
                sem_post(&libClient.acm_node);
                return E_4G_USB_DISCONNECT;
        }
	else{
		serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
		if(serial_fd <= 0)
		{
			IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", serial_fd, E_4G_USB_INIT);
			IOBD_DEBUG_LEVEL2("acm fp+");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL2("acm fp- \n");
			return E_4G_USB_INIT;
		}
	}
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	strcpy(at_cmd, DISABLE_ECHO);
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
		close(serial_fd);
		IOBD_DEBUG_LEVEL2("acm fp+");
		sem_post(&libClient.acm_node);
		IOBD_DEBUG_LEVEL2("acm fp- \n");
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
			close(serial_fd);
			IOBD_DEBUG_LEVEL2("acm fp+");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL2("acm fp- \n");
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_0,F_OK)){
				IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				close(serial_fd);
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
				IOBD_DEBUG_LEVEL2("acm fp+");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read: buf : %s",val);
		}
	}
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	if (type == MODE_TYPE_2G){
		strcpy(at_cmd, MODE_2G);
		IOBD_DEBUG_LEVEL3 ("2G_MODE set");
	}
	else if (type == MODE_TYPE_3G){
		strcpy(at_cmd, MODE_3G);
		IOBD_DEBUG_LEVEL3 ("3G_MODE set");
	}
	else if (type == AUTOMODE){
		strcpy(at_cmd, AUTO_MODE);
		IOBD_DEBUG_LEVEL3 ("AUTO_MODE set");
	}
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
		close(serial_fd);
		IOBD_DEBUG_LEVEL2("acm fp+");
		sem_post(&libClient.acm_node);
		IOBD_DEBUG_LEVEL2("acm fp- \n");
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
		if (ret != OBD2_LIB_SUCCESS){
			close(serial_fd);
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
			IOBD_DEBUG_LEVEL2("acm fp+");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL2("acm fp- \n");
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_0,F_OK)){
				IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read : buffer = %s",val);
		}
	}
	close(serial_fd);
	IOBD_DEBUG_LEVEL2("acm p+");
	sem_post(&libClient.acm_node);
	IOBD_DEBUG_LEVEL2("acm p- \n");
	return OBD2_LIB_SUCCESS;
}


int get_gsm_parameters(sim_data *gsm_param)
{
	char *signal_ptr;
	char *lac_ptr;
	char * c_id_ptr;
	char val[100];
	char at_cmd[50];
	int numberofbytesent, numberofbytesrcvd;
	int serial_fd = 0;
	short ret = 0;

	IOBD_DEBUG_LEVEL1("acm w+");
	sem_wait(&libClient.acm_node);
	IOBD_DEBUG_LEVEL1("acm w-");

	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(&libClient.acm_node);
		return E_4G_USB_DISCONNECT;
	}
	else{
		serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
		if(serial_fd <= 0){
			IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", serial_fd, E_4G_USB_INIT);
			IOBD_DEBUG_LEVEL1("acm fp+");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL1("acm fp- \n");
			close(serial_fd);
			return E_4G_USB_INIT;
		}       
	}

	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	strcpy(at_cmd, DISABLE_ECHO);
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(&libClient.acm_node);
		close(serial_fd);
		return E_4G_USB_DISCONNECT;
	}

	ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
		close(serial_fd);
		sem_post(&libClient.acm_node);
		return E_4G_USB_WRITE;
	} 
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_0,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
			sem_post(&libClient.acm_node);
			close(serial_fd);
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
			close(serial_fd);
			sem_post(&libClient.acm_node);
			return E_4G_USB_READ;
		}
	}
	/******************************SIGNAL STRENGTH*********************************/	
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	strcpy(at_cmd, GSM_SIGNAL_STRENGTH);
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(&libClient.acm_node);
		close(serial_fd);
		return E_4G_USB_DISCONNECT;
	}
	ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
		close(serial_fd);
		sem_post(&libClient.acm_node);
		return E_4G_USB_WRITE;
	} 
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_0,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
			sem_post(&libClient.acm_node);
			close(serial_fd);
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
			close(serial_fd);
			sem_post(&libClient.acm_node);
			return E_4G_USB_READ;
		}
	}


	signal_ptr = strtok(val, ":");
	signal_ptr = strtok(NULL, ",");

	strcpy(gsm_param-> signal_lvl,signal_ptr+1);
	IOBD_DEBUG_LEVEL2("signal_ptr:%s\r\n", signal_ptr+1);
	IOBD_DEBUG_LEVEL1("signal_range:%s\r\n", gsm_param-> signal_lvl);
	/************************************CELL ID***********************************/	
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0, sizeof(at_cmd));
	strcpy(at_cmd, "at+creg?\r");
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		close(serial_fd);
		sem_post(&libClient.acm_node);
		return E_4G_USB_DISCONNECT;
	}

	ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
		close(serial_fd);
		sem_post(&libClient.acm_node);
		return E_4G_USB_WRITE;
	}
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_0,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
			close(serial_fd);
			sem_post(&libClient.acm_node);
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
			close(serial_fd);
			sem_post(&libClient.acm_node);
			return E_4G_USB_READ;
		}
	}

	c_id_ptr = strtok(val, "\"");
	c_id_ptr = strtok(NULL, "\"");
	if(c_id_ptr != NULL){
		IOBD_DEBUG_LEVEL3 ("c_id_ptr :%s\r\n", c_id_ptr);
		strcpy(gsm_param->cell_id, c_id_ptr);
		IOBD_DEBUG_LEVEL1("cell_id :%s\r\n",gsm_param->cell_id);
	}
	/*********************************LAC CODE*****************************/
	lac_ptr = strtok(NULL, "\"");
	lac_ptr = strtok(NULL, "\"");
	if(lac_ptr != NULL){
		IOBD_DEBUG_LEVEL3 ("lac_ptr :%s\r\n", lac_ptr);
		strcpy(gsm_param->lac,lac_ptr);
		IOBD_DEBUG_LEVEL1("gsm_param->lac :%s\r\n",gsm_param->lac);
	}

	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));

	close(serial_fd);

	IOBD_DEBUG_LEVEL1("acm p+");
	sem_post(&libClient.acm_node);
	IOBD_DEBUG_LEVEL1("acm p-");

	IOBD_DEBUG_LEVEL2("get_gsm_parameters - ret %hd",ret);
	return ret;
}

int enable_nw_registration_with_location ()
{
	char at_cmd [15];
	char val [56];	
	int ret;
	int serial_fd;
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0, sizeof(at_cmd));

	IOBD_DEBUG_LEVEL1("acm w+");
	sem_wait(&libClient.acm_node);
	IOBD_DEBUG_LEVEL1("acm w-");

	serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
	if(serial_fd <= 0)
	{
		IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", serial_fd, E_4G_USB_INIT);
		IOBD_DEBUG_LEVEL2("acm fp+");
		sem_post(&libClient.acm_node);
		IOBD_DEBUG_LEVEL2("acm fp- \n");
		return E_4G_USB_INIT;
	}
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	strcpy(at_cmd, DISABLE_ECHO);
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
		close(serial_fd);
		IOBD_DEBUG_LEVEL2("acm fp+");
		sem_post(&libClient.acm_node);
		IOBD_DEBUG_LEVEL2("acm fp- \n");
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
			close(serial_fd);
			IOBD_DEBUG_LEVEL2("acm fp+ \n");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL2("acm fp- \n");
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_0,F_OK)){
				IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+ \n");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+ \n");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read: buf : %s",val);
		}
	}
	memset(val, 0x0, sizeof(val));
	memset(at_cmd, 0x0,sizeof(at_cmd));
	strcpy(at_cmd, GSM_CHECK_REGISTRATION_2);
	if(access(USB_0,F_OK)){
		IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
		close(serial_fd);
		IOBD_DEBUG_LEVEL2("acm fp+ \n");
		sem_post(&libClient.acm_node);
		IOBD_DEBUG_LEVEL2("acm fp- \n");
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (serial_fd, at_cmd, strlen(at_cmd));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
			close(serial_fd);
			IOBD_DEBUG_LEVEL2("acm fp+ \n");
			sem_post(&libClient.acm_node);
			IOBD_DEBUG_LEVEL2("acm fp- \n");
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_0,F_OK)){
				IOBD_DEBUG_LEVEL2("ttyUSB2 is removed %d",__LINE__);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+ \n");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
				close(serial_fd);
				IOBD_DEBUG_LEVEL2("acm fp+ \n");
				sem_post(&libClient.acm_node);
				IOBD_DEBUG_LEVEL2("acm fp- \n");
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read : buffer = %s",val);
		}
	}
	close(serial_fd);
	IOBD_DEBUG_LEVEL2("acm p+ \n");
	sem_post(&libClient.acm_node);
	IOBD_DEBUG_LEVEL2("acm p- \n");
	return OBD2_LIB_SUCCESS;
}
