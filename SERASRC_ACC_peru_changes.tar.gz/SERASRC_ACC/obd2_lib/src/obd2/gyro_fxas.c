/* headers */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <math.h>
#include "gyro_fxas.h"
#include "init.h"


int gyro_init()
{
	int fp, status;
	char model_name[50] = {0}; 
	int rc = 0;
	int ret =0;

	system(CONFIG_REG_1);
	system(CONFIG_REG_0);
	system(CONFIG_REG_2);
	system(GYROSCOPE_ENABLE);
	fp = open("/dev/FreescaleGyroscope", O_RDONLY);
	if (fp < 0)
	{
		printf("error open the device!\n");
		rc = -1;
		libClient.gyro_mounted = 0;
	}
	else{
		libClient.gyro_mounted = 1;
		ret = ioctl(fp, SENSOR_GET_MODEL_NAME, &model_name);
		printf("model_name : %s\r\n", model_name);

		ioctl(fp, SENSOR_GET_POWER_STATUS, &status);
		printf("status: %d\r\n", status);
		close(fp);
	}

	return rc;
}

int gyro_deinit()
{
	if (libClient.gyro_mounted == 1){
		system(GYROSCOPE_DISABLE);
	}
	return 0;
}

int gyroscope_read (short * sdata)
{
	int fp; 
	int rc = 0;

	if (libClient.gyro_mounted == 1){
		fp = open("/dev/FreescaleGyroscope", O_RDONLY);
		if (fp < 0)
		{
			printf("error open the device!\n");
			rc = -1;
			return rc;
		}
		ioctl(fp, SENSOR_GET_RAW_DATA, sdata);
		usleep(1250);
		close(fp);
	}else
		rc = -1;

	return rc;
}

int get_gyroscope(gyroscope_api_priv *g_data)
{
	int rc;
	short sdata[3];
	struct timeval gyro_start_time,gyro_end_time;

	printf("get_gyroscope data \n");	
	gettimeofday(&gyro_start_time, NULL);
	rc = gyroscope_read(&sdata[0]);
	gettimeofday(&gyro_end_time, NULL);
	libClient.run_time.gyro_duration = ((gyro_end_time.tv_usec - gyro_start_time.tv_usec) + (gyro_end_time.tv_sec - gyro_start_time.tv_sec)*1000000)/1000;
	if (rc == 0)
	{
		g_data -> x_axis = (float)sdata[0] * 0.0078125;
		g_data -> y_axis = (float)sdata[1] * 0.0078125;
		g_data -> z_axis = (float)sdata[2] * 0.0078125;

		//printf("in lib gyroscope_read x-axis: %f\r\n", g_data -> x_axis);
		//		printf("in lib gyroscope_read y-axis: %f\r\n", g_data -> y_axis);
		//		printf("in lib gyroscope_read z-axis: %f\r\n", g_data -> z_axis);
	}
	else{
		printf("gyro read error\n");
	}

	return rc;
}
