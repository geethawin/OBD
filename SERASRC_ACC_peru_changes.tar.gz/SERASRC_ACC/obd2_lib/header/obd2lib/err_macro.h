/*!< INclude File Header */
#ifndef __OBD2FW_ERR_H_
#define __OBD2FW_ERR_H_

/*!< Add Doxygen comment for macro, variables and function */
#define E_OBD_LIB_MOD_SHIFT     (16)
#define E_OBD_LIB_MOD_MASK     ((1 << E_OBD_LIB_MOD_SHIFT) -1)


#define E_OBD_LIB_ERR_BASE      (0xF0000000)
#define E_OBD2_LIB_INVALID_ARG  (E_OBD_LIB_ERR_BASE + 1)	
#define E_4G_MODULE_BASE    	(E_OBD_LIB_ERR_BASE | (1 & E_OBD_LIB_MOD_MASK) << E_OBD_LIB_MOD_SHIFT) /* VAlues??????*/ 
#define E_4G_USB_INIT		(E_4G_MODULE_BASE + 1)
#define E_4G_USB_WRITE		(E_4G_MODULE_BASE + 2) /* VAlues??????*/
#define E_4G_USB_READ    	(E_4G_MODULE_BASE + 3) /* VAlues??????*/
#define E_4G_USB_DISCONNECT	(E_4G_MODULE_BASE + 4)
#define E_CFG_FILE_OPEN     	(E_4G_MODULE_BASE + 5)

/*
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 5)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 6)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 7)
*/

#endif /* __OBD2FW_ERR_H_ */
