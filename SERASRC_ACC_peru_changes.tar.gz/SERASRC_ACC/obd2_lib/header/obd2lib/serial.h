#ifndef __SERIAL_H_
#define __SERIAL_H_

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <termios.h>
#include "common.h"

int uart_init (const char *device, int baudrate);

struct obd_ {
	double res[255];
	float volt;
	char res_buf[255];
};

typedef struct dtccodes{
	char *dtc_str[500];
	int no_codes;	
}dtccodes;

int obd_read_data(char *,char *,struct obd_ *);
int parse_raw_value(char *,char *);
int config_sleep_wake_trigger_off();
int config_sleep_wake_trigger_on();

#endif
