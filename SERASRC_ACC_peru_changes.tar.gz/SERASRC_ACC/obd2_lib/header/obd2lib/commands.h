#ifndef __COMMANDS__
#define __COMMANDS__

#define CMD_VEHICLE_SPEED               "010D"
#define CMD_RPM                         "010C"
#define CMD_ENGINE_LOAD                 "0104"
#define CMD_DISTANCE_DTC_CLEAR          "0131"
#define CMD_ENGINE_COOLANT_TEMP         "0105"
#define CMD_AIR_TEMP                    "0146"
#define CMD_RUNTIME_ENGINE_START        "011F"
#define CMD_FUEL_LEVEL                  "012F"
#define CMD_OIL_TEMP                    "015C"
#define CMD_VIN                         "0902"
#define CMD_MAF_RATE			"0110"
#define CMD_CTRL_MODULE_VOLT		"0142"
#define CMD_FUEL_RATE			"015E"

#endif
