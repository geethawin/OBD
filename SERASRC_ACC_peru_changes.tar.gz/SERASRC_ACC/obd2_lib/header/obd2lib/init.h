/*
#ifndef INIT_HEADER
#define INIT_HEADER
#endif
*/
#ifndef __INIT__
#define __INIT__
#include "common.h"
#include "obd2lib.h"

#define OBD_VERSION        "SW:M-2.0_REL1.0_AWS:HW_QR2.0"
#define CAR
#define CPU_UNIQUE_ID_LO  "/sys/fsl_otp/HW_OCOTP_CFG0"
#define CPU_UNIQUE_ID_HI  "/sys/fsl_otp/HW_OCOTP_CFG1"
//#define ADC_READ_NODE     "/sys/devices/soc0/soc.0/2100000.aips-bus/2198000.adc/iio:device0/in_voltage0_raw"
#define ADC_READ_NODE     "/sys/bus/iio/devices/iio:device0/in_voltage6_raw"
#define IN_BT_READ_NODE   "/sys/bus/iio/devices/iio:device0/in_voltage2_raw"

#ifdef ENABLE_OBD_DEBUG
#define IOBD_DEBUG(...)\
        {\
        printf("DEBUG:   %s L#%d ", __func__, __LINE__);  \
        printf(__VA_ARGS__); \
        printf("\n"); \
        }       
#else           
#define IOBD_DEBUG(...)
#endif

#define DEBUG_PRINT 0
#define DEBUG_PRINT_RES 1

#define MAX_MESSAGES                                    100
#define MAX_MSG_SIZE                                    256
#define SUCCESS                                          0
#define FAILURE 					-1

struct ign_stat
{
	int msg_type;
	char data[MAX_MSG_SIZE];
};

int send_ign_q(_libClient * libclient,struct ign_stat *);
int init_ign_dis_handler(void);
int hw_init(void);
void hw_deinit(void);
int start_pm_client();
int gps_init(void);
void gps_deinit(int );
int init_ign_q(_libClient *);
int obd_init();
char *trim(char *);
void sigHandler(int);
void get_imei(char *);
int frame_imei(char *,int *,char *);
int check_mode(void);
int check_protocol(void);
int check_ign_status();
int check_connection();
void ntp_server();
int ntp_server_update();
void ignition_thread(void);
void dtc_code(char *);
void car_status(char *);
char *get_disconnect_status(void);
int get_serial_no(void);
int check_adc_voltage (double *);
int check_in_bt_volt (double *);
void sys_sleep_completed(void);
void sys_wake_completed(void);
void server_connection_complete(void);
int get_car_status(car_parameters *carparams);
int agps_init();
//int flight_mode();
//int ParseGNRMC(struct gps_rmc_t *gps_rmc, char buf[200], size_t nbytes);
void enable_only_rmc();

#endif
