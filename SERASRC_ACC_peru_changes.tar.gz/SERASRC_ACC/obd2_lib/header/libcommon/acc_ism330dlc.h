#ifndef __ACCELEROMETER_H__
#define __ACCELEROMETER_H__


#define ACC_MAIN_PATH 		"/sys/bus/iio/devices/iio:device"
#define ACC_SUB_PATH_SCAN   	"/scan_elements"
#define ACC_SUB_PATH_BUF    	"/buffer"
#define ACC_EVENT_NAME		"accel"
#define ACC_INTERRUPT_X_AXIS 	"in_accel_x_en"
#define ACC_INTERRUPT_Y_AXIS 	"in_accel_y_en"
#define ACC_INTERRUPT_Z_AXIS 	"in_accel_z_en"
#define ACC_BUFFER_ENABLE    	"enable"
#define ENABLE  		1
#define DISABLE 		0


typedef struct _accelerometer_api_priv
{
    int fd;
    double x,y,z,acc;
} accelerometer_api_priv;

/* global declaration */
int acc_init();
int acc_deinit();
void accelerometer_read_thread (void);
int get_accelerometer (accelerometer_api_priv *);

#endif /* #define __ACCELEROMETER_H__ */
