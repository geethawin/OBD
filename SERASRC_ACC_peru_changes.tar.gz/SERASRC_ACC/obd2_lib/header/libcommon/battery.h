#ifndef __I_BATTERY__
#define __I_BATTERY__
#include <stdbool.h>
#include <unistd.h>
#include <poll.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define BATTERY_NODE "/sys/class/power_supply/bq27510-0"

int i_battery_get_health();
int i_battery_get_voltage();
int i_battery_get_current();


#endif
