#ifndef __GYROSCOPE_H__
#define __GYROSCOPE_H__

#define GYROSCOPE_ENABLE "echo 1 > /sys/devices/virtual/misc/FreescaleGyroscope/enable"
#define GYROSCOPE_DISABLE "echo 0 > /sys/devices/virtual/misc/FreescaleGyroscope/enable"

#define SENSOR_IOCTL_BASE       'S'
#define SENSOR_GET_MODEL_NAME           _IOR(SENSOR_IOCTL_BASE, 0, char *)
#define SENSOR_GET_POWER_STATUS         _IOR(SENSOR_IOCTL_BASE, 2, int)
#define SENSOR_SET_POWER_STATUS         _IOR(SENSOR_IOCTL_BASE, 3, int)
#define SENSOR_GET_DELAY_TIME           _IOR(SENSOR_IOCTL_BASE, 4, int)
#define SENSOR_SET_DELAY_TIME           _IOR(SENSOR_IOCTL_BASE, 5, int)
#define SENSOR_GET_RAW_DATA             _IOR(SENSOR_IOCTL_BASE, 6, short[3])
#define CONFIG_REG_0			"i2cset -f -y 3 0x20 0x0D 0x17"
#define CONFIG_REG_1			"i2cset -f -y 3 0x20 0x13 0x1E"
#define CONFIG_REG_2			"i2cset -f -y 3 0x20 0x14 0x0c"

typedef struct _gyroscope_api_priv
{
   double x_axis,y_axis,z_axis;
} gyroscope_api_priv;

int get_gyroscope(gyroscope_api_priv *g_data);

#endif /* #define __GYROSCOPE_H__ */
